;********************************************************************************
; Dearborn Protocol Adapter 5 Installation "Readme" File
;
; Drivers:            DGDPA5SA - Dearborn Group DPA 5 Single Application
; Drivers Version:    1.25
;
; File:               Readme.txt
; File Version:       1.25
;
; Revision:   	      September 1, 2011
;
; (c) Dearborn Group Technologies 2011 - All Rights Reserved
;********************************************************************************

;--------------------------------------------------------------------------------
; Purpose
;--------------------------------------------------------------------------------

This file contains last minute instructions and information for the installation 
and configuration of the Dearborn Protocol Adapter 5.

;--------------------------------------------------------------------------------
; Significant Enhancements and Issues Resolved in 1.25
;--------------------------------------------------------------------------------

1.  Fixed verify that SendCommand message sizes are valid. Make sure that command
    with a size greater than 0 pointer to data is not NULL.

;--------------------------------------------------------------------------------
; Table of Contents
;--------------------------------------------------------------------------------

   1:  Installing the DPA from the DPA Installation CD
   2:  Downloading and Installing from the Internet (www.dgtech.com)
   3:  Updating the Firmware On Your DPA 5  
   4:  Uninstalling the DPA
   5:  Deviations/Clarifications From The RP1210B Standard
   6:  Technical Support
   7:  DPA Warranty Terms and Conditions
   8:  Program Enhancements
   9:  Firmware Changes
   10: Driver Changes
   11: Install Changes

;--------------------------------------------------------------------------------
; 1: Installing the DPA from the DPA Installation CD
;--------------------------------------------------------------------------------

  1. Close all running applications.

  2. Insert the DPA Installation CD into your CD drive. 
     2a.  If "autorun" is enabled, the install process should start automatically 
          and you can skip to instruction 4.

  3. If "autorun" is diabled, run the "DPA5Install.exe" executable manually.
     by browsing to your CD and double clicking on "DPA5Install.exe".

  4. Follow the installation program instructions.

  5.  When the setup is complete, it will create a program folder called:

                   "Dearborn Group Products" -> "DPA 5" 

      which can be found under the "Start" -> "Programs" menu.  This folder 
      contains the User Manual and all DPA 5 utility applications such as the 
      Adapter Validation Tool (AVT), and DG Diagnostics.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 2: Downloading and Installing from the Internet (www.dgtech.com)
;--------------------------------------------------------------------------------

  1.  Download the Dearborn Protocol Adapter drivers from the internet found at
      http://www.dgtech.com/ under the support downloads page for the DPA 5.

  2.  Click on the "Installation CD" link to download the file to your computer.
      This file is a ZIP file that contains the complete software package as it
      appears on the installation CD.  

  3.  Unzip the file.

  4.  Run the file called "DPA5Install.exe".

  5.  Follow the installation program instructions.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 3: Updating the Firmware On Your DPA 5 
;--------------------------------------------------------------------------------

Your firmware may be out of date.  Please refer to the DPA 5 User Manual for 
complete instructions on how to check your firmware version and download new 
firmware if needed.  The User Manual can be found under:

   "Start -> Programs -> Dearborn Group Products -> DPA 5"

;--------------------------------------------------------------------------------
; 4: Uninstalling the DPA
;--------------------------------------------------------------------------------

  1.  Launch the "Add or Remove Programs" tool from the Control Panel.

  2.  Select "Dearborn Group DPA 5 Drivers" and then click the "Change/Remove"
      button and follow the instructions.

;--------------------------------------------------------------------------------
; 5: Deviations/Clarifications From The RP1210B Standard
;--------------------------------------------------------------------------------

  1.  Multiple applications.  The DGDPA5SA drivers can only support one application 
      at a time.  Multi-client drivers are being developed and should be released
      in the next version of the DPA 5 drivers.

  Note:  RP1210B is backwards compatible with RP1210A.  All RP1210 applications 
         that were developed for either the RP1210B or RP1210A standard should
         operate properly with the DPA 5.

;--------------------------------------------------------------------------------
; 6: Technical Support
;--------------------------------------------------------------------------------

For users in the United States, technical support is available from 9 a.m. to 
5 p.m. Eastern Time.

Users not residing in the United States should contact your local Dearborn Group 
representative.

	Phone:		(248) 888-2000
	Fax:		(248) 888-1188
	E-mail:		techsupp@dgtech.com 
	Web site:	www.dgtech.com 


;--------------------------------------------------------------------------------
; 7: DPA Warranty Terms and Conditions
;--------------------------------------------------------------------------------

Please refer to the DPA 5 User Manual for warranty terms and conditions.

;--------------------------------------------------------------------------------
; 8: Program Enhancements
;--------------------------------------------------------------------------------


8a.  Adapter Validation Tool Version 2.2

AVT now saves the last Vendor/Device/Protocol to an INI file in the current 
user's home directory.  

8b.  DG Diagnostics (DGD) Version 2.4

Major changes and enhancements to DGD include:

* Saves the last Vendor/Device to an INI file in the current user's home directory.
* Faults, Components are on tabs of their own.
* Total Truck Data and Dynamic Truck Data are on tabs of their own.
* OEM Applications tab added to configure and launch OEM diagnostics.
* Allow users interested in updates to register DGD with DG.
* Allow users to record data from the link and play back that txt file.

8c.  DG Updater Version 1.3

* No changes.

8d.  DPA Firmware Updater Version 5.0

* No changes.

8e.  DPA Options Version 2.2

* Updated application to edit the options for all of the DPA driver sets.

8f.  DPA 5 Bluetooth Configuration Version 1.3

* This version adds three seperate device entries for each bluetooth device 
  that is paired with the PC. Some OEM applications require use of the second 
  CAN and J1939 channel, but have yet to update their software to support the 
  RP1210B API. 

;--------------------------------------------------------------------------------
; 9: Firmware Changes
;--------------------------------------------------------------------------------

1.  Added ISO15765 error callbacks to indicate bus off.
2.  Fixed intermingeling of J1939 and ISO15765 messages on same data link bug.

;--------------------------------------------------------------------------------
; 10: Driver Changes
;--------------------------------------------------------------------------------

1.  Fixed J1939 bug that caused claim address to be released if there were more 
    than one J1939 client and one of them was disconnected.
2.  Added ISO15765 features required by RP1210B standard.
3.  Allow blocking send messages to be sent instead of forcing to non-blocking. 
4.  Updated ini file so that second CAN channel can be selected by RP1210A 
    applications.

;--------------------------------------------------------------------------------
; 11: Install Changes
;--------------------------------------------------------------------------------

1.  Seperated USB driver install so Dual CAN DPA and Quad CAN DPA are seperate 
    components.
2.  Rearranged shortcuts in start menu to make selecting an application easier.



