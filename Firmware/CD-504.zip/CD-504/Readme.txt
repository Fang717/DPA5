;********************************************************************************
; Dearborn Protocol Adapter 5 Series Installation "Readme" File
;
; Drivers:            DGDPA5MA - DG Technologies DPA 5 Multi Application
; Installation Version 5.04
;
; File:               Readme.txt
; Revision:   	      January 10, 2024
;
; Copyright (C) 2008-2024 DG Technologies - All Rights Reserved
;********************************************************************************

;--------------------------------------------------------------------------------
; Purpose
;--------------------------------------------------------------------------------

This file contains instructions and information for the installation and 
configuration of the Dearborn Protocol Adapter 5 Series.

;--------------------------------------------------------------------------------
; Significant Enhancements and Issues Resolved 
;--------------------------------------------------------------------------------

1.  Updated DPA 5 Bluetooth Configuration app
2.  Updated J2534 driver

;--------------------------------------------------------------------------------
; Table of Contents
;--------------------------------------------------------------------------------

   1:  Downloading and Installing from the Internet (www.dgtech.com)
   2:  Updating the Firmware on Your DPA 5  
   3:  Uninstalling the DPA Drivers
   4:  Technical Support
   5:  DPA Warranty Terms and Conditions
   6:  Firmware Changes
   7:  Driver Changes
   8:  Install Changes
   9:  Driver and Utilities Versions

;--------------------------------------------------------------------------------
; 1: Downloading and Installing from the Internet (www.dgtech.com)
;--------------------------------------------------------------------------------

1.1  Download the Dearborn Protocol Adapter drivers from the internet found at
     http://www.dgtech.com/ under the RESOURCE -> Downloads menu.

1.2  Click on the appropriate product family DPA Family Products image to show 
     the DPA driver sets.

1.3  Click on the download link for your product.

1.4  Follow the installation program instructions.

1.5  Check to see if a firmware update is required.  See section 2.

;--------------------------------------------------------------------------------
; 2: Updating the Firmware On Your DPA 5 
;--------------------------------------------------------------------------------

Your firmware may be out of date.  Please refer to the appropriate DPA 5 User 
Manual for complete instructions on how to check your firmware version and 
download new firmware if needed.  The DPA 5 User Manuals can be found on the 
website.

	https://www.dgtech.com/documents/

;--------------------------------------------------------------------------------
; 3: Uninstalling the DPA 5 Drivers
;--------------------------------------------------------------------------------

3.1  Open Control Pannel, select Programs and Features

3.2  Find "DGTech DPA 5" in the list and then select "Uninstall". On some systems 
     you need to click the three dots to access the uninstall option.

3.3  Follow uninstall the instructions.

;--------------------------------------------------------------------------------
; 4: Technical Support
;--------------------------------------------------------------------------------

For users in the United States, technical support is available from 9 a.m. to 
5 p.m. Eastern Time.

Users not residing in the United States should contact your local DG Technologies 
representative.

	Main Phone:	(248) 888-2000
	Tech. Support:  (248) 823-7001
	Fax:		(248) 888-9977
	E-mail:		techsupp@dgtech.com 
	Web site:	www.dgtech.com 


;--------------------------------------------------------------------------------
; 5: DPA Warranty Terms and Conditions
;--------------------------------------------------------------------------------

Please refer to the appropriate DPA 5 User Manual for warranty terms and 
conditions.

;--------------------------------------------------------------------------------
; 6: Firmware Changes
;--------------------------------------------------------------------------------

DPA 5 Dual CAN and DPA 5 Pro (65.417) firmware

     *None

;--------------------------------------------------------------------------------
; 7: Driver Changes
;--------------------------------------------------------------------------------

7.1  RP1210 
     *Changed version number to match instal version

7.2  Native
     *None

7.3  J2534 
     *Fixed J1939 ID in Filter, Rx, and Tx


;--------------------------------------------------------------------------------
; 8: Install Changes
;--------------------------------------------------------------------------------

8.1  Update DPA 5 Bluetooth Configuraiton Application

;--------------------------------------------------------------------------------
; 9: Driver and Utilities Versions
;--------------------------------------------------------------------------------

9.1  DPA Native Drivers             14.05
9.2  DGDPA5MA Driver                5.04
9.3  DGDPA5SA Driver                5.04
9.4  DGServer2 Application          4.01
9.5  J2534 Driver                   2.02
9.6  DGTech Utilities Install       5.01
9.7  DPA Firmware Updater GUI       7.06
9.8  Firmware Updater Drivers       5.05
9.9  J2534 Configuration Utilities  2.12
9.10 DPA 5 Bluetooth Config         3.03
NB! API: 3.00, DLL: 5.04 14.05, Firmware: 6.01 65.417