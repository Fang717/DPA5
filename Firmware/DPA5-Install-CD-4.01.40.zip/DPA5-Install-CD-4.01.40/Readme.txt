;********************************************************************************
; Dearborn Protocol Adapter 5 Series Installation "Readme" File
;
; Drivers:            DGDPA5MA - DG Technologies DPA 5 Multi Application
; Drivers Version:    4.01.40
;
; File:               Readme.txt
; File Version:       4.01.40
;
; Revision:   	      April 29, 2020
; Copyright (C) 2008-2020 DG Technologies - All Rights Reserved
;********************************************************************************

;--------------------------------------------------------------------------------
; Purpose
;--------------------------------------------------------------------------------

This file contains instructions and information for the installation and 
configuration of the Dearborn Protocol Adapter 5 Series.

;--------------------------------------------------------------------------------
; Significant Enhancements and Issues Resolved in 4.01.40
;--------------------------------------------------------------------------------

1.  Updated DPA 5 / DPA 5 Pro firmware
2.  Included updated DGTech Utilities install
3.  Install built with InstallShield

;--------------------------------------------------------------------------------
; Table of Contents
;--------------------------------------------------------------------------------

   1:  Downloading and Installing from the Internet (www.dgtech.com)
   2:  Updating the Firmware On Your DPA 5  
   3:  Uninstalling the DPA Drivers
   4:  Technical Support
   5:  DPA Warranty Terms and Conditions
   6:  Firmware Changes
   7:  Driver Changes
   8:  Install Changes
   9:  Driver and Utilities Versions

;--------------------------------------------------------------------------------
; 1: Downloading and Installing from the Internet (www.dgtech.com)
;--------------------------------------------------------------------------------

1.1  Download the Dearborn Protocol Adapter drivers from the internet found at
     http://www.dgtech.com/ under the RESOURCE -> Downloads menu.

1.2  Click on the appropriate product Family"DPA Family Products" image to show 
     the DPA driver sets.

1.3  Click on the "Download Now" link for the appropriate product.

1.4  You will be asked to enter your email address to which a link to the 
     install file will be sent.

1.5  After you receive the email open the link to the install file.

1.6  Follow the installation program instructions.

1.7  Check to see if a firmware update is required.  See section 2.

;--------------------------------------------------------------------------------
; 2: Updating the Firmware On Your DPA 5 
;--------------------------------------------------------------------------------

Your firmware may be out of date.  Please refer to the appropriate DPA 5 User 
Manual for complete instructions on how to check your firmware version and 
download new firmware if needed.  The DPA 5 User Manuals can be found on the 
website.

	https://www.dgtech.com/documents/

;--------------------------------------------------------------------------------
; 3: Uninstalling the DPA 5 Drivers
;--------------------------------------------------------------------------------

3.1  Launch the "Add or Remove Programs" tool from the Control Panel.

3.2  Select "DGTech DPA 5" and then click the "Change/Remove"
     button and follow the instructions.

;--------------------------------------------------------------------------------
; 4: Technical Support
;--------------------------------------------------------------------------------

For users in the United States, technical support is available from 9 a.m. to 
5 p.m. Eastern Time.

Users not residing in the United States should contact your local DG Technologies 
representative.

	Phone:		(248) 888-2000
	Fax:		(248) 888-9977
	E-mail:		techsupp@dgtech.com 
	Web site:	www.dgtech.com 


;--------------------------------------------------------------------------------
; 5: DPA Warranty Terms and Conditions
;--------------------------------------------------------------------------------

Please refer to the appropriate DPA 5 User Manual for warranty terms and 
conditions.

;--------------------------------------------------------------------------------
; 6: Firmware Changes
;--------------------------------------------------------------------------------

DPA 5 Dual CAN and DPA 5 Pro (65.311) firmware changes

6.1  *None

;--------------------------------------------------------------------------------
; 7: Driver Changes
;--------------------------------------------------------------------------------

7.1  RP1210 
     *RP1210A J1939 transport layer timing parameters updated
     *KWP2000 ini references changed to ISO14230

7.2  Native
     *J1939 timing parameter bug fixed

7.3  J2534 
     *None
;--------------------------------------------------------------------------------
; 8: Install Changes
;--------------------------------------------------------------------------------

8.1  None   

;--------------------------------------------------------------------------------
; 9: Driver and Utilities Versions
;--------------------------------------------------------------------------------

9.1  DPA Native Drivers             12.03
9.2  DGDPA5MA Driver                4.01.40
9.3  DGDPA5SA Driver                4.01.40
9.4  DGServer2 Application          3.00
9.5  J2534 Driver                   1.05.01
9.6  DGTech Utilities Install       3.01.20
9.7  DPA Firmware Updater GUI       6.00
9.8  Firmware Updater Drivers       4.02
9.9  J2534 Configuration Utilities  1.10