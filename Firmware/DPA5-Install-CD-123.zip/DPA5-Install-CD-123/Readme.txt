;********************************************************************************
; Dearborn Protocol Adapter 5 Installation "Readme" File
;
; Drivers:            DGDPA5SA - Dearborn Group DPA 5 Single Application
; Drivers Version:    1.23
;
; File:               Readme.txt
; File Version:       1.23
;
; Revision:   	      October 8, 2010
;
; (c) Dearborn Group Technologies 2010 - All Rights Reserved
;********************************************************************************

;--------------------------------------------------------------------------------
; Purpose
;--------------------------------------------------------------------------------

This file contains last minute instructions and information for the installation 
and configuration of the Dearborn Protocol Adapter 5.

;--------------------------------------------------------------------------------
; Table of Contents
;--------------------------------------------------------------------------------

   1:  Installing the DPA from the DPA Installation CD
   2:  Downloading and Installing from the Internet (www.dgtech.com)
   3:  Updating the Firmware On Your DPA 5  
   4:  Uninstalling the DPA
   5:  Deviations/Clarifications From The RP1210B Standard
   6:  Technical Support
   7:  DPA Warranty Terms and Conditions

;--------------------------------------------------------------------------------
; 1: Installing the DPA from the DPA Installation CD
;--------------------------------------------------------------------------------

  1. Close all running applications.

  2. Insert the DPA Installation CD into your CD drive. 
     2a.  If "autorun" is enabled, the install process should start automatically 
          and you can skip to instruction 4.

  3. If "autorun" is diabled, run the "DPA5Install.exe" executable manually.
     by browsing to your CD and double clicking on "DPA5Install.exe".

  4. Follow the installation program instructions.

  5.  When the setup is complete, it will create a program folder called:

                   "Dearborn Group Products" -> "DPA 5" 

      which can be found under the "Start" -> "Programs" menu.  This folder 
      contains the User Manual and all DPA 5 utility applications such as the 
      Adapter Validation Tool (AVT), and DG Diagnostics.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 2: Downloading and Installing from the Internet (www.dgtech.com)
;--------------------------------------------------------------------------------

  1.  Download the Dearborn Protocol Adapter drivers from the internet found at
      http://www.dgtech.com/ under the support downloads page for the DPA 5.

  2.  Click on the "Installation CD" link to download the file to your computer.
      This file is a ZIP file that contains the complete software package as it
      appears on the installation CD.  

  3.  Unzip the file.

  4.  Run the file called "DPA5Install.exe".

  5.  Follow the installation program instructions.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 3: Updating the Firmware On Your DPA 5 
;--------------------------------------------------------------------------------

Your firmware may be out of date.  Please refer to the DPA 5 User Manual for 
complete instructions on how to check your firmware version and download new 
firmware if needed.  The User Manual can be found under:

   "Start -> Programs -> Dearborn Group Products -> DPA 5"

;--------------------------------------------------------------------------------
; 4: Uninstalling the DPA
;--------------------------------------------------------------------------------

  1.  Launch the "Add or Remove Programs" tool from the Control Panel.

  2.  Select "Dearborn Group DPA 5 Drivers" and then click the "Change/Remove"
      button and follow the instructions.

;--------------------------------------------------------------------------------
; 5: Deviations/Clarifications From The RP1210B Standard
;--------------------------------------------------------------------------------

  1.  Multiple applications.  The DGDPA5SA drivers can only support one application 
      at a time.  Multi-client drivers are being developed and should be released
      in the next version of the DPA 5 drivers.

  Note:  RP1210B is backwards compatible with RP1210A.  All RP1210 applications 
         that were developed for either the RP1210B or RP1210A standard should
         operate properly with the DPA 5.

;--------------------------------------------------------------------------------
; 6: Technical Support
;--------------------------------------------------------------------------------

For users in the United States, technical support is available from 9 a.m. to 
5 p.m. Eastern Time.

Users not residing in the United States should contact your local Dearborn Group 
representative.

	Phone:		(248) 888-2000
	Fax:		(248) 888-1188
	E-mail:		techsupp@dgtech.com 
	Web site:	www.dgtech.com 


;--------------------------------------------------------------------------------
; 7: DPA Warranty Terms and Conditions
;--------------------------------------------------------------------------------

Please refer to the DPA 5 User Manual for warranty terms and conditions.

