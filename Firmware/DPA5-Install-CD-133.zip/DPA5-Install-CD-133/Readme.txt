;********************************************************************************
; Dearborn Protocol Adapter 5 Installation "Readme" File
;
; Drivers:            DGDPA5MA - Dearborn Group DPA 5 Multi Application
; Drivers Version:    1.33
;
; File:               Readme.txt
; File Version:       1.33
;
; Revision:   	      October 15, 2013
;
; Copyright (C) 2008-2013 Dearborn Group, Inc. - All Rights Reserved
;********************************************************************************

;--------------------------------------------------------------------------------
; Purpose
;--------------------------------------------------------------------------------

This file contains last minute instructions and information for the installation 
and configuration of the Dearborn Protocol Adapter 5.

;--------------------------------------------------------------------------------
; Significant Enhancements and Issues Resolved in 1.33
;--------------------------------------------------------------------------------

1.  Fixed various firmware problems with ISO15765

2.  Allow up to 30 seconds for automatic firmware update message to be displayed.

3.  Sped up connect/disconnect time in RP1210 drivers.

;--------------------------------------------------------------------------------
; Table of Contents
;--------------------------------------------------------------------------------

   1:  Installing the DPA from the DPA Installation CD
   2:  Downloading and Installing from the Internet (www.dgtech.com)
   3:  Updating the Firmware On Your DPA 5  
   4:  Uninstalling the DPA
   5:  Technical Support
   6:  DPA Warranty Terms and Conditions
   7:  Firmware Changes
   8:  Driver Changes
   9:  Install Changes

;--------------------------------------------------------------------------------
; 1: Installing the DPA from the DPA Installation CD
;--------------------------------------------------------------------------------

  1. Close all running applications.

  2. Insert the DPA Installation CD into your CD drive. 
     2a.  If "autorun" is enabled, the install process should start automatically 
          and you can skip to instruction 4.

  3. If "autorun" is disabled, run the "DPA5Install.exe" executable manually.
     by browsing to your CD and double clicking on "DPA5Install.exe".

  4. Follow the installation program instructions.

  5.  When the setup is complete, it will create a program folder called:

                   "Dearborn Group Products" -> "DPA 5" 

      which can be found under the "Start" -> "Programs" menu.  This folder 
      contains the User Manual and all DPA 5 utility applications such as the 
      Adapter Validation Tool (AVT), and DG Diagnostics.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 2: Downloading and Installing from the Internet (www.dgtech.com)
;--------------------------------------------------------------------------------

  1.  Download the Dearborn Protocol Adapter drivers from the internet found at
      http://www.dgtech.com/ under the support downloads page for the DPA 5.

  2.  Click on the "Installation CD" link to download the file to your computer.
      This file is a ZIP file that contains the complete software package as it
      appears on the installation CD.  

  3.  Unzip the file.

  4.  Run the file called "DPA5Install.exe".

  5.  Follow the installation program instructions.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 3: Updating the Firmware On Your DPA 5 
;--------------------------------------------------------------------------------

Your firmware may be out of date.  Please refer to the DPA 5 User Manual for 
complete instructions on how to check your firmware version and download new 
firmware if needed.  The User Manual can be found under:

   "Start -> Programs -> Dearborn Group Products -> DPA 5"

;--------------------------------------------------------------------------------
; 4: Uninstalling the DPA
;--------------------------------------------------------------------------------

  1.  Launch the "Add or Remove Programs" tool from the Control Panel.

  2.  Select "Dearborn Group DPA 5 Drivers" and then click the "Change/Remove"
      button and follow the instructions.

;--------------------------------------------------------------------------------
; 5: Technical Support
;--------------------------------------------------------------------------------

For users in the United States, technical support is available from 9 a.m. to 
5 p.m. Eastern Time.

Users not residing in the United States should contact your local Dearborn Group 
representative.

	Phone:		(248) 888-2000
	Fax:		(248) 888-1188
	E-mail:		techsupp@dgtech.com 
	Web site:	www.dgtech.com 


;--------------------------------------------------------------------------------
; 6: DPA Warranty Terms and Conditions
;--------------------------------------------------------------------------------

Please refer to the DPA 5 User Manual for warranty terms and conditions.

;--------------------------------------------------------------------------------
; 7: Firmware Changes
;--------------------------------------------------------------------------------

7a.  DPA 5 Dual CAN (65.115) firmware changes 
* Fixed various ISO15765 multi-packet message bugs.

7b.  DPA 5 Quad CAN (67.115) firmware changes 
* Fixed various ISO15765 multi-packet message bugs.

;--------------------------------------------------------------------------------
; 8: Driver Changes
;--------------------------------------------------------------------------------
RP1210
1.  Sped up connect / disconnect sequence
2.  Fixed ISO15765 send long message where multiple flow controls have been
    configured by the application.
3.  Additional testing added to determine if J1939 and/or ISO15765 clients 
    connecting to the same channel are running at the same baud and allow the 
    connections to take place. 
4.  Allow up to 30 seconds for user to respond to the message box about automatic
    firmware update being performed.
5.  GetHardwareStatus now reports status across various protocols when queried.

J2534
1.  Add use of multi-media timer to improve performance
2.  Updated JVT for device selection and added support for European vehicles
3.  Update SDK Help info
4.  Fixed J1939 for Ch1 and Ch2 
   
;--------------------------------------------------------------------------------
; 9: Install Changes
;--------------------------------------------------------------------------------

1.  Updated firmware updated (WF_*.dll) files.
2.  Changed from DPAUtilities to RP1210Utilities.