;********************************************************************************
; Dearborn Protocol Adapter 5 Installation "Readme" File
;
; Drivers:            DGDPA5MA - Dearborn Group DPA 5 Multi Application
; Drivers Version:    2.01
;
; File:               Readme.txt
; File Version:       2.01
;
; Revision:   	      August 21, 2015
;
; Copyright (C) 2008-2015 Dearborn Group, Inc. - All Rights Reserved
;********************************************************************************

;--------------------------------------------------------------------------------
; Purpose
;--------------------------------------------------------------------------------

This file contains last minute instructions and information for the installation 
and configuration of the Dearborn Protocol Adapter 5.

;--------------------------------------------------------------------------------
; Significant Enhancements and Issues Resolved in 2.01
;--------------------------------------------------------------------------------

1.  Sped up throughput of ReadMessage() in RP1210 multi-application layer.

;--------------------------------------------------------------------------------
; Table of Contents
;--------------------------------------------------------------------------------

   1:  Installing the DPA from the DPA Installation CD
   2:  Downloading and Installing from the Internet (www.dgtech.com)
   3:  Updating the Firmware On Your DPA 5  
   4:  Uninstalling the DPA
   5:  Technical Support
   6:  DPA Warranty Terms and Conditions
   7:  Firmware Changes
   8:  Driver Changes
   9:  Install Changes

;--------------------------------------------------------------------------------
; 1: Installing the DPA from the DPA Installation CD
;--------------------------------------------------------------------------------

  1. Close all running applications.

  2. Insert the DPA Installation CD into your CD drive. 
     2a.  If "autorun" is enabled, the install process should start automatically 
          and you can skip to instruction 4.

  3. If "autorun" is disabled, run the "DPA5Install.exe" executable manually.
     by browsing to your CD and double clicking on "DPA5Install.exe".

  4. Follow the installation program instructions.

  5.  When the setup is complete, it will create a program folder called:

                   "Dearborn Group Products" -> "DPA 5" 

      which can be found under the "Start" -> "Programs" menu.  This folder 
      contains the User Manual and all DPA 5 utility applications such as the 
      Adapter Validation Tool (AVT), and DG Diagnostics.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 2: Downloading and Installing from the Internet (www.dgtech.com)
;--------------------------------------------------------------------------------

  1.  Download the Dearborn Protocol Adapter drivers from the internet found at
      http://www.dgtech.com/ under the support downloads page for the DPA 5.

  2.  Click on the "Installation CD" link to download the file to your computer.
      This file is a ZIP file that contains the complete software package as it
      appears on the installation CD.  

  3.  Unzip the file.

  4.  Run the file called "DPA5Install.exe".

  5.  Follow the installation program instructions.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 3: Updating the Firmware On Your DPA 5 
;--------------------------------------------------------------------------------

Your firmware may be out of date.  Please refer to the DPA 5 User Manual for 
complete instructions on how to check your firmware version and download new 
firmware if needed.  The User Manual can be found under:

   "Start -> Programs -> Dearborn Group Products -> DPA 5"

;--------------------------------------------------------------------------------
; 4: Uninstalling the DPA
;--------------------------------------------------------------------------------

  1.  Launch the "Add or Remove Programs" tool from the Control Panel.

  2.  Select "Dearborn Group DPA 5 Drivers" and then click the "Change/Remove"
      button and follow the instructions.

;--------------------------------------------------------------------------------
; 5: Technical Support
;--------------------------------------------------------------------------------

For users in the United States, technical support is available from 9 a.m. to 
5 p.m. Eastern Time.

Users not residing in the United States should contact your local Dearborn Group 
representative.

	Phone:		(248) 888-2000
	Fax:		(248) 888-9977
	E-mail:		techsupp@dgtech.com 
	Web site:	www.dgtech.com 


;--------------------------------------------------------------------------------
; 6: DPA Warranty Terms and Conditions
;--------------------------------------------------------------------------------

Please refer to the DPA 5 User Manual for warranty terms and conditions.

;--------------------------------------------------------------------------------
; 7: Firmware Changes
;--------------------------------------------------------------------------------

7a.  DPA 5 Dual CAN (65.201) firmware changes
* Implemented ZF protocol.
* Added 250K baud for UART protocols.
* Added CARB files.

7b.  DPA 5 Quad CAN (67.119) firmware changes
* Fix bug related to fast init in ISO9141.

;--------------------------------------------------------------------------------
; 8: Driver Changes
;--------------------------------------------------------------------------------

RP1210 
1.  Speed up throughput of ReadMessage in the DGDPA5MA driver. 
2.  Fixed bugs in GetHardwareStatus where data was not being updated.
3.  Fixed IOCTL bugs related to ISO9141 and KWP2000 in MA layer.
4.  SetFilterType bug fix. 
5.  ISO9141 ReadMessage had extra header bytes that shouldn't have been included.

Native

1.  Fixed race condition that could occur if two API commands were called at
    same time. 

J2534 
1.  For SWCAN/SWISO15765, a change is made to just return success on setting the 
    Resistance Switch to make the application go further.
2.  Allow J1850PWM data rate setting of 83300 to be like 83333
3.  Added support for ISO15765 WFT MAX
4.  Added PassThruIoctl GET_DEVICE_INFO and GET_PROTOCOL_INFO features.
5.  Revised J1939 message format to match the current J2534-2 spec. March 1, 2009
6.  Corrected the RxStatus of ISO15765 29-bit loopback message to show that 
    29-bit-id flag being set.
7.  Corrected the way to handle setting pass filter on CAN while the bus is 
    being flooded.
8.  Fixed a bug of automatically disconnecting CAN (channel 1) when trying to 
    disconnect other protocol while connected to CAN (channel 1).

;--------------------------------------------------------------------------------
; 9: Install Changes
;--------------------------------------------------------------------------------

1.  Added registry entries so 66.xxx firmware will be upgraded to 65.2xx firmware.

;--------------------------------------------------------------------------------
; 9: Driver and Utilties Versions
;--------------------------------------------------------------------------------

1.  DPA Native Drivers            10.20
2.  DGDPA5MA Driver                2.01
3.  DGDPA5SA Driver                2.01
4.  DGServer2 Application          2.01
5.  DPA J2534 Driver               1.01
6.  RP1210 Utilties Install        1.32
7.  DPA Firmware Updater GUI       5.54
8.  Firmware Updater Drivers       3.27