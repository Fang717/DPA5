;********************************************************************************
; Dearborn Protocol Adapter 5 Installation "Readme" File
;
; Drivers:            DGDPA5MA - Dearborn Group DPA 5 Multi Application
; Drivers Version:    1.36
;
; File:               Readme.txt
; File Version:       1.36
;
; Revision:   	      June 23, 2014
;
; Copyright (C) 2008-2014 Dearborn Group, Inc. - All Rights Reserved
;********************************************************************************

;--------------------------------------------------------------------------------
; Purpose
;--------------------------------------------------------------------------------

This file contains last minute instructions and information for the installation 
and configuration of the Dearborn Protocol Adapter 5.

;--------------------------------------------------------------------------------
; Significant Enhancements and Issues Resolved in 1.36
;--------------------------------------------------------------------------------

1.  Improved Bluetooth throughput.

2.  Fixed several bugs that caused fatal exceptions.

;--------------------------------------------------------------------------------
; Table of Contents
;--------------------------------------------------------------------------------

   1:  Installing the DPA from the DPA Installation CD
   2:  Downloading and Installing from the Internet (www.dgtech.com)
   3:  Updating the Firmware On Your DPA 5  
   4:  Uninstalling the DPA
   5:  Technical Support
   6:  DPA Warranty Terms and Conditions
   7:  Firmware Changes
   8:  Driver Changes
   9:  Install Changes

;--------------------------------------------------------------------------------
; 1: Installing the DPA from the DPA Installation CD
;--------------------------------------------------------------------------------

  1. Close all running applications.

  2. Insert the DPA Installation CD into your CD drive. 
     2a.  If "autorun" is enabled, the install process should start automatically 
          and you can skip to instruction 4.

  3. If "autorun" is disabled, run the "DPA5Install.exe" executable manually.
     by browsing to your CD and double clicking on "DPA5Install.exe".

  4. Follow the installation program instructions.

  5.  When the setup is complete, it will create a program folder called:

                   "Dearborn Group Products" -> "DPA 5" 

      which can be found under the "Start" -> "Programs" menu.  This folder 
      contains the User Manual and all DPA 5 utility applications such as the 
      Adapter Validation Tool (AVT), and DG Diagnostics.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 2: Downloading and Installing from the Internet (www.dgtech.com)
;--------------------------------------------------------------------------------

  1.  Download the Dearborn Protocol Adapter drivers from the internet found at
      http://www.dgtech.com/ under the support downloads page for the DPA 5.

  2.  Click on the "Installation CD" link to download the file to your computer.
      This file is a ZIP file that contains the complete software package as it
      appears on the installation CD.  

  3.  Unzip the file.

  4.  Run the file called "DPA5Install.exe".

  5.  Follow the installation program instructions.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 3: Updating the Firmware On Your DPA 5 
;--------------------------------------------------------------------------------

Your firmware may be out of date.  Please refer to the DPA 5 User Manual for 
complete instructions on how to check your firmware version and download new 
firmware if needed.  The User Manual can be found under:

   "Start -> Programs -> Dearborn Group Products -> DPA 5"

;--------------------------------------------------------------------------------
; 4: Uninstalling the DPA
;--------------------------------------------------------------------------------

  1.  Launch the "Add or Remove Programs" tool from the Control Panel.

  2.  Select "Dearborn Group DPA 5 Drivers" and then click the "Change/Remove"
      button and follow the instructions.

;--------------------------------------------------------------------------------
; 5: Technical Support
;--------------------------------------------------------------------------------

For users in the United States, technical support is available from 9 a.m. to 
5 p.m. Eastern Time.

Users not residing in the United States should contact your local Dearborn Group 
representative.

	Phone:		(248) 888-2000
	Fax:		(248) 888-1188
	E-mail:		techsupp@dgtech.com 
	Web site:	www.dgtech.com 


;--------------------------------------------------------------------------------
; 6: DPA Warranty Terms and Conditions
;--------------------------------------------------------------------------------

Please refer to the DPA 5 User Manual for warranty terms and conditions.

;--------------------------------------------------------------------------------
; 7: Firmware Changes
;--------------------------------------------------------------------------------

7a.  DPA 5 Dual CAN (65.118) firmware changes 
* Improved Bluetooth throughput.
* Fixed ISO9141 fast init with not communication bug.
* When data link is disabled stop calculating and passing back bus statistics for 
  that channel.
* When the ring buffer reset command is received also disable all data links.

7b.  DPA 5 Quad CAN (67.117) firmware changes 
* Fixed bug where wrong mail box number was being sent back for BAM receive 
  message.
* Improved Bluetooth throughput.
* Fixed ISO9141 fast init with not communication bug.
* When data link is disabled stop calculating and passing back bus statistics for 
  that channel.
* When the ring buffer reset command is received also disable all data links.

;--------------------------------------------------------------------------------
; 8: Driver Changes
;--------------------------------------------------------------------------------

RP1210
1.  Fixed bug where auto baud client was connecting to a channel that already was
    initialized. 
2.  Fixed race condition in disconnect code when a J1939 and CAN client were 
    connected to the same channel. 


J2534
1.  Made it time efficient by not Sleeping inside ReadMsg function if timeout not
    hit and number of expected messages not read.
2.  Add re-init in vDisconnectProtocol() for ISO9141, ISO14230, & 
    UART_ECHO_BYTE_PS to fix race condition - needed to set 
    pfReceiveFirstByteVector = NULL.
3.  Supported CAN Mixed Mode on ISO15765
4.  Allowed a protocol channel to set up to 20 filters instead of 10. This change
    was made to get GDS2 working.
5.  When calling PassThruReadMsgs, if at least a message is read but not to the
    number of messages it is trying to read, the function returns no error instead
    of error timeout. This change was made to get GDS2 working.
6.  Corrected the rx msg filter check with CAN TxFlags and RxStatus
7.  Corrected the place to make sure J1962 Pins are set.
8.  Made J2534 DPA5/Netbridge SW CAN to be mutually exclusive to CAN CH1.
9.  For ISO15765/SWISO15765 CAN Mixed Mode, corrected a way in order to be able to
    change baud rate 

;--------------------------------------------------------------------------------
; 9: Install Changes
;--------------------------------------------------------------------------------

1.  Added Adapter Validation Tool launcher application. 
2.  Removed checkbox from the user manual dialog. 