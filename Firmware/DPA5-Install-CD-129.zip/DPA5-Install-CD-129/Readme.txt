;********************************************************************************
; Dearborn Protocol Adapter 5 Installation "Readme" File
;
; Drivers:            DGDPA5MA - Dearborn Group DPA 5 Multi Application
; Drivers Version:    1.29
;
; File:               Readme.txt
; File Version:       1.29
;
; Revision:   	      January 10, 2013
;
; Copyright (C) 2008-2013 Dearborn Group, Inc. - All Rights Reserved
;********************************************************************************

;--------------------------------------------------------------------------------
; Purpose
;--------------------------------------------------------------------------------

This file contains last minute instructions and information for the installation 
and configuration of the Dearborn Protocol Adapter 5.

;--------------------------------------------------------------------------------
; Significant Enhancements and Issues Resolved in 1.29
;--------------------------------------------------------------------------------

1.  Added support of receiving multiple J1939 transport layer sessions to 
    firmware.

2.  Added 2000ms delay when first RP121032 ClientConnect call is made by 
    ServiceRanger (c) Eaton Corporation.

3.  Added special behavior when ServiceAssistant is communicating with the DPA
    via the RP121032 driver.

;--------------------------------------------------------------------------------
; Table of Contents
;--------------------------------------------------------------------------------

   1:  Installing the DPA from the DPA Installation CD
   2:  Downloading and Installing from the Internet (www.dgtech.com)
   3:  Updating the Firmware On Your DPA 5  
   4:  Uninstalling the DPA
   5:  Technical Support
   6:  DPA Warranty Terms and Conditions
   7:  Program Enhancements
   8:  Firmware Changes
   9:  Driver Changes
   10: Install Changes

;--------------------------------------------------------------------------------
; 1: Installing the DPA from the DPA Installation CD
;--------------------------------------------------------------------------------

  1. Close all running applications.

  2. Insert the DPA Installation CD into your CD drive. 
     2a.  If "autorun" is enabled, the install process should start automatically 
          and you can skip to instruction 4.

  3. If "autorun" is disabled, run the "DPA5Install.exe" executable manually.
     by browsing to your CD and double clicking on "DPA5Install.exe".

  4. Follow the installation program instructions.

  5.  When the setup is complete, it will create a program folder called:

                   "Dearborn Group Products" -> "DPA 5" 

      which can be found under the "Start" -> "Programs" menu.  This folder 
      contains the User Manual and all DPA 5 utility applications such as the 
      Adapter Validation Tool (AVT), and DG Diagnostics.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 2: Downloading and Installing from the Internet (www.dgtech.com)
;--------------------------------------------------------------------------------

  1.  Download the Dearborn Protocol Adapter drivers from the internet found at
      http://www.dgtech.com/ under the support downloads page for the DPA 5.

  2.  Click on the "Installation CD" link to download the file to your computer.
      This file is a ZIP file that contains the complete software package as it
      appears on the installation CD.  

  3.  Unzip the file.

  4.  Run the file called "DPA5Install.exe".

  5.  Follow the installation program instructions.

  6.  Check to see if a firmware update is required.  See section 3.

;--------------------------------------------------------------------------------
; 3: Updating the Firmware On Your DPA 5 
;--------------------------------------------------------------------------------

Your firmware may be out of date.  Please refer to the DPA 5 User Manual for 
complete instructions on how to check your firmware version and download new 
firmware if needed.  The User Manual can be found under:

   "Start -> Programs -> Dearborn Group Products -> DPA 5"

;--------------------------------------------------------------------------------
; 4: Uninstalling the DPA
;--------------------------------------------------------------------------------

  1.  Launch the "Add or Remove Programs" tool from the Control Panel.

  2.  Select "Dearborn Group DPA 5 Drivers" and then click the "Change/Remove"
      button and follow the instructions.

;--------------------------------------------------------------------------------
; 5: Technical Support
;--------------------------------------------------------------------------------

For users in the United States, technical support is available from 9 a.m. to 
5 p.m. Eastern Time.

Users not residing in the United States should contact your local Dearborn Group 
representative.

	Phone:		(248) 888-2000
	Fax:		(248) 888-1188
	E-mail:		techsupp@dgtech.com 
	Web site:	www.dgtech.com 


;--------------------------------------------------------------------------------
; 6: DPA Warranty Terms and Conditions
;--------------------------------------------------------------------------------

Please refer to the DPA 5 User Manual for warranty terms and conditions.

;--------------------------------------------------------------------------------
; 7: Program Enhancements
;--------------------------------------------------------------------------------

7a.  Adapter Validation Tool Version 3.1
* Selectable English/French/Spanish translations.
* Changed copyright date.

7b.  Fix INI Version 3.1
* Selectable English/French/Spanish translations.
* Changed copyright date.

7c.  DG Diagnostics (DGD) Version 2.82
* Auto baud detect is not checked by default on Home tab.
* Added display of J2012 fault data to Faults tab.
* Added 6 alternator parameters for US Army to dynamic parameters tab.
* Added fuel pressure and fuel differential pressure to dynamic parameters tab.
* Added display of DM24 (Supported PIDs) to Emissions tab for Detroit Diesel.
* Changed copyright date.

7d.  DG Updater Version 1.53
* Changed copyright date.

7e.  DPA Firmware Updater Version 5.51
* Changed copyright date.

7f.  DPA Options Version 2.51
* Changed copyright date.

7g.  Sample Source Code/EXE � C Language Version 2.65
* Changed copyright date.

7h.  DPA 5 Bluetooth Configuration Version 1.51
* Changed copyright date.

7i.  J2534 ISO15765 Sample Source Version 1.21
* This is a new set of sample C++ code for 11-bit ISO15765 and the J2534 API.
* Changed copyright date.	

7j.  RP1210 Sample Source Code � Python Language Version 1.1
* This is a new set of sample source code for the Python programming language.

;--------------------------------------------------------------------------------
; 8: Firmware Changes
;--------------------------------------------------------------------------------

1.  Added support of receiving multiple J1939 transport layer sessions to 
    firmware.

;--------------------------------------------------------------------------------
; 9: Driver Changes
;--------------------------------------------------------------------------------

1.  Added 2000ms delay when  first Rp121032 ClientConnect call is made by 
    ServicRanger (c) Eaton Corporation.

2.  Added special behavior when ServiceAssistant is communicating with the DPA
    via the Rp121032 driver.
  
;--------------------------------------------------------------------------------
; 10: Install Changes
;--------------------------------------------------------------------------------

1.  Removed DGDPA5SA entry from ini file.

2.  Added Python Language RP1210 Sample Source Code SampleSource.py to 
    [DPA Utilities]\SampleSource



