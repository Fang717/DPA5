﻿' ----------------------------------------------------------------------------------------------------
'  DG Technologies - VB Sample Source Code - Copyright (c) 2014 - Dearborn Group, Inc.
' ----------------------------------------------------------------------------------------------------
' 
'  Name:           VBJ2534SampleSource.vb Version 1.00 for ISO15765 11-Bit VB.Net
' 
'  Date:           March 27, 2014
' 
'  Written By:     Kenneth L. DeGrant II
'                  Field Applications Engineering Manager, TMC RP1210 Task Force Chairman
'                  DG Technologies
'                  33604 West 8 Mile Road
'                  Farmington Hills, MI  48335
'                  kdegrant@dgtech.com
' 
'  Description:    This code is provided by Dearborn Group, Inc. to assist application developers in 
'                  developing J2534 applications for Dearborn Group J2534 devices.  It allows 
'                  connecting to the ISO15765 protocol at 500k with Standard (11-bit) CAN 
'                  identifiers.  It shows how to set flow control filters for all ISO15765-4
'                  test equipment addresses to the address from the physical ECUs.
'
'                        External Test Equipment      Physical Response CANID
'                        -----------------------      -----------------------
'                               0x7E0                         0x7E8
'                               0x7E1                         0x7E9
'                               0x7E2                         0x7EA
'                               0x7E3                         0x7EB
'                               0x7E4                         0x7EC
'                               0x7E5                         0x7ED
'                               0x7E6                         0x7EE
'                               0x7E7                         0x7EF
'
'                  After the flow control filters are set up, the program will send out the 
'                  J1979 request for supported PID values in Mode 1 (Mode 1, PID 0) every
'                  three seconds and process the responses.  This is sometimes called 
'                  the tester present, or keep-alive message.  
'
' Code Notes:      All necessary code for this project is in this file.  Because this program
'                  runs on a DOS command prompt, it can be readily adapted to do any basic 
'                  functionality that a developer unfamiliar with J2534 might want to do, and without
'                  having to look at complex MFC, Visual Basic, C#, or other "GUI" code.  
'
'                  You may have to set your target EXE type to x86 to get the code to run properly.
'                  If LoadLibrary() fails, this is your indication.
'
'                  It is possible to develop a completely J2534 compliant application that
'                  will not connect, send or read messages to or from a particular databus.  
'                  To ensure success, please read the documentation for the protocol you want to use 
'                  thoroughly along with reading the "complete" J2534 document before trying to 
'                  adapt this code to a particular purpose.
'
'  Special Thanks: Special thanks goes out to Leo Kominek of Eaton Corporation for his help
'                  getting this project going and also the VB code for J2534.
'
'  Requirements:   This program requires that you have downloaded and installed the latest J2534 
'                  drivers for one of the following products:
'
'                     * DG DPA 5                ( DLL Name = DGDPA532.DLL   )
'                     * VSI-2534                ( DLL Name = DGVSI32.DLL    )
'                     * d-briDGe                ( DLL Name = DBRIDGE.DLL    )
'                     * Netbridge               ( DLL Name = NBRIDGE.DLL    )
'                     * Softbridge              ( DLL Name = SOFTBRIDGE.DLL )
'                     * Gryphon, G2, S3, S4     ( DLL Name = J2534G32.DLL   )
'
'                  Drivers are available from the DG Technologies website as follows:
'                               http://www.dgtech.com/download.php
'
'  No Liability:   This code is example code and is NOT warranted to be fit for any particular use 
'                  or purpose.  DG Technologies will not be held liable for any use or 
'                  misuse of this code "under any circumstances whatsoever".  
' 
'  Copyright:      This code is copyrighted by Dearborn Group, Inc., and is intended
'                  solely for the use of our DPA customers or potential DPA customers.  No portion,
'                  including "snippets" of this code are to be used, investigated, or copied in any 
'                  shape, form, or fashion, by anyone who is, or may in the future be, in competition 
'                  with DG Technologies in any way.  The code shall also not be modified in
'                  a way that it is capable of being used with any adapter outside of one from Dearborn 
'                  Group Technology.
'
' ----------------------------------------------------------------------------------------------------
'  Revision  Date       Notes
'     1.0    03-27-14   Original Version.
' ----------------------------------------------------------------------------------------------------
'
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Globalization

Module VBJ2534SampleSource

    Public Const PROGRAM_ID = "DG Technologies - VB J2534 Sample Souce Code For ISO15765 11-Bit - Version 1.00"

    '-----------------------------------------------------------------------------------------------------
    ' J2534   J2534 definitions.
    '-----------------------------------------------------------------------------------------------------

    '
    ' Protocol definitions 
    '
    Public Const J1850VPW                               As UInt32 =  1
    Public Const J1850PWM                               As UInt32 =  2
    Public Const ISO9141                                As UInt32 =  3
    Public Const ISO14230                               As UInt32 =  4
    Public Const CAN                                    As UInt32 =  5
    Public Const ISO15765                               As UInt32 =  6
    Public Const SCI_A_ENGINE                           As UInt32 =  7
    Public Const SCI_A_TRANS                            As UInt32 =  8
    Public Const SCI_B_ENGINE                           As UInt32 =  9
    Public Const SCI_B_TRANS                            As UInt32 = 10
    '
    ' IOCTL IDs
    '
    Public Const GET_CONFIG                             As UInt32 =  1
    Public Const SET_CONFIG                             As UInt32 =  2
    Public Const READ_VBATT                             As UInt32 =  3
    Public Const FIVE_BAUD_INIT                         As UInt32 =  4
    Public Const FAST_INIT                              As UInt32 =  5
    Public Const SET_PIN_USE                            As UInt32 =  6
    Public Const CLEAR_TX_BUFFER                        As UInt32 =  7
    Public Const CLEAR_RX_BUFFER                        As UInt32 =  8
    Public Const CLEAR_PERIODIC_MSGS                    As UInt32 =  9
    Public Const CLEAR_MSG_FILTERS                      As UInt32 = 10
    Public Const CLEAR_FUNCT_MSG_LOOKUP_TABLE           As UInt32 = 11
    Public Const ADD_TO_FUNCT_MSG_LOOKUP_TABLE          As UInt32 = 12
    Public Const DELETE_FROM_FUNCT_MSG_LOOKUP_TABLE     As UInt32 = 13
    Public Const READ_PROG_VOLTAGE                      As UInt32 = 14
    '
    ' Configuration Parameter IDs
    '
    Public Const CAN_ID_BOTH                            As UInt32 = &H0400
    Public Const DATA_RATE                              As UInt32 = 1
    Public Const LOOPBACK                               As UInt32 = 3
    Public Const NODE_ADDRESS                           As UInt32 = 4
    Public Const NETWORK_LINE                           As UInt32 = 5
    Public Const P1_MIN                                 As UInt32 = 6
    Public Const P1_MAX                                 As UInt32 = 7
    Public Const P2_MIN                                 As UInt32 = 8
    Public Const P2_MAX                                 As UInt32 = 9
    Public Const P3_MIN                                 As UInt32 = 10
    Public Const P3_MAX                                 As UInt32 = 11
    Public Const P4_MIN                                 As UInt32 = 12
    Public Const P4_MAX                                 As UInt32 = 13
    Public Const W1                                     As UInt32 = 14
    Public Const W2                                     As UInt32 = 15
    Public Const W3                                     As UInt32 = 16
    Public Const W4                                     As UInt32 = 17
    Public Const W5                                     As UInt32 = 18
    Public Const TIDLE                                  As UInt32 = 19
    Public Const TINIL                                  As UInt32 = 20
    Public Const TWUP                                   As UInt32 = 21
    Public Const PARITY                                 As UInt32 = 22
    Public Const BIT_SAMPLE_POINT                       As UInt32 = 23
    Public Const SYNC_JUMP_WIDTH                        As UInt32 = 24
    Public Const T1_MAX                                 As UInt32 = 26
    Public Const T2_MAX                                 As UInt32 = 27
    Public Const T4_MAX                                 As UInt32 = 28
    Public Const T5_MAX                                 As UInt32 = 29
    Public Const ISO15765_BS                            As UInt32 = 30
    Public Const ISO15765_STMIN                         As UInt32 = 31
    Public Const DATA_BITS                              As UInt32 = 32
    Public Const FIVE_BAUD_MOD                          As UInt32 = 33
    Public Const BS_TX                                  As UInt32 = 34
    Public Const STMIN_TX                               As UInt32 = 35
    Public Const T3_MAX                                 As UInt32 = 36
    Public Const ISO15765_WFT_MAX                       As UInt32 = 37
    '
    ' Error IDs
    '
    Public Const STATUS_NOERROR                         As UInt32 = 0
    Public Const ERR_NOT_SUPPORTED                      As UInt32 = 1
    Public Const ERR_INVALID_CHANNEL_ID                 As UInt32 = 2
    Public Const ERR_INVALID_PROTOCOL_ID                As UInt32 = 3
    Public Const ERR_NULL_PARAMETER                     As UInt32 = 4
    Public Const ERR_INVALID_IOCTL                      As UInt32 = 5
    Public Const ERR_INVALID_FLAGS                      As UInt32 = 6
    Public Const ERR_FAILED                             As UInt32 = 7
    Public Const ERR_DEVICE_NOT_CONNECTED               As UInt32 = 8
    Public Const ERR_TIMEOUT                            As UInt32 = 9
    Public Const ERR_INVALID_MSG                        As UInt32 = 10
    Public Const ERR_INVALID_TIME_INTERVAL              As UInt32 = 11
    Public Const ERR_EXCEEDED_LIMIT                     As UInt32 = 12
    Public Const ERR_INVALID_MSG_ID                     As UInt32 = 13
    Public Const ERR_INVALID_ERROR_ID                   As UInt32 = 14
    Public Const ERR_INVALID_IOCTL_ID                   As UInt32 = 15
    Public Const ERR_BUFFER_EMPTY                       As UInt32 = 16
    Public Const ERR_BUFFER_FULL                        As UInt32 = 17
    Public Const ERR_BUFFER_OVERFLOW                    As UInt32 = 18
    Public Const ERR_PIN_INVALID                        As UInt32 = 19
    Public Const ERR_CHANNEL_IN_USE                     As UInt32 = 20
    Public Const ERR_MSG_PROTOCOL_ID                    As UInt32 = 21
    '
    ' RxStatus definitions 
    '
    Public Const TX_MSG_TYPE                            As UInt32 = &H00000001
    Public Const ISO15765_FIRST_FRAME                   As UInt32 = &H00000002
    Public Const RX_BREAK                               As UInt32 = &H00000004
    Public Const ISO15765_TX_DONE                       As UInt32 = &H00000008
    '
    ' TxFlags definitions
    '
    Public Const TX_NORMAL_TRANSMIT                     As UInt32 = &H00000000
    Public Const ISO15765_FRAME_PAD                     As UInt32 = &H00000040
    Public Const ISO15765_EXT_ADDR                      As UInt32 = &H00000080
    '
    Public Const TX_STANDARD_CAN                        As UInt32 = &H00
    Public Const TX_EXTENDED_CAN                        As UInt32 = &H80
    '
    Public Const CAN_29BIT_ID                           As UInt32 = &H80
    Public Const CAN_11BIT_ID                           As UInt32 = &H00
    '
    Public Const TX_BLOCKING                            As UInt32 = &H00010000
    Public Const SCI_TX_VOLTAGE                         As UInt32 = &H00800000
    '
    ' Filter definitions 
    '
    Public Const PASS_FILTER                            As UInt32 = &H00000001
    Public Const BLOCK_FILTER                           As UInt32 = &H00000002
    Public Const FLOW_CONTROL_FILTER                    As UInt32 = &H00000003

    '
    ' PASSTHRU_MSG 
    '
    '   Note that this is how you declare a structure to be on a 1-byte boundary,
    '   which is called for in the J2534 specification.
    '
    '   Note that you have to declare the array a fixed size for marshalling 
    '   purposes.  This statement does not allocate any memory in VB.net.  You 
    '   must ReDim the array at 4128 before you use it.  However, the Sizeof operator
    '   will return the correct size of the array, which is 4152 bytes and 
    '   matches up with the C DLL declaration.
    '
    <StructLayout(LayoutKind.Sequential,Pack:=1)> _
    Public Structure PASSTHRU_MSG
      Public ProtocolID        As UInt32      
      Public RxStatus          As UInt32      
      Public TxFlags           As UInt32      
      Public Timestamp         As UInt32      
      Public DataSize          As UInt32      
      Public ExtraDataIndex    As UInt32  
      <MarshalAs(UnmanagedType.ByValArray, SizeConst:=4128)> _
      Public Data              As Byte()
    End Structure 'PASSTHRU_MSG

    '------------------------------------------------------------------------------------------
    ' Import the LoadLibrary(), GetProcAddress(), and FreeLibrary() calls from Kernel32.DLL.
    ' Import the _kbhit() call from CRTDLL.DLL.
    '------------------------------------------------------------------------------------------
  
    <DllImport("kernel32.dll", CallingConvention:=CallingConvention.Winapi, CharSet:=CharSet.Ansi, PreserveSig:=True)> _
    Friend Function LoadLibrary   ( ByVal DllPath As String) As IntPtr
    End Function

    <DllImport("kernel32.dll", CallingConvention:=CallingConvention.Winapi, CharSet:=Charset.Ansi, PreserveSig:=True)> _
    Friend Function FreeLibrary   ( ByVal Handle As IntPtr ) As Integer
    End Function

    <DllImport("kernel32.dll", CallingConvention:=CallingConvention.Winapi, CharSet:=CharSet.Ansi, PreserveSig:=True)> _
    Friend Function GetProcAddress( ByVal hModule As IntPtr, ByVal lpProcName As String) As IntPtr
    End Function

    <DllImport("crtdll.dll", CallingConvention:=CallingConvention.Winapi, CharSet:=CharSet.Ansi, PreserveSig:=True)> _
    Friend Function _kbhit() As Int32
    End Function

    '------------------------------------------------------------------------------------------
    ' J2534 Function Prototypes.  
    '------------------------------------------------------------------------------------------
    
    public delegate function PassThruOpen                  (pName     As IntPtr, ByRef pDeviceID As UInt32                                                                           ) As UInt32
    public delegate function PassThruClose                 (DeviceID  As UInt32                                                                                                      ) As UInt32
    public delegate function PassThruConnect               (DeviceID  As UInt32,       ProtoID   As UInt32,       Flags    As UInt32, BaudRate As UInt32, ByRef pChanID As UInt32    ) As UInt32
    public delegate function PassThruDisconnect            (ChannelID As UInt32                                                                                                      ) As UInt32
    public delegate function PassThruReadMsgs              (ChannelID As UInt32,       pMsg      As IntPtr, ByRef pNumMsgs as Uint32, Timeout  As UInt32                             ) As UInt32
    public delegate function PassThruWriteMsgs             (ChannelID As UInt32,       pMsg      As IntPtr, ByRef pNumMsgs As UInt32, Timeout  As UInt32                             ) As UInt32
    public delegate function PassThruStartPeriodicMsg      (ChannelID As UInt32,       pMsg      As IntPtr, ByRef pMsgID   As UInt32, TimeInt  As UInt32                             ) As UInt32
    public delegate function PassThruStopPeriodicMsg       (ChannelID As UInt32,       MsgID     As UInt32                                                                           ) As UInt32
    public delegate function PassThruStartMsgFilter        (ChannelID As UInt32, FiltType  As UInt32, pMask As IntPtr, pPatt As IntPtr, pFlowCon As IntPtr, Byref pFilterID As UInt32) As UInt32
    public delegate function PassThruStopMsgFilter         (ChannelID As UInt32,       FilterID  As Uint32                                                                           ) As UInt32
    public delegate function PassThruSetProgrammingVoltage (DeviceID  As UInt32,       PinNumber As Uint32,       Voltage  As UInt32                                                 ) As UInt32
    public delegate function PassThruReadVersion           (DeviceID  As UInt32,       pFWVer    As Byte(),       pDLLVer  As Byte(), pAPIVer  As Byte()                             ) As UInt32
    public delegate function PassThruGetLastError          (pErrDesc  As Byte()                                                                                                      ) As UInt32
    public delegate function PassThruIoctl                 (ChannelID As UInt32,       IOCTLID   As UInt32,       pInput   As IntPtr, pOutput  As IntPtr                             ) As UInt32
    
    '
    ' Convert a byte array into a String variable.  
    '
    ' Calls to a C/C++ DLL of ANSI C strings (char *) must be Byte() arrays because VB and other
    ' languages do not use NULL terminated strings, they use a descriptor byte.
    '
    ' The System.Text.Encoding.ASCII.GetString( Byte() ) does not set the descriptor
    ' byte to the number of non-zero characters, so you have to do this yourself because
    ' the length attribute is read-only.  You have to iterate through the array until 
    ' a NULL/Zero character is found and append each character as you go.
    '
    Public Function ByteArrayToString( baArray As Byte(), ByRef szString As String ) As String
     
      Dim i As Integer

      szString = ""

      For i = 0 To baArray.Length Step 1

         If ( baArray(i) = 0 ) Then
           Exit For
         Else
           szString = szString & Chr( baArray (i) )
         End If

      Next 'For

      Return szString

    End Function 'ByteArrayToString

    '
    ' Convert a String into a byte array.  Here the system call works fine.
    '
    Public Function StringToByteArray( szString As String, ByRef baArray As Byte() ) As Byte()

      baArray = System.Text.Encoding.ASCII.GetBytes( szString )

      Return baArray

    End Function 'StringToByteArray

    '
    ' Clear a byte array to zero.
    '
    Public Function ClearByteArray( ByRef baArray As Byte() ) As Byte()

      Array.Clear( baArray, 0, baArray.Length() )

      Return baArray

    End Function 'StringToByteArray

    ' ----------------------------------------------------------------------
    ' Unpack a four-byte integer that has been sent MSB first.
    '
    ' Note that the code does not follow the other sample code.  VB did not
    ' like X = ( Byte << x ) OR ( Byte2 << y ) ...  Each byte had to be 
    ' promoted into an unsigned short and then it could be shifted and the  
    ' result could be OR'd together.
    '
    ' ----------------------------------------------------------------------

    Public Function UnPackFourByteIntegerMSB( ucIntString as Byte(), nStartIdx As Int16 ) As UInt32
    
      Dim usByte0      As UInt16 = 0
      Dim usByte1      As UInt16 = 0
      Dim usByte2      As UInt16 = 0
      Dim usByte3      As UInt16 = 0

      Dim usTot        As UInt32 = 0

      usByte0 = ucIntString(0 + nStartIdx)
      usByte1 = ucIntString(1 + nStartIdx)
      usByte2 = ucIntString(2 + nStartIdx)
      usByte3 = ucIntString(3 + nStartIdx)

      usByte0 <<= 24 
      usByte1 <<= 16
      usByte2 <<=  8 
      usByte3 <<=  0
      
      usTot = (usByte0 OR usByte1 OR usByte2 OR usByte3)   

      Return usTot

    End Function 'UnPackFourByteIntegerMSB

    ' ----------------------------------------------------------------------
    ' Unpack a two-byte integer that has been sent LSB first.
    '
    ' Note that the code does not follow the other sample code.  VB did not
    ' like X = ( Byte << x ) OR ( Byte2 << y ) ...  Each byte had to be 
    ' promoted into an unsigned short and then it could be shifted and the  
    ' result could be OR'd together.
    '
    ' ----------------------------------------------------------------------

    Public Function UnPackTwoByteIntegerLSB( ucIntString As Byte(), nStartIdx As Int16 ) As UInt16
    
      Dim usByte0      As UInt16 = 0
      Dim usByte1      As UInt16 = 0
      Dim usTot        As UInt16 = 0

      usByte0 = ucIntString(0 + nStartIdx)
      usByte1 = ucIntString(1 + nStartIdx)

      usByte0 <<=  0
      usByte1 <<=  8

      usTot = (usByte0 OR usByte1)   

      Return usTot

    End Function 'UnPackTwoByteIntegerLSB

    '------------------------------------------------------------------
    ' J2534 Function Pointer Definitions and then Function Variables
    '------------------------------------------------------------------
    
    public Dim pDLL                            As IntPtr = Nothing

    public Dim pPassThruOpen                   As PassThruOpen                  
    public Dim pPassThruClose                  As PassThruClose                 
    public Dim pPassThruConnect                As PassThruConnect               
    public Dim pPassThruDisconnect             As PassThruDisconnect            
    public Dim pPassThruReadMsgs               As PassThruReadMsgs              
    public Dim pPassThruWriteMsgs              As PassThruWriteMsgs             
    public Dim pPassThruStartPeriodicMsg       As PassThruStartPeriodicMsg      
    public Dim pPassThruStopPeriodicMsg        As PassThruStopPeriodicMsg       
    public Dim pPassThruStartMsgFilter         As PassThruStartMsgFilter        
    public Dim pPassThruStopMsgFilter          As PassThruStopMsgFilter         
    public Dim pPassThruSetProgrammingVoltage  As PassThruSetProgrammingVoltage 
    public Dim pPassThruReadVersion            As PassThruReadVersion           
    public Dim pPassThruGetLastError           As PassThruGetLastError          
    public Dim pPassThruIoctl                  As PassThruIoctl                 

    '    
    '****************************************************************************************************
    '****************************************************************************************************
    ' J2534 Section
    '****************************************************************************************************
    '****************************************************************************************************
    '

    '
    ' Load an J2534 DLL and set up all of the function pointers.
    '
    Public Function LoadDLLAndFunctions( szDLLToLoad As String ) As Boolean

      Dim fpPassThruOpen                  As IntPtr  = Nothing
      Dim fpPassThruClose                 As IntPtr  = Nothing
      Dim fpPassThruConnect               As IntPtr  = Nothing
      Dim fpPassThruDisconnect            As IntPtr  = Nothing
      Dim fpPassThruReadMsgs              As IntPtr  = Nothing
      Dim fpPassThruWriteMsgs             As IntPtr  = Nothing
      Dim fpPassThruStartPeriodicMsg      As IntPtr  = Nothing
      Dim fpPassThruStopPeriodicMsg       As IntPtr  = Nothing
      Dim fpPassThruStartMsgFilter        As IntPtr  = Nothing
      Dim fpPassThruStopMsgFilter         As IntPtr  = Nothing
      Dim fpPassThruSetProgrammingVoltage As IntPtr  = Nothing
      Dim fpPassThruReadVersion           As IntPtr  = Nothing
      Dim fpPassThruGetLastError          As IntPtr  = Nothing
      Dim fpPassThruIoctl                 As IntPtr  = Nothing
      '
      Dim bError                          As Boolean = False
      
      pDLL = LoadLibrary( szDLLToLoad )
      
      If pDLL = 0 Then
          Return False
      End If
        
      fpPassThruOpen                  = GetProcAddress(pDLL, "PassThruOpen"                         )
      fpPassThruClose                 = GetProcAddress(pDLL, "PassThruClose"                        )
      fpPassThruConnect               = GetProcAddress(pDLL, "PassThruConnect"                      )
      fpPassThruDisconnect            = GetProcAddress(pDLL, "PassThruDisconnect"                   )
      fpPassThruReadMsgs              = GetProcAddress(pDLL, "PassThruReadMsgs"                     )
      fpPassThruWriteMsgs             = GetProcAddress(pDLL, "PassThruWriteMsgs"                    )
      fpPassThruStartPeriodicMsg      = GetProcAddress(pDLL, "PassThruStartPeriodicMsg"             )
      fpPassThruStopPeriodicMsg       = GetProcAddress(pDLL, "PassThruStopPeriodicMsg"              )
      fpPassThruStartMsgFilter        = GetProcAddress(pDLL, "PassThruStartMsgFilter"               )
      fpPassThruStopMsgFilter         = GetProcAddress(pDLL, "PassThruStopMsgFilter"                )
      fpPassThruSetProgrammingVoltage = GetProcAddress(pDLL, "PassThruSetProgrammingVoltage"        )
      fpPassThruReadVersion           = GetProcAddress(pDLL, "PassThruReadVersion"                  )
      fpPassThruGetLastError          = GetProcAddress(pDLL, "PassThruGetLastError"                 )
      fpPassThruIoctl                 = GetProcAddress(pDLL, "PassThruIoctl"                        )
      
      If ( 0 = fpPassThruOpen                  ) Then bError = True 
      If ( 0 = fpPassThruClose                 ) Then bError = True 
      If ( 0 = fpPassThruConnect               ) Then bError = True 
      If ( 0 = fpPassThruDisconnect            ) Then bError = True 
      If ( 0 = fpPassThruReadMsgs              ) Then bError = True 
      If ( 0 = fpPassThruWriteMsgs             ) Then bError = True 
      If ( 0 = fpPassThruStartPeriodicMsg      ) Then bError = True 
      If ( 0 = fpPassThruStopPeriodicMsg       ) Then bError = True 
      If ( 0 = fpPassThruStartMsgFilter        ) Then bError = True 
      If ( 0 = fpPassThruStopMsgFilter         ) Then bError = True 
      If ( 0 = fpPassThruSetProgrammingVoltage ) Then bError = True 
      If ( 0 = fpPassThruReadVersion           ) Then bError = True
      If ( 0 = fpPassThruGetLastError          ) Then bError = True
      If ( 0 = fpPassThruIoctl                 ) Then bError = True
      
      If ( True = bError ) Then 
         Return False
      End If
      
      pPassThruOpen                   = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruOpen                 ,GetType(PassThruOpen                 )), PassThruOpen                 )
      pPassThruClose                  = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruClose                ,GetType(PassThruClose                )), PassThruClose                )
      pPassThruConnect                = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruConnect              ,GetType(PassThruConnect              )), PassThruConnect              )
      pPassThruDisconnect             = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruDisconnect           ,GetType(PassThruDisconnect           )), PassThruDisconnect           )
      pPassThruReadMsgs               = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruReadMsgs             ,GetType(PassThruReadMsgs             )), PassThruReadMsgs             )
      pPassThruWriteMsgs              = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruWriteMsgs            ,GetType(PassThruWriteMsgs            )), PassThruWriteMsgs            )
      pPassThruStartPeriodicMsg       = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruStartPeriodicMsg     ,GetType(PassThruStartPeriodicMsg     )), PassThruStartPeriodicMsg     )
      pPassThruStopPeriodicMsg        = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruStopPeriodicMsg      ,GetType(PassThruStopPeriodicMsg      )), PassThruStopPeriodicMsg      )
      pPassThruStartMsgFilter         = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruStartMsgFilter       ,GetType(PassThruStartMsgFilter       )), PassThruStartMsgFilter       )
      pPassThruStopMsgFilter          = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruStopMsgFilter        ,GetType(PassThruStopMsgFilter        )), PassThruStopMsgFilter        )
      pPassThruSetProgrammingVoltage  = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruSetProgrammingVoltage,GetType(PassThruSetProgrammingVoltage)), PassThruSetProgrammingVoltage)
      pPassThruReadVersion            = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruReadVersion          ,GetType(PassThruReadVersion          )), PassThruReadVersion          )
      pPassThruGetLastError           = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruGetLastError         ,GetType(PassThruGetLastError         )), PassThruGetLastError         )
      pPassThruIoctl                  = DirectCast(Marshal.GetDelegateForFunctionPointer(fpPassThruIoctl                ,GetType(PassThruIoctl                )), PassThruIoctl                )
      
      Return True
      
    End Function 'LoadDLLAndFunctions()

    '
    ' Free the J2534 DLL
    '
    Public Function FreeLibraryAndFunctions() As Boolean

      FreeLibrary( pDLL )

      pDLL                            = Nothing
      pPassThruOpen                   = Nothing
      pPassThruClose                  = Nothing
      pPassThruConnect                = Nothing
      pPassThruDisconnect             = Nothing
      pPassThruReadMsgs               = Nothing
      pPassThruWriteMsgs              = Nothing
      pPassThruStartPeriodicMsg       = Nothing
      pPassThruStopPeriodicMsg        = Nothing
      pPassThruStartMsgFilter         = Nothing
      pPassThruStopMsgFilter          = Nothing
      pPassThruSetProgrammingVoltage  = Nothing
      pPassThruReadVersion            = Nothing
      pPassThruGetLastError           = Nothing
      pPassThruIoctl                  = Nothing

      Return True

    End Function'FreeLibraryAndFunctions()

    '------------------------------------------------------------------------------------------------------------------
    ' PrintTxISO15765Message - Print a message that was sent on the ISO15765 bus.
    '------------------------------------------------------------------------------------------------------------------
    
    Public Function PrintTxISO15765Message( sSentMsg As PASSTHRU_MSG ) As Boolean
    
      Dim i                      As Integer   = 0
      Dim j                      As Integer   = 0
      Dim nDataBytesIndex        As UInt32    = 0
      Dim nNumDataBytes          As UInt32    = 0
      Dim iCANID                 As UInt32    = 0
      
      '
      ' Unpack the CANID.  It is always 4 bytes even when using 11-bit.
      '
      iCANID          = UnPackFourByteIntegerMSB( sSentMsg.Data, 0 )
      
      '
      ' Data bytes will start appearing at index 4.
      '
      nDataBytesIndex = 4
      
      '
      ' Calculate the number of data bytes in the message.
      '
      nNumDataBytes   = sSentMsg.DataSize - nDataBytesIndex
      
      '
      ' Print the string to the FILE pointers and to the variable szMsgString.
      '
      Console.WriteLine( "Tx ISO15765 CANID=[{0}] TxFlags=[{1}] DataLen=[{2}]", iCANID.ToString("X8"), sSentMsg.TxFlags.ToString("X8"), nNumDataBytes.ToString("D4") )
      
      '
      ' If data bytes exist (some messages are just indications), print the data bytes as well.
      '  
      If( nNumDataBytes > 0 ) Then
        
          Console.Write("    DATA")
          
          i = nDataBytesIndex

          For j = 0 To ( nNumDataBytes - 1 ) Step 1

              Console.Write("[{0}]", sSentMsg.Data(i).ToString("X2") )

              i = i + 1

          Next 'j

      End If
      
      '
      ' Terminate the line with a newline.  
      '
      Console.WriteLine()
      
      Return True

    End Function 'PrintTxISO15765Message
    
    '------------------------------------------------------------------------------------------------------------------
    ' PrintRxISO15765Message - Print a received ISO15765 message.
    '------------------------------------------------------------------------------------------------------------------
    Public Function PrintRxISO15765Message( sReadMessage As PASSTHRU_MSG ) As Boolean
    
      Dim i                      As integer       = 0
      Dim j                      As integer       = 0
      Dim nDataBytesIndex        As UInt32        = 0
      Dim nNumDataBytes          As UInt32        = 0
      Dim iCANID                 As UInt32        = 0
      
      '
      ' Unpack the CANID.  It is always 4 bytes even when using 11-bit.
      '
      iCANID          = UnPackFourByteIntegerMSB( sReadMessage.Data, 0 )
      
      '
      ' Data bytes will start appearing at index 4.
      '
      nDataBytesIndex = 4
      
      '
      ' Calculate the number of data bytes in the message.
      '
      nNumDataBytes   = sReadMessage.DataSize - nDataBytesIndex
      
      '
      ' Print the string to the screen.
      '
      Console.WriteLine( "Rx TS=[{0}] ISO15765 CANID=[{1}] RxStatus=[{2}] DataLen=[{3}]", _
                         sReadMessage.Timestamp.ToString("D10"), iCANID.ToString("X8"), sReadMessage.RxStatus.ToString("X8"), nNumDataBytes.ToString("D4") )
      
      '
      ' If data bytes exist (some messages are just indications), print the data bytes as well.
      '  
      If( nNumDataBytes > 0 ) Then
        
          Console.Write("    DATA")
          
          i = nDataBytesIndex

          For j = 0 To ( nNumDataBytes - 1 ) Step 1

              Console.Write("[{0}]", sReadMessage.Data(i).ToString("X2") )

              i = i + 1

          Next 'j

      End If
      
      Console.WriteLine()
      
      Return True
      
    End Function 'PrintRxISO15765Message

    '------------------------------------------------------------------------------------------------------------------
    ' ProcessRxISO15765Message - Process a received ISO15765 message.  Look for PID 0x41 which will arrive in 
    '                            response to our sending of PID 0x01 (Supported PIDS).
    '------------------------------------------------------------------------------------------------------------------

    Public Function ProcessRxISO15765Message( sReadMessage As PASSTHRU_MSG ) As Boolean
    
      Dim nNumDataBytes          As UInt32       = 0
      Dim iCANID                 As UInt32       = 0
      Dim i                      As Integer      = 0
      
      '
      ' Print the raw message to the file pointers fp1, fp2.
      '
      PrintRxISO15765Message( sReadMessage )
      
      '
      ' Unpack the CANID of the node.
      '
      iCANID    = UnPackFourByteIntegerMSB( sReadMessage.Data, 0 )
      
      '
      ' The number of data bytes is the data size - 5 (4 bytes CANID + 1 byte for the PID ).
      '
      nNumDataBytes   = sReadMessage.DataSize - 5
      
      Select Case ( sReadMessage.Data(4) )
        
          '
          ' Supported PIDS Mode 1 Response
          '
        case &H41:
          
          Console.WriteLine()
          Console.WriteLine("Received PID 0x41 in Response to PID 0x01 from CANID=[{0}].", iCANID.ToString("X8") )
          Console.Write("    DATA" )

          for i = 0 To ( nNumDataBytes - 1 ) Step 1
            
              Console.Write( "[{0}]", sReadMessage.Data(i+5).ToString("X2") )

          Next 'i
          
          Console.WriteLine()
          Console.WriteLine()
          
          Exit Select
          
      End Select 
      
      Return True
      
    End Function 'ProcessRxISO15765Message

    '------------------------------------------------------------------------------------------------------------------
    ' ReadAndProcessISO15765Messages - Since the PassThruReadMsgs may return status indicators and some requests
    '                                  may return more than one message, this function reads messages until the 
    '                                  buffer is empty.  On each message, it is handled to a "Process" routine
    '                                  that looks for specific PID responses (i.e. 0x41).
    '------------------------------------------------------------------------------------------------------------------
    
    Public Function ReadAndProcessISO15765Messages( ulProtocolID as UInt32, ulChannelID As UInt32 ) As Boolean
    
      Dim sReadMessage      As PASSTHRU_MSG     
      Dim ulRetVal          As UInt32           = 0
      Dim ulNumMessages     As UInt32           = 1
      Dim iSizeOfPTM        As Int16            = 0 
      Dim pMsg              As IntPtr           = IntPtr.Zero
      Dim nDataBytesIndex   As Int16            = 4
      Dim nNumDataBytes     As Int16            = 0

      '
      ' Redimension the Data byte array.
      '
      ReDim sReadMessage.Data(4128)
      ClearByteArray(sReadMessage.Data)

      '
      ' Read messages until dry.
      '
      Do
          '
          ' Setup to read 1 message with a 250ms timeout value.
          '
          ulNumMessages = 1
          
          sReadMessage.ProtocolID = ulProtocolID
          
          '
          ' To pass the address of a structure in VB.Net to a C++ DLL, this is required.
          '      
          iSizeOfPTM              = Marshal.SizeOf( sReadMessage )
          pMsg                    = Marshal.AllocHGlobal( iSizeOfPTM     )
          Marshal.StructureToPtr( sReadMessage, pMsg, false)

          '
          ' Attempt to read a message.
          '
          ulRetVal = pPassThruReadMsgs( ulChannelID, pMsg, ulNumMessages, 250 )
          
          '
          ' Put the message from pMsg back into the sReadMessage structure.
          '
          sReadMessage =  CType(Marshal.PtrToStructure(pMsg, GetType(PASSTHRU_MSG)), PASSTHRU_MSG)

          If( ulRetVal = ERR_BUFFER_EMPTY ) Then
            
              Console.WriteLine("Rx TS=[{0}] ** Buffer Empty", sReadMessage.Timestamp.ToString("D10") )      
              Exit Do

          End If

          nDataBytesIndex = 4
  
          nNumDataBytes   = ( sReadMessage.DataSize - nDataBytesIndex )

          If( ( sReadMessage.RxStatus = &H09 ) AND ( 0 = nNumDataBytes ) ) Then
            
              Console.WriteLine(  "Rx TS=[{0}] ** Tx Done Indication", sReadMessage.Timestamp.ToString("D10") ) 
              Continue Do

          End If

          If( ( sReadMessage.RxStatus AND &H02 ) = &H02 ) Then
            
              Console.WriteLine(  "Rx TS=[{0}] ** Rx Start Indication", sReadMessage.Timestamp.ToString("D10") ) 
              Continue Do

          End If

          If( STATUS_NOERROR = ulRetVal ) Then
          
              ProcessRxISO15765Message( sReadMessage )

          End If
          

          If( ulRetVal = ERR_BUFFER_EMPTY ) Then
            Exit Do
          End If

      Loop 'Do
      
      '
      ' Free the memory.
      '
      Marshal.FreeHGlobal( pMsg )

      Return True

    End Function 'ReadAndProcessISO15765Messages

    '================================================================================
    ' Request Mode Supported PIDS
    '================================================================================

    Public Function RequestModeSupportedPIDS( ulProtocolID As UInt32, ulChannelID As UInt32,  ulTesterCANID As UInt32, ucMode As Byte) As Boolean
    
      Dim ulNumMessages    As UInt32            = 1
      Dim ulRetVal         As UInt32            = 0
      Dim sSendMessage     As PASSTHRU_MSG 
      Dim szErrMsg         As String            = ""
      Dim baErrMsg         As Byte()'100
      Dim iSizeOfPTM       As Integer           = 0 
      Dim pMsg             As IntPtr            = IntPtr.Zero
      
      '
      ' Redimension the baErrMsg (error message) byte array.
      '
      ReDim baErrMsg(100)

      '
      ' Redimension the Data byte array.
      '
      ReDim sSendMessage.Data(4128)
      ClearByteArray ( sSendMessage.Data )

      ' 
      ' Set up the message header to send.
      '
      sSendMessage.ProtocolID         = ISO15765            
      sSendMessage.RxStatus           = &H00000000          
      sSendMessage.ExtraDataIndex     = &H00000000          
      sSendMessage.Timestamp          = &H00000000          
      sSendMessage.TxFlags            = ISO15765_FRAME_PAD  
      
      '
      ' CANID is always 4 bytes even though we are using 11-bit.
      '
      sSendMessage.Data(0)            = ((( ulTesterCANID AND &HFF000000 )) >> 24)
      sSendMessage.Data(1)            = ((( ulTesterCANID AND &H00FF0000 )) >> 16)
      sSendMessage.Data(2)            = ((( ulTesterCANID AND &H0000FF00 )) >>  8)
      sSendMessage.Data(3)            = ((( ulTesterCANID AND &H000000FF )) >>  0)
      
      '
      ' Requests for all PIDS take two messages:
      '     Msg1=(&H00, &H20, &H40, &H60, &H80, &HA0)
      '     Msg2=(&HC0, &HE0)
      '   This app only sends the first message.
      '
      sSendMessage.Data( 4)   = ucMode ' DB1
      sSendMessage.Data( 5)   = &H00   ' DB2
      sSendMessage.Data( 6)   = &H20   ' DB3
      sSendMessage.Data( 7)   = &H40   ' DB4
      sSendMessage.Data( 8)   = &H60   ' DB5
      sSendMessage.Data( 9)   = &H80   ' DB6
      sSendMessage.Data(10)   = &HA0   ' DB7
      sSendMessage.DataSize   = 11

      '
      ' To pass the address of a structure in VB.Net to a C++ DLL, this is required.
      '      
      iSizeOfPTM              = Marshal.SizeOf( sSendMessage )
      pMsg                    = Marshal.AllocHGlobal( iSizeOfPTM     )
      Marshal.StructureToPtr( sSendMessage, pMsg, false)

      '
      ' Write the message.
      '
      ulRetVal = pPassThruWriteMsgs( ulChannelID, pMsg, ulNumMessages, 1000 )

      If ( STATUS_NOERROR <> ulRetVal ) Then
        
          pPassThruGetLastError( baErrMsg )

          ByteArrayToString( baErrMsg, szErrMsg )
          
          Console.WriteLine( "RequestModeSupportedPIDS(Mode={0} PassThruWriteMsgs() Returned Failure of {1}.  Msg={2}", ucMode, ulRetVal, szErrMsg  )
          
          Marshal.FreeHGlobal( pMsg )

          Return false
        
      Else
          '
          ' Put message from pMsg into the sSendMessage structure.
          '
          sSendMessage =  CType(Marshal.PtrToStructure(pMsg, GetType(PASSTHRU_MSG)), PASSTHRU_MSG)
         
          '
          ' Write the message to the screen.
          '
          PrintTxISO15765Message( sSendMessage )

      End If  
      
      '
      ' Read and process ISO15765 messages until the buffer is empty.
      '
      ReadAndProcessISO15765Messages( ulProtocolID, ulChannelID )

      '
      ' Release the memory.
      '      
      Marshal.FreeHGlobal( pMsg )

      Return True

    End Function 'RequestModeSupportedPIDS
    
    '
    '****************************************************************************************************
    '****************************************************************************************************
    ' main() - Program Entry Point
    '****************************************************************************************************
    '****************************************************************************************************
    '

    Sub Main()

      '================================================================================
      ' Declare Global J2534 Variables That Are Used Throughout
      '================================================================================
      
      Dim ulProtocolID                         As UInt32            = ISO15765
      Dim ulProtocolBaud                       As UInt32            = 500000
      Dim ulProtocolFlagsISO15765              As UInt32            = 0
      Dim ulTesterCANID                        As UInt32            = &H000007DF
      Dim ulChannelID                          As UInt32            = &H00
      Dim ulDeviceID                           As UInt32            = &H00
      '
      Dim sMaskMsg                             As PASSTHRU_MSG
      Dim sPatternMsg                          As PASSTHRU_MSG 
      Dim sFlowControlMsg                      As PASSTHRU_MSG 

      '
      ' To pass the address of a structure in VB.Net to a C++ DLL, this is required.
      '      
      Dim iSizeOfPTM                           As Integer           = 0 
      Dim pMsg                                 As IntPtr            = 0
      Dim pMaskMsg                             As IntPtr            = 0
      Dim pPatternMsg                          As IntPtr            = 0
      Dim pFlowControlMsg                      As IntPtr            = 0
      '
      Dim ulFlowFilter                         As UInt32            = 0
      '
      ' Device DLL name, DeviceID and nClientID variables.
      '
      Dim szJ2534DeviceDLL                     As String            = ""
      Dim baJ2534DeviceDLL                     As Byte()'100            
      '
      ' Return value for J2534 functions, and declare a send/read message buffer.
      '
      Dim ulRetVal                             As UInt32            = 0
      Dim szErrMsg                             As String            = ""
      Dim baErrMsg                             As Byte()'100
      '
      ' Values for J2534_ReadDetailedVersion().
      '
      Dim szFirmwareVersion                    As String            = ""
      Dim szDLLVersion                         As String            = ""
      Dim szAPIVersion                         As String            = ""
      Dim abFirmwareVersion                    As Byte()'100
      Dim abDLLVersion                         As Byte()'100
      Dim abAPIVersion                         As Byte()'100
      '
      ' Generic variables.
      '
      Dim sUserInput                           As String            = ""
      Dim iUserChosenAPI                       As Integer           = 0
      '
      ' Variables for sending request messages every 5 seconds.
      '
      Dim dttLastTimeRequestsSent              As DateTime                    
      Dim tsDiffInSeconds                      As TimeSpan                    
      Dim bFirst                               As Boolean           = True

      '
      ' Re-dimension all byte arrays and ensure they are nullified.
      '
      ReDim baErrMsg                           (100)
      ReDim baJ2534DeviceDLL                   (100)
      ReDim abFirmwareVersion                  (100)
      ReDim abDLLVersion                       (100)
      ReDim abAPIVersion                       (100)

      ClearByteArray( baErrMsg          )
      ClearByteArray( baJ2534DeviceDLL  )
      ClearByteArray( abFirmwareVersion )
      ClearByteArray( abDLLVersion      )
      ClearByteArray( abAPIVersion      )

      '
      ' Redimension the arrays inside of the PASSTHRU_MSG sructures and clear that memory.
      '
      ReDim sPatternMsg.Data    (4128)
      ReDim sMaskMsg.Data       (4128)
      ReDim sFlowControlMsg.Data(4128)

      ClearByteArray ( sPatternMsg.Data     )
      ClearByteArray ( sMaskMsg.Data        )
      ClearByteArray ( sFlowControlMsg.Data )
      
      '
      ' Write the program identification to the screen.
      '
      Console.WriteLine( PROGRAM_ID )

      '
      ' Have the user select the adapter they want to use and set szJ2534DeviceDLL.
      '
      Do 
        
          Console.WriteLine( "                                                                       " )
          Console.WriteLine( "---------------------------------------------------------------------- " )
          Console.WriteLine( " Select Adapter To Use                                                 " )
          Console.WriteLine( "---------------------------------------------------------------------- " )
          Console.WriteLine( "                                                                       " )
          Console.WriteLine( " 1 = DG DPA 5                ( DLL Name = DGDPA532.DLL   )             " )
          Console.WriteLine( " 2 = VSI-2534                ( DLL Name = DGVSI32.DLL    )             " )
          Console.WriteLine( " 3 = d-briDGe                ( DLL Name = DBRIDGE.DLL    )             " )
          Console.WriteLine( " 4 = Netbridge               ( DLL Name = NBRIDGE.DLL    )             " )
          Console.WriteLine( " 5 = Softbridge              ( DLL Name = SOFTBRIDGE.DLL )             " )
          Console.WriteLine( " 6 = Gryphon, G2, S3, S4     ( DLL Name = J2534G32.DLL   )             " )
          Console.WriteLine( "                                                                       " )
          Console.Write    ( "->  " )
          
          sUserInput = Console.ReadLine()
          
          If Len( sUserInput ) > 0
            
              iUserChosenAPI = Convert.ToInt32( sUserInput )
              
              Select Case ( iUserChosenAPI )
                
                 Case 1
                    szJ2534DeviceDLL = "dgDPA532.DLL"   
                    Exit Do
                 Case 2
                    szJ2534DeviceDLL = "DGVSI32.DLL"    
                    Exit Do
                 Case 3
                    szJ2534DeviceDLL = "DBRIDGE.DLL"    
                    Exit Do
                 Case 4
                    szJ2534DeviceDLL = "NBRIDGE.DLL"    
                    Exit Do
                 Case 5
                    szJ2534DeviceDLL = "SOFTBRIDGE.DLL" 
                    Exit Do
                 Case 6
                    szJ2534DeviceDLL = "J2534G32.DLL"   
                    Exit Do
                    
              End Select
              
          End If  
          
      Loop 'Do
      
      '
      ' Attempt loading the DLL and setting all of the function pointers.
      '
      If ( False = LoadDLLAndFunctions( szJ2534DeviceDLL.ToString() ) ) Then
        
          Console.WriteLine( "FAILURE loading DLL {0}.", szJ2534DeviceDLL )
          Console.WriteLine( " -> Try setting the project EXE type to x86.")
          End
          
      End If
      
      '
      ' PassThruOpen() - Open a connection to the device.  Get the DeviceID back.
      '
      ulRetVal = pPassThruOpen( IntPtr.Zero, ulDeviceID )
      
      If ( STATUS_NOERROR <> ulRetVal ) Then
        
          Console.WriteLine( "FAILURE calling PassThruOpen on DLL {0}. Returned {1}.", szJ2534DeviceDLL, ulRetVal )
          FreeLibraryAndFunctions()
          End
          
      End If
      
      '
      ' PassThruReadVersion() - Get the API, DLL, and FW version information.
      '
      ulRetVal = pPassThruReadVersion(ulDeviceID, abFirmwareVersion, abDLLVersion, abAPIVersion)

      If ( STATUS_NOERROR <> ulRetVal) Then
        
          Console.WriteLine("FAILURE calling PassThruReadVersion on DLL {0}. Returned {1}.", szJ2534DeviceDLL, ulRetVal )
          FreeLibraryAndFunctions()
          End
        
      Else

         ByteArrayToString( abFirmwareVersion, szFirmwareVersion )        
         ByteArrayToString( abDLLVersion     , szDLLVersion      )        
         ByteArrayToString( abAPIVersion     , szAPIVersion      )        

         Console.WriteLine("Device Firmware Version = {0}, DLL Version = {1}, API Version = {2}", szFirmwareVersion, szDLLVersion, szAPIVersion )
         
      End If
      
      '
      ' PassThruconnect() - Connect to the ISO15765 data bus.
      '
      ulRetVal = pPassThruConnect(ulDeviceID, ulProtocolID, ulProtocolFlagsISO15765, ulProtocolBaud, ulChannelID )

      If ( STATUS_NOERROR <> ulRetVal) Then
        
          Console.WriteLine("FAILURE calling PassThruConnect on DLL {0}. Returned {1}.", szJ2534DeviceDLL, ulRetVal )
          pPassThruClose(ulDeviceID)
          FreeLibraryAndFunctions()
          End
          
      End If

      '
      ' Setup ISO15765 flow control filters for all allowable 11-bit ISO15765-4 
      ' external test equipment/ECM address combinations.
      '
      '     External Test Equipment      Physical Response CANID
      '     -----------------------      -----------------------
      '            0x7E0                         0x7E8
      '            0x7E1                         0x7E9
      '            0x7E2                         0x7EA
      '            0x7E3                         0x7EB
      '            0x7E4                         0x7EC
      '            0x7E5                         0x7ED
      '            0x7E6                         0x7EE
      '            0x7E7                         0x7EF
      
      sMaskMsg.ProtocolID            = ulProtocolID
      sMaskMsg.RxStatus              = 0
      sMaskMsg.TxFlags               = ISO15765_FRAME_PAD
      sMaskMsg.Timestamp             = 0
      sMaskMsg.DataSize              = 4
      sMaskMsg.ExtraDataIndex        = 0
      sMaskMsg.Data(0)               = &HFF
      sMaskMsg.Data(1)               = &HFF
      sMaskMsg.Data(2)               = &HFF
      sMaskMsg.Data(3)               = &HFF
      
      sPatternMsg.ProtocolID         = ulProtocolID
      sPatternMsg.RxStatus           = 0
      sPatternMsg.TxFlags            = ISO15765_FRAME_PAD
      sPatternMsg.Timestamp          = 0
      sPatternMsg.DataSize           = 4
      sPatternMsg.ExtraDataIndex     = 0
      sPatternMsg.Data(0)            = &H00
      sPatternMsg.Data(1)            = &H00
      sPatternMsg.Data(2)            = &H07
      sPatternMsg.Data(3)            = &HE8
      
      sFlowControlMsg.ProtocolID     = ulProtocolID
      sFlowControlMsg.RxStatus       = 0
      sFlowControlMsg.TxFlags        = ISO15765_FRAME_PAD
      sFlowControlMsg.Timestamp      = 0
      sFlowControlMsg.DataSize       = 4
      sFlowControlMsg.ExtraDataIndex = 4
      sFlowControlMsg.Data(0)        = &H00
      sFlowControlMsg.Data(1)        = &H00
      sFlowControlMsg.Data(2)        = &H07
      sFlowControlMsg.Data(3)        = &HE0
      
      '
      ' Setup flow control filters for all pairs.
      '
      For sFlowControlMsg.Data(3) = &HE0 To &HE7 Step 1
        
          '
          ' This may be redundant, but I wanted to make sure that if the PassThruStartMsgFilter
          '   code modifies the structure in any way, I set it back to the correct state.
          '
          sMaskMsg.ProtocolID            = ulProtocolID
          sMaskMsg.RxStatus              = 0
          sMaskMsg.TxFlags               = ISO15765_FRAME_PAD
          sMaskMsg.Timestamp             = 0
          sMaskMsg.DataSize              = 4
          sMaskMsg.ExtraDataIndex        = 0
          sMaskMsg.Data(0)               = &HFF
          sMaskMsg.Data(1)               = &HFF
          sMaskMsg.Data(2)               = &HFF
          sMaskMsg.Data(3)               = &HFF
          
          sPatternMsg.ProtocolID         = ulProtocolID
          sPatternMsg.RxStatus           = 0
          sPatternMsg.TxFlags            = ISO15765_FRAME_PAD
          sPatternMsg.Timestamp          = 0
          sPatternMsg.DataSize           = 4
          sPatternMsg.ExtraDataIndex     = 0
          sPatternMsg.Data(0)            = &H00
          sPatternMsg.Data(1)            = &H00
          sPatternMsg.Data(2)            = &H07
          
          sFlowControlMsg.ProtocolID     = ulProtocolID
          sFlowControlMsg.RxStatus       = 0
          sFlowControlMsg.TxFlags        = ISO15765_FRAME_PAD
          sFlowControlMsg.Timestamp      = 0
          sFlowControlMsg.DataSize       = 4
          sFlowControlMsg.ExtraDataIndex = 4
          sFlowControlMsg.Data(0)        = &H00
          sFlowControlMsg.Data(1)        = &H00
          sFlowControlMsg.Data(2)        = &H07

          '
          ' This code is required to Marshal managed structure (VB.Net) into a 
          '   C++ DLL unmanaged structure pointer (PASSTHRU_MSG *pMsg).
          '
          iSizeOfPTM              = Marshal.SizeOf( sFlowControlMsg ) 

          pMaskMsg                = Marshal.AllocHGlobal( iSizeOfPTM  )
          pPatternMsg             = Marshal.AllocHGlobal( iSizeOfPTM  )
          pFlowControlMsg         = Marshal.AllocHGlobal( iSizeOfPTM  )

          Marshal.StructureToPtr( sMaskMsg        , pMaskMsg        , false)
          Marshal.StructureToPtr( sPatternMsg     , pPatternMsg     , false)
          Marshal.StructureToPtr( sFlowControlMsg , pFlowControlMsg , false)

          ulRetVal = pPassThruStartMsgFilter( ulChannelID, FLOW_CONTROL_FILTER, pMaskMsg, pPatternMsg, pFlowControlMsg, ulFlowFilter)
          
          If ( STATUS_NOERROR <> ulRetVal )
            
              pPassThruGetLastError ( baErrMsg ) 

              ByteArrayToString     ( baErrMsg, szErrMsg )

              Console.WriteLine("FAILURE calling PassThruStartMsgFilter on DLL {0}. Returned {1}. Reason({2})", szJ2534DeviceDLL, ulRetVal, szErrMsg )

              pPassThruDisconnect(ulChannelID)

              pPassThruClose(ulDeviceID)

              FreeLibraryAndFunctions()

              '
              ' Free all the memory
              '
              Marshal.FreeHGlobal( pMaskMsg        )
              Marshal.FreeHGlobal( pPatternMsg     )
              Marshal.FreeHGlobal( pFlowControlMsg )

              End

          Else
            
              Console.WriteLine( "Setting flow/pattern filter Tester({0}{1}{2}{3}) / ECM ({4}{5}{6}{7}) successful.", _
                      sPatternMsg.Data(0).ToString("X2")        , _
                      sPatternMsg.Data(1).ToString("X2")        , _
                      sPatternMsg.Data(2).ToString("X2")        , _
                      sPatternMsg.Data(3).ToString("X2")        , _
                      sFlowControlMsg.Data(0).ToString("X2")    , _
                      sFlowControlMsg.Data(1).ToString("X2")    , _
                      sFlowControlMsg.Data(2).ToString("X2")    , _
                      sFlowControlMsg.Data(3).ToString("X2")      _   
                      )
          End IF

          sPatternMsg.Data(3) = sPatternMsg.Data(3) + 1

      Next 
      
      '
      ' Free memory allocated with setting flow control filters.
      '
      Marshal.FreeHGlobal( pMaskMsg        )
      Marshal.FreeHGlobal( pPatternMsg     )
      Marshal.FreeHGlobal( pFlowControlMsg )

      '
      ' Let the user know how to exit the program.
      '
      Console.WriteLine( "---------------------------------------------------------------------" )
      Console.WriteLine( " Ready to begin.  Press ""Enter"" to start, any key exits program.   " )
      Console.WriteLine( "            Press ""Ctrl-S"" to freeze the screen.                   " )
      Console.WriteLine( "---------------------------------------------------------------------" )
      Console.Write    ( ">" )
      
      sUserInput = Console.ReadLine()
      
      '
      ' Get the time now.
      '
      dttLastTimeRequestsSent = DateTime.Now
      
      '
      ' Forever.  Read/process messages until a ERR_HARDWARE_NOT_RESPONDING or a keystroke.
      '
      While True
          '
          ' Get the time now and see if it has been over 3 seconds.
          '
          tsDiffInSeconds = DateTime.Now - dttLastTimeRequestsSent
          
          If ( ( tsDiffInSeconds.Seconds > 3 ) OR ( bFirst = True ) ) Then
            
              RequestModeSupportedPIDS( ulProtocolID, ulChannelID, ulTesterCANID, 1 )
              
              dttLastTimeRequestsSent = DateTime.Now

              bFirst = false

          End IF
          
          '
          ' If a key is pressed, exit cleanly.
          '
          If ( _kbhit() <> 0 ) Then 
            Exit While
          End If
          
      End While 'True
      
      '
      ' PassThruDisconnect() - Disconnect from the protocol data bus.
      '
      pPassThruDisconnect( ulChannelID )
      pPassThruClose( ulDeviceID )
      FreeLibraryAndFunctions()
      
      '
      ' Return to the operating system.
      '
      End

    End Sub

End Module
