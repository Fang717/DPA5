% Example Matlab script program for DPA5 J2534 interface.
% The function DPA5End stops the filter, disconnects, and closes.
% You must run script DPA5Start before running this script.
% 
% ***************************************************************************************
% Version 1.1 of 2013-05-01 markc added comments
% Version 1.0 of 2011-01-28 markc initial
% ***************************************************************************************
% Copyright (C) 2011 DG Technologies, Inc. All Rights Reserved.
% The copyright notice here does not evidence any actual or intended publication.
% This code is provided "as-is".
% No claims are made concerning suitability for any given purpose.
% ***************************************************************************************

if not(libisloaded('DGDPA532'))
	return
end

[error] = calllib('DGDPA532', 'PassThruStopMsgFilter', ulChannelID, ulFilterID)

[error] = calllib('DGDPA532', 'PassThruDisconnect', ulChannelID)

[error] = calllib('DGDPA532', 'PassThruClose', ulDeviceID)
