﻿' ----------------------------------------------------------------------------------------------------
'  DG Technologies - VB Sample Source Code - Copyright (c) 2014 - Dearborn Group, Inc.
' ----------------------------------------------------------------------------------------------------
' 
'  Name:           VBRP1210SampleSource.vb Version 1.00 for VB.Net
' 
'  Date:           March 27, 2014
' 
'  Written By:     Kenneth L. DeGrant II
'                  Field Applications Engineering Manager, TMC RP1210 Task Force Chairman
'                  DG Technologies
'                  33604 West 8 Mile Road
'                  Farmington Hills, MI  48335
'                  kdegrant@dgtech.com
' 
'  Description:    This code is provided by DG Technologies to assist application developers in 
'                  developing RP1210 applications for the Dearborn RP1210 family of products.  
'                  It connects to the J1708/J1587 and J1939 protocols.  It displays all message 
'                  traffic seen/sent and also sends out request messages every 5 seconds.  
'                  This example demonstrates all computer science fundamentals
'                  ( open, read, write, close ) necessary to communicate with vehicle components
'                  on any of these networks.
'
'  Special Thanks: Special thanks goes out to Leo Kominek of Eaton Corporation for his help
'                  getting this project going.
'
'  Decoding:       Not only does this code display raw data messages, it also translates one 
'                  common J1587 and J1939 message into text form.  Please see the J1587 and
'                  J1939/71 documents for more information on how you can apply these 
'                  algorithms to the decoding of other messages.
'
'  Code Notes:     All necessary code for this project is in one file ( this file ).  Because this
'                  program runs on a DOS command prompt, it can be readily adapted to do any basic 
'                  functionality that a developer unfamiliar with RP1210 might want to do without
'                  having to look at complex "GUI" code.
'
'                  You may have to set your target platform to 'X86 to get LoadLibrary() to work.
'
'                  Be sure to have your DOS command prompt set to a width of at least 150, as the 
'                  program displays about 140 contiguous characters from messages.
' 
'                  It is possible to develop a completely RP1210 A/B/C compliant application that
'                  will not connect, send or read messages to or from a particular databus.  
'                  To ensure success, please read the documentation for the protocol you want to use 
'                  thoroughly along with reading the "complete" RP1210 document before trying to 
'                  adapt this code to a particular purpose.
'
'  Requirements:   This program requires that you have downloaded and installed the latest RP1210 
'                  drivers for one of the following products:
'
'                     * DPA 5      Multi-Application           ( DLL Name = DGDPA5MA.DLL )
'                     * DPA 4 Plus Multi-Application           ( DLL Name =  DPA4PMA.DLL )
'                     * DPA 4 Plus And Prior DPAs              ( DLL Name = DG121032.DLL )
'                     * Allison DR Drivers (DPA 4 Plus/DPA 5 ) ( DLL Name = DR121032.DLL )
'                     * D-briDGe   Multi-Application           ( DLL Name = DBRIDGEM.DLL )
'                     * Netbridge  Multi-Application           ( DLL Name = NBRIDGEM.DLL )
'
'                  Drivers are available from the DG Technologies website as follows:
'
'                               http://www.dgtech.com/download.php
'
'  No Liability:   This code is example code and is NOT warranted to be fit for any particular use 
'                  or purpose.  DG Technologies will not be held liable for any use or 
'                  misuse of this code "under any circumstances whatsoever".  
' 
'  Copyright:      This code is copyrighted by Dearborn Group, Inc., and is intended
'                  solely for the use of our DPA customers or potential DPA customers.  No portion,
'                  including "snippets" of this code are to be used, investigated, or copied in any 
'                  shape, form, or fashion, by anyone who is, or may in the future be, in competition 
'                  with DG Technologies in any way.  The code shall also not be modified in
'                  a way that it is capable of being used with any adapter outside of one from Dearborn 
'                  Group Technology.
'
' ----------------------------------------------------------------------------------------------------
'  Revision  Date       Notes
'     1.0    03-27-14   Original Version.
' ----------------------------------------------------------------------------------------------------
'
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Globalization

Module VBRP1210SampleSource

    Public Const PROGRAM_ID = "DG Technologies - VB RP1210 Sample Souce Code - Version 1.00"

    '-----------------------------------------------------------------------------------------------------
    ' RP1210   RP1210_SendCommand() definitions.
    '-----------------------------------------------------------------------------------------------------
    
    Public Const RP1210_Reset_Device                              As Short =          0 '
    Public Const RP1210_Set_All_Filters_States_to_Pass            As Short =          3 '
    Public Const RP1210_Set_Message_Filtering_For_J1939           As Short =          4 '
    Public Const RP1210_Set_Message_Filtering_For_CAN             As Short =          5 '
    Public Const RP1210_Set_Message_Filtering_For_J1708           As Short =          7 '
    Public Const RP1210_Set_Message_Filtering_For_J1850           As Short =          8 '
    Public Const RP1210_Set_Message_Filtering_For_ISO15765        As Short =          9 '
    Public Const RP1210_Generic_Driver_Command                    As Short =         14 '
    Public Const RP1210_Set_J1708_Mode                            As Short =         15 '
    Public Const RP1210_Echo_Transmitted_Messages                 As Short =         16 '
    Public Const RP1210_Set_All_Filters_States_to_Discard         As Short =         17 '
    Public Const RP1210_Set_Message_Receive                       As Short =         18 '
    Public Const RP1210_Protect_J1939_Address                     As Short =         19 '
    Public Const RP1210_Set_Broadcast_For_J1708                   As Short =         20 '
    Public Const RP1210_Set_Broadcast_For_CAN                     As Short =         21 '
    Public Const RP1210_Set_Broadcast_For_J1939                   As Short =         22 '
    Public Const RP1210_Set_Broadcast_For_J1850                   As Short =         23 '
    Public Const RP1210_Set_J1708_Filter_Type                     As Short =         24 '
    Public Const RP1210_Set_J1939_Filter_Type                     As Short =         25 '
    Public Const RP1210_Set_CAN_Filter_Type                       As Short =         26 '
    Public Const RP1210_Set_J1939_Interpacket_Time                As Short =         27 '
    Public Const RP1210_SetMaxErrorMsgSize                        As Short =         28 '
    Public Const RP1210_Disallow_Further_Connections              As Short =         29 '
    Public Const RP1210_Set_J1850_Filter_Type                     As Short =         30 '
    Public Const RP1210_Release_J1939_Address                     As Short =         31 '
    Public Const RP1210_Set_ISO15765_Filter_Type                  As Short =         32 '
    Public Const RP1210_Set_Broadcast_For_ISO15765                As Short =         33 '
    Public Const RP1210_Set_ISO15765_Flow_Control                 As Short =         34 '
    Public Const RP1210_Clear_ISO15765_Flow_Control               As Short =         35 '
    Public Const RP1210_Set_ISO15765_Link_Type                    As Short =         36 '
    Public Const RP1210_Set_J1939_Baud                            As Short =         37 '
    Public Const RP1210_Set_ISO15765_Baud                         As Short =         38 '
    Public Const RP1210_Set_BlockTimeout                          As Short =        215 '
    Public Const RP1210_Set_J1708_Baud                            As Short =        305 '

    '-----------------------------------------------------------------------------------------------------
    ' RP1210 Constants - Check RP1210 document for any updates.
    '-----------------------------------------------------------------------------------------------------
    
    Public Const BIT0                                             As Byte =           1 ' Bit 0 - Used for masking bits
    Public Const BIT1                                             As Byte =           2 ' Bit 1 - Used for masking bits
    Public Const BIT2                                             As Byte =           4 ' Bit 2 - Used for masking bits
    Public Const BIT3                                             As Byte =           8 ' Bit 3 - Used for masking bits
    Public Const BIT4                                             As Byte =          16 ' Bit 4 - Used for masking bits
    Public Const BIT5                                             As Byte =          32 ' Bit 5 - Used for masking bits
    Public Const BIT6                                             As Byte =          64 ' Bit 6 - Used for masking bits
    Public Const BIT7                                             As Byte =         128 ' Bit 7 - Used for masking bits
    '
    Public Const CONNECTED                                        As SByte =          1 ' Connection state = Connected 
    Public Const NOT_CONNECTED                                    As SByte =         -1 ' Connection state = Disconnected
    '
    Public Const FILTER_PASS_NONE                                 As Byte =           0 ' Filter state = DISCARD ALL MESSAGES
    Public Const FILTER_PASS_SOME                                 As Byte =           1 ' Filter state = PASS SOME
    Public Const FILTER_PASS_ALL                                  As Byte =           2 ' Filter state = PASS ALL
    '
    Public Const NULL_WINDOW                                      As Byte =           0 ' Windows 3.1 is no longer supported.
    '
    Public Const BLOCKING_IO                                      As Byte =           1 ' For Blocking calls to send/read.
    Public Const NON_BLOCKING_IO                                  As Byte =           0 ' For Non-Blocking calls to send/read.
    Public Const BLOCK_INFINITE                                   As Byte =           0 ' For Blocking calls to send/read.
    '
    Public Const BLOCK_UNTIL_DONE                                 As Byte =           0 ' J1939 Address claim, wait until done
    Public Const RETURN_BEFORE_COMPLETION                         As Byte =           2 ' J1939 Address claim, don't wait
    Public Const SILENT_J1939_CLAIM                               As Byte =           0 ' Claim J1939 Address
    Public Const PASS_J1939_CLAIM_MESSAGES                        As Byte =           1 ' Claim J1939 Address
    '
    Public Const CONVERTED_MODE                                   As Byte =           1 ' J1708 RP1210Mode="Converted"
    Public Const RAW_MODE                                         As Byte =           0 ' J1708 RP1210Mode="Raw"
    '
    Public Const MAX_J1708_MESSAGE_LENGTH                         As Int32 =        508 ' Maximum size of J1708 message (+1)
    Public Const MAX_J1939_MESSAGE_LENGTH                         As Int32 =       1796 ' Maximum size of J1939 message (+1)
    Public Const MAX_ISO15765_MESSAGE_LENGTH                      As Int32 =       4108 ' Maximum size of ISO15765 message (+1)
    '
    Public Const ECHO_OFF                                         As Byte =        &H00 ' EchoMode
    Public Const ECHO_ON                                          As Byte =        &H01 ' EchoMode
    '
    Public Const RECEIVE_ON                                       As Byte =        &H01 ' Set Message Receive
    Public Const RECEIVE_OFF                                      As Byte =        &H00 ' Set Message Receive
    '
    Public Const ADD_LIST                                         As Byte =        &H01 ' Add a message to the list.
    Public Const VIEW_B_LIST                                      As Byte =        &H02 ' View an entry in the list.
    Public Const DESTROY_LIST                                     As Byte =        &H03 ' Remove all entries in the list.
    Public Const REMOVE_ENTRY                                     As Byte =        &H04 ' Remove a specific entry from the list.
    Public Const LIST_LENGTH                                      As Byte =        &H05 ' Returns number of items in list.
    '
    Public Const FILTER_PGN                                       As Int32 = &H00000001 ' Setting of J1939 filters
    Public Const FILTER_PRIORITY                                  As Int32 = &H00000002 ' Setting of J1939 filters
    Public Const FILTER_SOURCE                                    As Int32 = &H00000004 ' Setting of J1939 filters
    Public Const FILTER_DESTINATION                               As Int32 = &H00000008 ' Setting of J1939 filters
    '
    Public Const FILTER_INCLUSIVE                                 As Byte =        &H00 ' FilterMode
    Public Const FILTER_EXCLUSIVE                                 As Byte =        &H01 ' FilterMode
    '
    Public Const CHANGE_BAUD_NOW                                  As Byte =        &H00 ' Change Baud
    Public Const MSG_FIRST_CHANGE_BAUD                            As Byte =        &H01 ' Change Baud
    Public Const RP1210_BAUD_9600                                 As Byte =        &H00 ' Change Baud
    Public Const RP1210_BAUD_19200                                As Byte =        &H01 ' Change Baud
    Public Const RP1210_BAUD_38400                                As Byte =        &H02 ' Change Baud
    Public Const RP1210_BAUD_57600                                As Byte =        &H03 ' Change Baud
    Public Const RP1210_BAUD_125k                                 As Byte =        &H04 ' Change Baud
    Public Const RP1210_BAUD_250k                                 As Byte =        &H05 ' Change Baud
    Public Const RP1210_BAUD_500k                                 As Byte =        &H06 ' Change Baud
    Public Const RP1210_BAUD_1000k                                As Byte =        &H07 ' Change Baud
    '
    Public Const STANDARD_CAN                                     As Byte =        &H00 ' Filters
    Public Const EXTENDED_CAN                                     As Byte =        &H01 ' Filters
    '
    Public Const STANDARD_CAN_ISO15765_EXTENDED                   As Byte =        &H02 ' 11-bit with ISO15765 extended address
    Public Const EXTENDED_CAN_ISO15765_EXTENDED                   As Byte =        &H03 ' 29-bit with ISO15765 extended address
    Public Const STANDARD_MIXED_CAN_ISO15765                      As Byte =        &H04 ' 11-bit identifier with mixed addressing
    Public Const ISO15765_ACTUAL_MESSAGE                          As Byte =        &H00 ' ISO15765 ReadMessage - type of data
    Public Const ISO15765_CONFIRM                                 As Byte =        &H01 ' ISO15765 ReadMessage - type of data
    Public Const ISO15765_FF_INDICATION                           As Byte =        &H02 ' ISO15765 ReadMessage - type of data
    Public Const LINKTYPE_GENERIC_CAN                             As Byte =        &H00 ' Set_ISO15765_Link_Type argument
    Public Const LINKTYPE_J1939_ISO15765_2_ANNEX_A                As Byte =        &H01 ' Set_ISO15765_Link_Type argument
    Public Const LINKTYPE_J1939_ISO15765_3                        As Byte =        &H02 ' Set_ISO15765_Link_Type argument
    '      
    Public Const J1939_GLOBAL_ADDRESS                             As Byte =         255 ' Global address for destination specific messages.
    Public Const J1939_OFFBOARD_DIAGNOSTICS_TOOL_1                As Byte =         249 ' Offboard PC#1 address in J1939.
    Public Const J1708_OFFBOARD_DIAGNOSTICS_TOOL_1                As Byte =         172 ' Offboard PC#1 address in J1708/J1587.

    '-----------------------------------------------------------------------------------------------------
    ' RP1210 Return Definitions
    '-----------------------------------------------------------------------------------------------------
    
    Public Const NO_ERRORS                                        As Int32 =          0  '
    Public Const ERR_DLL_NOT_INITIALIZED                          As Int32 =        128  '
    Public Const ERR_INVALID_CLIENT_ID                            As Int32 =        129  '
    Public Const ERR_CLIENT_ALREADY_CONNECTED                     As Int32 =        130  '
    Public Const ERR_CLIENT_AREA_FULL                             As Int32 =        131  '
    Public Const ERR_FREE_MEMORY                                  As Int32 =        132  '
    Public Const ERR_NOT_ENOUGH_MEMORY                            As Int32 =        133  '
    Public Const ERR_INVALID_DEVICE                               As Int32 =        134  '
    Public Const ERR_DEVICE_IN_USE                                As Int32 =        135  '
    Public Const ERR_INVALID_PROTOCOL                             As Int32 =        136  '
    Public Const ERR_TX_QUEUE_FULL                                As Int32 =        137  '
    Public Const ERR_TX_QUEUE_CORRUPT                             As Int32 =        138  '
    Public Const ERR_RX_QUEUE_FULL                                As Int32 =        139  '
    Public Const ERR_RX_QUEUE_CORRUPT                             As Int32 =        140  '
    Public Const ERR_MESSAGE_TOO_LONG                             As Int32 =        141  '
    Public Const ERR_HARDWARE_NOT_RESPONDING                      As Int32 =        142  '
    Public Const ERR_COMMAND_NOT_SUPPORTED                        As Int32 =        143  '
    Public Const ERR_INVALID_COMMAND                              As Int32 =        144  '
    Public Const ERR_TXMESSAGE_STATUS                             As Int32 =        145  '
    Public Const ERR_ADDRESS_CLAIM_FAILED                         As Int32 =        146  '
    Public Const ERR_CANNOT_SET_PRIORITY                          As Int32 =        147  '
    Public Const ERR_CLIENT_DISCONNECTED                          As Int32 =        148  '
    Public Const ERR_CONNECT_NOT_ALLOWED                          As Int32 =        149  '
    Public Const ERR_CHANGE_MODE_FAILED                           As Int32 =        150  '
    Public Const ERR_BUS_OFF                                      As Int32 =        151  '
    Public Const ERR_COULD_NOT_TX_ADDRESS_CLAIMED                 As Int32 =        152  '
    Public Const ERR_ADDRESS_LOST                                 As Int32 =        153  '
    Public Const ERR_CODE_NOT_FOUND                               As Int32 =        154  '
    Public Const ERR_BLOCK_NOT_ALLOWED                            As Int32 =        155  '
    Public Const ERR_MULTIPLE_CLIENTS_CONNECTED                   As Int32 =        156  '
    Public Const ERR_ADDRESS_NEVER_CLAIMED                        As Int32 =        157  '
    Public Const ERR_WINDOW_HANDLE_REQUIRED                       As Int32 =        158  '
    Public Const ERR_MESSAGE_NOT_SENT                             As Int32 =        159  '
    Public Const ERR_MAX_NOTIFY_EXCEEDED                          As Int32 =        160  '
    Public Const ERR_MAX_FILTERS_EXCEEDED                         As Int32 =        161  '
    Public Const ERR_HARDWARE_STATUS_CHANGE                       As Int32 =        162  '
    Public Const ERR_INI_FILE_NOT_IN_WIN_DIR                      As Int32 =        202  '
    Public Const ERR_INI_SECTION_NOT_FOUND                        As Int32 =        204  '
    Public Const ERR_INI_KEY_NOT_FOUND                            As Int32 =        205  '
    Public Const ERR_INVALID_KEY_STRING                           As Int32 =        206  '
    Public Const ERR_DEVICE_NOT_SUPPORTED                         As Int32 =        207  '
    Public Const ERR_INVALID_PORT_PARAM                           As Int32 =        208  '
    Public Const ERR_COMMAND_TIMED_OUT                            As Int32 =        213  '
    Public Const ERR_OS_NOT_SUPPORTED                             As Int32 =        220  '
    Public Const ERR_COMMAND_QUEUE_IS_FULL                        As Int32 =        222  '
    Public Const ERR_CANNOT_SET_CAN_BAUDRATE                      As Int32 =        224  '
    Public Const ERR_CANNOT_CLAIM_BROADCAST_ADDRESS               As Int32 =        225  '
    Public Const ERR_OUT_OF_ADDRESS_RESOURCES                     As Int32 =        226  '
    Public Const ERR_ADDRESS_RELEASE_FAILED                       As Int32 =        227  '
    Public Const ERR_COMM_DEVICE_IN_USE                           As Int32 =        230  '
    Public Const DG_DLL_NOT_FOUND                                 As Int32 =        254  '
    Public Const DG_BUSY_SENDING                                  As Int32 =        255  '
    Public Const ERR_DATA_LINK_CONFLICT                           As Int32 =        441  '
    Public Const ERR_ADAPTER_NOT_RESPONDING                       As Int32 =        453  '
    Public Const ERR_CAN_BAUD_SET_NONSTANDARD                     As Int32 =        454  '
    Public Const ERR_MULTIPLE_CONNECTIONS_NOT_ALLOWED_NOW         As Int32 =        455  '
    Public Const ERR_J1708_BAUD_SET_NONSTANDARD                   As Int32 =        456  '
    Public Const ERR_J1939_BAUD_SET_NONSTANDARD                   As Int32 =        457  '
    Public Const ERR_ISO15765_BAUD_SET_NONSTANDARD                As Int32 =        458  '

    '------------------------------------------------------------------------------------------
    ' Import the LoadLibrary(), GetProcAddress(), and FreeLibrary() calls from Kernel32.DLL.
    ' Import the _kbhit() call from CRTDLL.DLL.
    '------------------------------------------------------------------------------------------
  
    <DllImport("kernel32.dll", CallingConvention:=CallingConvention.Winapi, CharSet:=CharSet.Ansi, PreserveSig:=True)> _
    Friend Function LoadLibrary   ( ByVal DllPath As String) As IntPtr
    End Function

    <DllImport("kernel32.dll", CallingConvention:=CallingConvention.Winapi, CharSet:=Charset.Ansi, PreserveSig:=True)> _
    Friend Function FreeLibrary   ( ByVal Handle As IntPtr ) As Integer
    End Function

    <DllImport("kernel32.dll", CallingConvention:=CallingConvention.Winapi, CharSet:=CharSet.Ansi, PreserveSig:=True)> _
    Friend Function GetProcAddress( ByVal hModule As IntPtr, ByVal lpProcName As String) As IntPtr
    End Function

    <DllImport("crtdll.dll", CallingConvention:=CallingConvention.Winapi, CharSet:=CharSet.Ansi, PreserveSig:=True)> _
    Friend Function _kbhit() As Int32
    End Function

    '--------------------------------------------------------------
    ' RP1210 Function Prototypes
    '--------------------------------------------------------------
    
    Public Delegate Function RP1210_ClientConnect      (hWnd        As Int32 , nDeviceId   As Int16 , fpchProtocol As Byte(), lTxBuf          As Int32, lRxBuf  As Int32, nIsAppPack As Int16) As Int16
    Public Delegate Function RP1210_ClientDisconnect   (nClientID   As Int16                                                                                                                 ) As Int16
    Public Delegate Function RP1210_SendMessage        (nClientID   As Int16 , fpchTxMsg   As Byte(), nMessageSize As Int16 , nNotifyStatOnTx As Int16, nBlkSnd As Int16                     ) As Int16
    Public Delegate Function RP1210_ReadMessage        (nClientID   As Int16 , fpchTxMsg   As Byte(), nBufferSize  As Int16 , nBlockOnSend    As Int16                                       ) As Int16
    Public Delegate Function RP1210_SendCommand        (nCmdNum     As Int16 , nClientID   As Int16 , fpchClCmd    As Byte(), nMessageSize    As Int16                                       ) As Int16
    Public Delegate Sub      RP1210_ReadVersion        (fpchDLLMajV As Byte(), fpchDLLMinV As Byte(), fpchAPIMajV  As Byte(), fpchAPIMinV     As Byte()                                      )'As void
    Public Delegate Function RP1210_ReadDetailedVersion(nClientID   As Int16 , fpchAPIVI   As Byte(), fpchDLLVer   As Byte(), fpchFWVerInfo   As Byte()                                      ) As Int16
    Public Delegate Function RP1210_GetHardwareStatus  (nClientID   As Int16 , fpchCInfo   As Byte(), nInfoSize    As Int16 , nBlockOnRequest As Int16                                       ) As Int16
    Public Delegate Function RP1210_GetErrorMsg        (nErrCode    As Int16 , fpchMessage As Byte()                                                                                         ) As Int16

    '------------------------------------------------------------------
    ' RP1210 Function Pointer Variables
    '------------------------------------------------------------------

    Public Dim pRP1210_ClientConnect            As RP1210_ClientConnect
    Public Dim pRP1210_ClientDisconnect         As RP1210_ClientDisconnect        
    Public Dim pRP1210_SendMessage              As RP1210_SendMessage             
    Public Dim pRP1210_ReadMessage              As RP1210_ReadMessage             
    Public Dim pRP1210_SendCommand              As RP1210_SendCommand             
    Public Dim pRP1210_ReadVersion              As RP1210_ReadVersion             
    Public Dim pRP1210_ReadDetailedVersion      As RP1210_ReadDetailedVersion     
    Public Dim pRP1210_GetHardwareStatus        As RP1210_GetHardwareStatus       
    Public Dim pRP1210_GetErrorMsg              As RP1210_GetErrorMsg             
    
    '------------------------------------------------------------------
    ' Global Variables
    '------------------------------------------------------------------

    Public Dim pDLL                             As IntPtr         = Nothing
    Public Dim iUserChosenAPI                   As Int32          = 0
    Public Dim nDeviceID                        As Int16          = 0
    Public Dim nClientIDJ1708                   As Int16          = NOT_CONNECTED
    Public Dim nClientIDJ1939                   As Int16          = NOT_CONNECTED
    Public Dim ucJ1939Address                   As Byte           = J1939_OFFBOARD_DIAGNOSTICS_TOOL_1
    Public Dim ucJ1708Address                   As Byte           = J1708_OFFBOARD_DIAGNOSTICS_TOOL_1
    Public Dim nRetVal                          As Int16          = 0
    Public Dim sUserInput                       As String         = ""
    Public Dim sbRP1210DeviceDLL                As String         = ""
    Public Dim szTemp                           As String         = ""
    Public Dim sJ1939Msg                        As sJ1939Message 
    Public Dim sJ1708Msg                        As sJ1708Message 
    Public Dim dttLastTimeRequestsSent          As DateTime
    Public Dim tsDiffInSeconds                  As TimeSpan
    '
    Public Dim baTemp                           As Byte()'500     
    Public Dim NullByteArray                    As Byte()'100
    Public Dim ucTxRxMessage                    As Byte()'2000
    '
    Public Dim abAPIVer                         As Byte()'100
    Public Dim abDLLVer                         As Byte()'100
    Public Dim abFWVer                          As Byte()'100
    Public Dim szAPIVer                         As String         = ""
    Public Dim szDLLVer                         As String         = ""
    Public Dim szFWVer                          As String         = ""
    
    '    
    '****************************************************************************************************
    '****************************************************************************************************
    ' RP1210 Section
    '****************************************************************************************************
    '****************************************************************************************************
    '

    '
    ' Load an RP1210 DLL and set up all of the function pointers.
    '
    Public Function LoadDLLAndFunctions( szDLLToLoad As String ) As Boolean

      Dim fpRP1210_ClientConnect           As IntPtr  = Nothing
      Dim fpRP1210_ClientDisconnect        As IntPtr  = Nothing
      Dim fpRP1210_SendMessage             As IntPtr  = Nothing
      Dim fpRP1210_ReadMessage             As IntPtr  = Nothing
      Dim fpRP1210_SendCommand             As IntPtr  = Nothing
      Dim fpRP1210_ReadVersion             As IntPtr  = Nothing
      Dim fpRP1210_ReadDetailedVersion     As IntPtr  = Nothing
      Dim fpRP1210_GetHardwareStatus       As IntPtr  = Nothing
      Dim fpRP1210_GetErrorMsg             As IntPtr  = Nothing
      '
      Dim bError                           As Boolean = False
      
      pDLL = LoadLibrary( szDLLToLoad )
      
      If pDLL = 0 Then
          Return False
      End If
        
      fpRP1210_ClientConnect        = GetProcAddress(pDLL, "RP1210_ClientConnect"      )      
      fpRP1210_ClientDisconnect     = GetProcAddress(pDLL, "RP1210_ClientDisconnect"   )   
      fpRP1210_SendMessage          = GetProcAddress(pDLL, "RP1210_SendMessage"        )        
      fpRP1210_ReadMessage          = GetProcAddress(pDLL, "RP1210_ReadMessage"        )        
      fpRP1210_SendCommand          = GetProcAddress(pDLL, "RP1210_SendCommand"        )        
      fpRP1210_ReadVersion          = GetProcAddress(pDLL, "RP1210_ReadVersion"        )        
      fpRP1210_ReadDetailedVersion  = GetProcAddress(pDLL, "RP1210_ReadDetailedVersion")
      fpRP1210_GetHardwareStatus    = GetProcAddress(pDLL, "RP1210_GetHardwareStatus"  )  
      fpRP1210_GetErrorMsg          = GetProcAddress(pDLL, "RP1210_GetErrorMsg"        )        
      
      If ( 0 = fpRP1210_ClientConnect       ) Then bError = True 
      If ( 0 = fpRP1210_ClientDisconnect    ) Then bError = True
      If ( 0 = fpRP1210_SendMessage         ) Then bError = True
      If ( 0 = fpRP1210_ReadMessage         ) Then bError = True
      If ( 0 = fpRP1210_SendCommand         ) Then bError = True
      If ( 0 = fpRP1210_ReadVersion         ) Then bError = True
      If ( 0 = fpRP1210_ReadDetailedVersion ) Then bError = True
      If ( 0 = fpRP1210_GetHardwareStatus   ) Then bError = True
      If ( 0 = fpRP1210_GetErrorMsg         ) Then bError = True
      
      If ( True = bError ) Then 
         Return False
      End If
      
      pRP1210_ClientConnect       = DirectCast(Marshal.GetDelegateForFunctionPointer(fpRP1210_ClientConnect       ,GetType(RP1210_ClientConnect      )),RP1210_ClientConnect       )
      pRP1210_ClientDisconnect    = DirectCast(Marshal.GetDelegateForFunctionPointer(fpRP1210_ClientDisconnect    ,GetType(RP1210_ClientDisconnect   )),RP1210_ClientDisconnect    )
      pRP1210_SendMessage         = DirectCast(Marshal.GetDelegateForFunctionPointer(fpRP1210_SendMessage         ,GetType(RP1210_SendMessage        )),RP1210_SendMessage         )
      pRP1210_ReadMessage         = DirectCast(Marshal.GetDelegateForFunctionPointer(fpRP1210_ReadMessage         ,GetType(RP1210_ReadMessage        )),RP1210_ReadMessage         )
      pRP1210_SendCommand         = DirectCast(Marshal.GetDelegateForFunctionPointer(fpRP1210_SendCommand         ,GetType(RP1210_SendCommand        )),RP1210_SendCommand         )
      pRP1210_ReadVersion         = DirectCast(Marshal.GetDelegateForFunctionPointer(fpRP1210_ReadVersion         ,GetType(RP1210_ReadVersion        )),RP1210_ReadVersion         )
      pRP1210_ReadDetailedVersion = DirectCast(Marshal.GetDelegateForFunctionPointer(fpRP1210_ReadDetailedVersion ,GetType(RP1210_ReadDetailedVersion)),RP1210_ReadDetailedVersion )
      pRP1210_GetHardwareStatus   = DirectCast(Marshal.GetDelegateForFunctionPointer(fpRP1210_GetHardwareStatus   ,GetType(RP1210_GetHardwareStatus  )),RP1210_GetHardwareStatus   )
      pRP1210_GetErrorMsg         = DirectCast(Marshal.GetDelegateForFunctionPointer(fpRP1210_GetErrorMsg         ,GetType(RP1210_GetErrorMsg        )),RP1210_GetErrorMsg         )
      
      Return True
      
    End Function 'LoadDLLAndFunctions()

    '
    ' Free the RP1210 DLL
    '
    Public Function FreeLibraryAndFunctions() As Boolean

      FreeLibrary( pDLL )

      pDLL                         = Nothing
      pRP1210_ClientConnect        = Nothing
      pRP1210_ClientDisconnect     = Nothing
      pRP1210_SendMessage          = Nothing
      pRP1210_ReadMessage          = Nothing
      pRP1210_SendCommand          = Nothing
      pRP1210_ReadVersion          = Nothing
      pRP1210_ReadDetailedVersion  = Nothing
      pRP1210_GetHardwareStatus    = Nothing
      pRP1210_GetErrorMsg          = Nothing

      Return True

    End Function'FreeLibraryAndFunctions()

    '
    ' Convert a byte array into a String variable.  
    '
    ' Calls to RP1210 of C strings (char *) must be Byte() arrays because VB and other
    ' languages do not use NULL terminated strings, they use a descriptor byte.
    '
    ' The System.Text.Encoding.ASCII.GetString( Byte() ) does not set the descriptor
    ' byte to the number of non-zero characters, so you have to do this yourself because
    ' the length attribute is read-only.  You have to iterate through the array until 
    ' a NULL character is found and append each character as you go.
    '
    Public Function ByteArrayToString( baArray As Byte(), ByRef szString As String ) As String
     
      Dim i As Integer

      szString = ""

      For i = 0 To baArray.Length Step 1

         If( baArray(i) = 0 ) Then
           Exit For
         Else
           szString = szString & Chr( baArray (i) )
         End If

      Next 'For

      Return szString

    End Function 'ByteArrayToString

    '
    ' Convert a String into a byte array.  Here the system call works fine.
    '
    Public Function StringToByteArray( szString As String, ByRef baArray As Byte() ) As Byte()

      baArray = System.Text.Encoding.ASCII.GetBytes( szString )

      Return baArray

    End Function 'StringToByteArray

    '
    ' Clear a byte array to zero.
    '
    Public Function ClearByteArray( ByRef baArray As Byte() ) As Byte()

      Array.Clear( baArray, 0, baArray.Length() )

      Return baArray

    End Function 'StringToByteArray

    ' ----------------------------------------------------------------------
    ' Unpack a two-byte integer that has been sent LSB first.
    '
    ' Note that the code does not follow the other sample code.  VB did not
    ' like X = ( Byte << x ) OR ( Byte2 << y ) ...  Each byte had to be 
    ' promoted into an unsigned short and then it could be shifted and the  
    ' result could be OR'd together.
    '
    ' ----------------------------------------------------------------------

    Public Function UnPackTwoByteIntegerLSB( ucIntString As Byte(), nStartIdx As Int16 ) As UInt16
    
      Dim usByte0      As UInt16 = 0
      Dim usByte1      As UInt16 = 0
      Dim usTot        As UInt16 = 0

      usByte0 = ucIntString(0 + nStartIdx)
      usByte1 = ucIntString(1 + nStartIdx)

      usByte0 <<=  0
      usByte1 <<=  8

      usTot = (usByte0 OR usByte1)   

      Return usTot

    End Function 'UnPackTwoByteIntegerLSB
    
    '    
    '****************************************************************************************************
    '****************************************************************************************************
    ' J1939 Section
    '****************************************************************************************************
    '****************************************************************************************************
    '

    '
    ' Structure that defines a J1939 Message.
    '
    Public Structure sJ1939Message
    
      Public nChannel              As Int16  
      Public ulTimeStamp           As UInt32 
      Public ucSourceAddress       As Byte   
      Public ucDestAddress         As Byte   
      Public ucPriority            As Byte   
      Public sHow                  As String 
      Public ulPGN                 As UInt32 
      Public ulDataLength          As UInt32 
      Public ucData                As Byte() 

    End Structure 'sJ1939Message

    '
    ' Process a received and decoded J1939 message, looking for PGN 61444 EEC1.
    '
    Public Function ProcessJ1939RxMessage( sJ1939Msg As sJ1939Message ) As Boolean
    
      Dim fEngineSpeed               As Double = 0.0
      Dim fEngineDemandPercentTorque As Double = 0.0

      Select Case ( sJ1939Msg.ulPGN )
        
          '
          ' EEC1 - Electronic Engine #1, 61444
          '
        case 61444

          Console.WriteLine()

          '
          ' SPN 190
          '
          
          fEngineSpeed =  ( UnPackTwoByteIntegerLSB( sJ1939Msg.ucData, 3 ) * 0.125 ) + 0
          
          If( ( fEngineSpeed < 0 ) Or ( fEngineSpeed > 8031.875 ) ) Then
            Console.WriteLine("( PGN 61444/SPN 190  ) EngineSpeed                              = N/A"              )
          Else
            Console.WriteLine("( PGN 61444/SPN 190  ) EngineSpeed                              = {0}", fEngineSpeed  )
          End If

          '
          ' SPN 2432
          '

          fEngineDemandPercentTorque = (sJ1939Msg.ucData(7) * 1) + (-125)

          If( (fEngineDemandPercentTorque < -125) Or (fEngineDemandPercentTorque > 125) ) Then
            Console.WriteLine("( PGN 61444/SPN 2432 ) EngineDemandPercentTorque                = N/A"                            )
          Else
            Console.WriteLine("( PGN 61444/SPN 2432 ) EngineDemandPercentTorque                = {0}", fEngineDemandPercentTorque)
          End If

          Console.WriteLine()
          
       End Select

       Return True

    End Function 'ProcessJ1939RxMessage

    '
    ' Prints a received and decoded J1939 message.
    '
    Public Function PrintJ1939RxMessage( sJ1939Msg As sJ1939Message ) As Boolean
    
      Dim i As Integer = 0

      Console.Write("Rx J1939 TS=[{0}] ", sJ1939Msg.ulTimeStamp.ToString    ("D10") )
      Console.Write("Chan=[{0}] "       , sJ1939Msg.nChannel.ToString       ("D2" ) )
      Console.Write("PGN=[{0}] "        , sJ1939Msg.ulPGN.ToString          ("D5" ) )
      Console.Write("HOW=[{0}] "        , sJ1939Msg.sHow.ToString           (     ) )
      Console.Write("PRI=[{0}] "        , sJ1939Msg.ucPriority.ToString     ("D1" ) )
      Console.Write("SRC=[{0}] "        , sJ1939Msg.ucSourceAddress.ToString("D3" ) )
      Console.Write("DST=[{0}] "        , sJ1939Msg.ucDestAddress.ToString  ("D3" ) )
      Console.Write("DL=[{0}] "         , sJ1939Msg.ulDataLength.ToString   ("D4" ) )
      Console.WriteLine()
      Console.Write("    DATA-HEX")
      
      For i = 0 To ( sJ1939Msg.ulDataLength - 1 ) Step 1
        Console.Write("[{0}]", sJ1939Msg.ucData(i).ToString("X2") )
      Next i

      Console.WriteLine("")

      Return True

    End Function 'PrintJ1939RxMessage

    '
    ' Prints a transmitted and decoded J1939 message.
    '
    Public Function PrintJ1939TxMessage( sJ1939Msg  As sJ1939Message ) As Boolean
    
      Dim i As Integer = 0

      Console.Write("Tx J1939 Chan=[{0}] "       , sJ1939Msg.nChannel.ToString       ("D2") )
      Console.Write("PGN=[{0}] "                 , sJ1939Msg.ulPGN.ToString          ("D5") )
      Console.Write("HOW=[{0}] "                 , sJ1939Msg.sHow.ToString           (    ) )
      Console.Write("PRI=[{0}] "                 , sJ1939Msg.ucPriority.ToString     ("D1") )
      Console.Write("SRC=[{0}] "                 , sJ1939Msg.ucSourceAddress.ToString("D3") )
      Console.Write("DST=[{0}] "                 , sJ1939Msg.ucDestAddress.ToString  ("D3") )
      Console.Write("DL=[{0}] "                  , sJ1939Msg.ulDataLength.ToString   ("D4") )
      Console.WriteLine()
      Console.Write("    DATA-HEX")
      
      For i = 0 To (sJ1939Msg.ulDataLength -1) Step 1
        Console.Write("[{0}]", sJ1939Msg.ucData(i).ToString("X2") )
      Next i

      Console.WriteLine("")

    End Function 'PrintJ1939TxMessage
    
    '
    ' Decodes a received J1939 message and puts it in a structure.
    '
    '
    ' Note that the code does not follow the other sample code.  VB did not
    ' like X = ( Byte << x ) OR ( Byte2 << y ) ...  Each byte had to be 
    ' promoted into an unsigned long and then it could be shifted and the  
    ' result could be OR'd together.
    '
    Public Function DecodeRxJ1939Message( ucMessage As Byte(), nMsgLen As Int16, nChannel As Int16) As sJ1939Message 
    
      Dim ulByte0      As UInt32 = 0
      Dim ulByte1      As UInt32 = 0
      Dim ulByte2      As UInt32 = 0
      Dim ulByte3      As UInt32 = 0
      Dim ulTot        As UInt32 = 0
      Dim sDecodedMsg  As sJ1939Message      = new sJ1939Message()

      sDecodedMsg.nChannel                   = nChannel

      ulByte0 = ucMessage(0)
      ulByte1 = ucMessage(1)
      ulByte2 = ucMessage(2)
      ulByte3 = ucMessage(3)

      ulByte0 <<= 24
      ulByte1 <<= 16
      ulByte2 <<=  8
      ulByte3 <<=  0

      ulTot   = (ulByte0 OR ulByte1 OR ulByte2 OR ulByte3)

      sDecodedMsg.ulTimeStamp                = ulTot

      ulByte0 = ucMessage(6)
      ulByte1 = ucMessage(5)
      ulByte2 = ucMessage(4)

      ulByte0 <<= 16
      ulByte1 <<=  8
      ulByte2 <<=  0

      ulTot   = (ulByte0 OR ulByte1 OR ulByte2)

      sDecodedMsg.ulPGN                      = ulTot

      If( ( ucMessage(7) And &H80) = &H80 ) Then
        
          sDecodedMsg.sHow                   = "BAM"

          ucMessage(9)                       = &HFF
        
      Else
        
          sDecodedMsg.sHow                   = "RTS"

      End If  

      sDecodedMsg.ucPriority                 = (ucMessage(7) And &H07)
      sDecodedMsg.ucSourceAddress            = ucMessage(8)
      sDecodedMsg.ucDestAddress              = ucMessage(9)
      sDecodedMsg.ulDataLength               = (nMsgLen - 10)

      ReDim sDecodedMsg.ucData(sDecodedMsg.ulDataLength)
      
      Array.Copy(ucMessage, 10, sDecodedMsg.ucData, 0, sDecodedMsg.ulDataLength)
      
      Return sDecodedMsg

    End Function 'DecodeRxJ1939Message

    '
    ' Decodes a transmitted J1939 message and puts it in a structure.
    '
    '
    ' Note that the code does not follow the other sample code.  VB did not
    ' like X = ( Byte << x ) OR ( Byte2 << y ) ...  Each byte had to be 
    ' promoted into an unsigned long and then it could be shifted and the  
    ' result could be OR'd together.
    '
    Public Function DecodeTxJ1939Message( ucMessage As Byte(), nMsgLen As Int16, nChannel As Int16 ) As sJ1939Message 
    
      Dim ulByte0      As UInt16 = 0
      Dim ulByte1      As UInt16 = 0
      Dim ulByte2      As UInt16 = 0
      Dim ulTot        As UInt16 = 0

      Dim sDecodedMsg As sJ1939Message       = new sJ1939Message()

      sDecodedMsg.nChannel                   = nChannel
      sDecodedMsg.ulTimeStamp                = 0

      ulByte0 = ucMessage(0)
      ulByte1 = ucMessage(1)
      ulByte2 = ucMessage(2)

      ulByte0 <<=  0
      ulByte1 <<=  8
      ulByte2 <<= 16

      sDecodedMsg.ulPGN                      = (ulByte2 OR ulByte0 OR ulByte1)   

      If( ( ucMessage(3) And &H80) = &H80 )
        
          sDecodedMsg.sHow                   = "BAM"
        
      Else
        
          sDecodedMsg.sHow                   = "RTS"
        
      End If

      sDecodedMsg.ucPriority                 = (ucMessage(3) And &H07)

      sDecodedMsg.ucSourceAddress            = ucMessage(4)
      sDecodedMsg.ucDestAddress              = ucMessage(5)
      sDecodedMsg.ulDataLength               = (nMsgLen - 6)

      ReDim sDecodedMsg.ucData(sDecodedMsg.ulDataLength)
      
      Array.Copy(ucMessage, 6, sDecodedMsg.ucData, 0, sDecodedMsg.ulDataLength)
      
      Return sDecodedMsg

    End Function 'DecodeTxJ1939Message

    '
    ' This shows how to claim a J1939 address.
    '
    Public Function ClaimJ1939Address(nClientID As Int16, ucJ1939Address As Byte) As Boolean 
    
      Dim    nRetVal              As Int16
      Dim    ucTxRxBuffer         As Byte() = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0    }
      Dim    ucJ1939Name          As Byte() = { &H00, &H00, &H60, &H01, &H00, &H81, &H00, &H00 }

      ' J1939 "NAME" for this sample source code application ( see J1939/81 )
      '    Self Configurable       =   0 = NO
      '    Industry Group          =   0 = GLOBAL
      '    Vehicle System          =   0 = Non-Specific
      '    Vehicle System Instance =   0 = First Diagnostic PC
      '    Reserved                =   0 = Must be zero
      '    Function                = 129 = Offboard Service Tool
      '    Function Instance       =   0 = First Offboard Service Tool
      '    Manufacturer Code       =  11 = Dearborn Group, Inc. 
      '    Manufacturer Identity   =   0 = Dearborn Group, Inc. Sample Source Code
      
      ucTxRxBuffer(0) = ucJ1939Address
      ucTxRxBuffer(1) = ucJ1939Name(0)
      ucTxRxBuffer(2) = ucJ1939Name(1)
      ucTxRxBuffer(3) = ucJ1939Name(2)
      ucTxRxBuffer(4) = ucJ1939Name(3)
      ucTxRxBuffer(5) = ucJ1939Name(4)
      ucTxRxBuffer(6) = ucJ1939Name(5)
      ucTxRxBuffer(7) = ucJ1939Name(6)
      ucTxRxBuffer(8) = ucJ1939Name(7)
      ucTxRxBuffer(9) = BLOCK_UNTIL_DONE

      nRetVal = pRP1210_SendCommand( RP1210_Protect_J1939_Address, nClientID, ucTxRxBuffer, 10 )
      
      If( nRetVal = 0 ) Then
        
          Return True
        
      Else
        
          Return False

      End If

    End Function 'ClaimJ1939Address

    '
    ' This shows how to send a J1939 message.  It sends the request PGN 59904 asking for iRequestedPGN.
    '
    Public Function SendJ1939RequestPGN( nClientID as Int16, ucSourceAddress As Byte, ucAddressRequestedFrom As Byte, iRequestedPGN As UInt32 ) As Boolean
    
      Dim iPGN                As Int32  = 59904
      Dim nRetVal             As Int16  = -1
      Dim nDataBytes          As Int16  = -1
      Dim ucTxRxBuffer        As Byte() = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0    }
      Dim sJ1939Msg           As sJ1939Message

      iPGN            = 59904                                     ' Request PGN
      ucTxRxBuffer(0) = ( (iPGN AND &H000000FF) >> 0   )          ' Byte 0 - LSB, Lo byte of PGN
      ucTxRxBuffer(1) = ( (iPGN AND &H0000FF00) >> 8   )          ' Byte 1 - LSB, Mid byte of PGN
      ucTxRxBuffer(2) = ( (iPGN AND &H00FF0000) >> 16  )          ' Byte 2 - LSB, Hi byte of PGN
      ucTxRxBuffer(3) = 0                                         ' 0 = RTS/CTS, 1 = BAM
      ucTxRxBuffer(3) = ucTxRxBuffer(3) << 7                      ' Shift RTS/CTS/BAM to highest bit
      ucTxRxBuffer(3) = ucTxRxBuffer(3) OR 6                      ' OR in the priority
      ucTxRxBuffer(4) = ucSourceAddress                           ' Source Address
      ucTxRxBuffer(5) = ucAddressRequestedFrom                    ' Who we want to respond
      ucTxRxBuffer(6) = ( (iRequestedPGN AND &H000000FF) >> 0   ) ' Byte 0 - LSB, Lo byte of requested PGN
      ucTxRxBuffer(7) = ( (iRequestedPGN AND &H0000FF00) >> 8   ) ' Byte 1 - LSB, Mid byte of requested PGN
      ucTxRxBuffer(8) = ( (iRequestedPGN AND &H00FF0000) >> 16  ) ' Byte 2 - LSB, Hi byte of requested PGN
  
      nDataBytes = 9
      
      nRetVal = pRP1210_SendMessage( nClientID, ucTxRxBuffer, nDataBytes, 0, NON_BLOCKING_IO )
      
      If( nRetVal <> 0 ) Then
        
          Return False
        
      Else
        
          sJ1939Msg = DecodeTxJ1939Message( ucTxRxBuffer, nDataBytes, nClientID )

          PrintJ1939TxMessage( sJ1939Msg )

          Return True

      End If
        

    End Function 'SendJ1939RequestPGN

    '
    '****************************************************************************************************
    '****************************************************************************************************
    ' J1708 Section
    '****************************************************************************************************
    '****************************************************************************************************
    '

    '
    ' Defines a J1708 Message
    '
    Public Structure sJ1708Message
    
      public nChannel        As Int16  
      public ulTimeStamp     As UInt32       
      public ucMID           As Byte         
      public ulDataLength    As UInt32       
      public ucData          As Byte()       
      public ucPriority      As Byte          
    
    End Structure 'sJ1708Message

    '
    ' Process a received and decoded J1708 message, looking for PID 190 (Engine Speed).
    '
    Public Function ProcessJ1708RxMessage(  sJ1708Msg As sJ1708Message ) As Boolean
    
      Dim  fEngineSpeed               As Double = 0.0
      Dim  ucPID                      As Byte   = 0

      ucPID = sJ1708Msg.ucData(0)
     
      Select Case( ucPID )
        
          '
          ' 190 - Engine Speed
          '
        Case 190

          Console.WriteLine()

          fEngineSpeed =  ( UnPackTwoByteIntegerLSB( sJ1708Msg.ucData, 1 ) * 0.25 ) + 0
          
          Console.WriteLine("( SPN 190  ) EngineSpeed                              = {0}", fEngineSpeed)

          Console.WriteLine(  )
          
      End Select

      Return True

    End Function 'ProcessJ1708RxMessage

    '
    ' Prints a received and decoded J1708 message.
    '
    Public Function PrintJ1708RxMessage( sJ1708Msg As sJ1708Message ) As Boolean

      Dim i As Integer = 0
    
      Console.Write("Rx J1708 TS=[{0}] ", sJ1708Msg.ulTimeStamp.ToString ("D10") )
      Console.Write("Chan=[{0}] "       , sJ1708Msg.nChannel.ToString    ("D2" ) )
      Console.Write("MID=[{0}] "        , sJ1708Msg.ucMID.ToString       ("D3" ) )
      Console.Write("DL=[{0}] "         , sJ1708Msg.ulDataLength.ToString("D4" ) )
      Console.WriteLine()
      Console.Write("    DATA-HEX")
      
      For  i = 0 To ( sJ1708Msg.ulDataLength - 1) Step 1
        Console.Write("[{0}]", sJ1708Msg.ucData(i).ToString("X2") )
      Next i

      Console.WriteLine("")

      Return True

    End Function 'PrintJ1708RxMessage

    '
    ' Prints a transmitted and decoded J1708 message.
    '
    Public Function PrintJ1708TxMessage( sJ1708Msg As sJ1708Message ) As Boolean
    
      Dim i As Integer = 0

      Console.Write("Tx J1708 Chan=[{0}] ", sJ1708Msg.nChannel.ToString    ("D2" ) )
      Console.Write("PRI=[{0}] "          , sJ1708Msg.ucPriority.ToString  ("D3" ) )
      Console.Write("MID=[{0}] "          , sJ1708Msg.ucMID.ToString       ("D3" ) )
      Console.Write("DL=[{0}] "           , sJ1708Msg.ulDataLength.ToString("D4" ) )
      Console.WriteLine()
      Console.Write("    DATA-HEX")
      
      For  i = 0 To ( sJ1708Msg.ulDataLength - 1) Step 1
        Console.Write("[{0}]", sJ1708Msg.ucData(i).ToString("X2") )
      Next i
      
      Console.WriteLine("")

      Return True

    End Function 'PrintJ1708TxMessage

    '
    ' Decodes a received J1708 message and puts it in a structure.
    '
    '
    ' Note that the code does not follow the other sample code.  VB did not
    ' like X = ( Byte << x ) OR ( Byte2 << y ) ...  Each byte had to be 
    ' promoted into an unsigned long and then it could be shifted and the  
    ' result could be OR'd together.
    '
    Public Function DecodeRxJ1708Message( ucMessage As Byte(), nMsgLen as Int16, nChannel As Int16 ) As sJ1708Message 
    
      Dim sDecodedMsg As sJ1708Message       = new sJ1708Message()
      Dim ulByte0      As UInt32 = 0
      Dim ulByte1      As UInt32 = 0
      Dim ulByte2      As UInt32 = 0
      Dim ulByte3      As UInt32 = 0
      Dim ulTot        As UInt32 = 0
      
      sDecodedMsg.ucPriority                 = 0
      sDecodedMsg.nChannel                   = nChannel

      ulByte0 = ucMessage(0)
      ulByte1 = ucMessage(1)
      ulByte2 = ucMessage(2)
      ulByte3 = ucMessage(3)

      ulByte0 <<= 24
      ulByte1 <<= 16
      ulByte2 <<=  8
      ulByte3 <<=  0

      ulTot   = (ulByte0 OR ulByte1 OR ulByte2 OR ulByte3)

      sDecodedMsg.ulTimeStamp                = ulTot

      sDecodedMsg.ucMID                      = ucMessage(4)
      sDecodedMsg.ulDataLength               = (nMsgLen - 5)

      ReDim sDecodedMsg.ucData(sDecodedMsg.ulDataLength)
      
      Array.Copy(ucMessage, 5, sDecodedMsg.ucData, 0, sDecodedMsg.ulDataLength)
      
      return sDecodedMsg

    End Function 'DecodeRxJ1708Message

    '
    ' Decodes a transmitted J1708 message and puts it in a structure.
    '
    Public Function DecodeTxJ1708Message( ucMessage As Byte(), nMsgLen as Int16, nChannel As Int16 ) As sJ1708Message 
    
      Dim sDecodedMsg As sJ1708Message           = new sJ1708Message()

      sDecodedMsg.nChannel                   = nChannel
      sDecodedMsg.ulTimeStamp                = 0
      sDecodedMsg.ucPriority                 = ucMessage(0)
      sDecodedMsg.ucMID                      = ucMessage(1)
      sDecodedMsg.ulDataLength               = (nMsgLen - 2)
      
      ReDim sDecodedMsg.ucData(sDecodedMsg.ulDataLength)

      Array.Copy(ucMessage, 2, sDecodedMsg.ucData, 0, sDecodedMsg.ulDataLength)
      
      return sDecodedMsg

    End Function 'DecodeTxJ1708Message

    '
    ' This shows how to send a J1708 message.  It sends the request PID (0) asking for ucRequestedPID.
    '
    Public Function SendJ1708RequestPID( nClientID As Int16, ucSourceAddress As Byte, ucRequestedPID As Byte ) As Boolean
    
      Dim nRetVal             As Int16 = -1
      Dim nDataBytes          As Int16 = -1
      Dim sJ1708Msg           As sJ1708Message
      Dim ucTxRxBuffer        As Byte() = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0    }

      ucTxRxBuffer(0) = 8                ' Lowest Priority
      ucTxRxBuffer(1) = ucSourceAddress  ' Source Address
      ucTxRxBuffer(2) = &H00             ' Request PID
      ucTxRxBuffer(3) = ucRequestedPID   ' Requested PID
      nDataBytes      = 4

      nRetVal = pRP1210_SendMessage( nClientID, ucTxRxBuffer, nDataBytes, 0, NON_BLOCKING_IO)
      
      If ( nRetVal <> 0 ) Then
        
          return false
        
      Else
        
          sJ1708Msg = DecodeTxJ1708Message( ucTxRxBuffer, nDataBytes, nClientID )

          PrintJ1708TxMessage( sJ1708Msg )

      End If

      Return True
       
    End Function 'SendJ1708RequestPID

    '
    '====================================================================================================
    '====================================================================================================
    ' main()
    '====================================================================================================
    '====================================================================================================
    '
    Sub Main()

       '
       ' VB won't let you declare a simple byte array of x bytes, so you declare it and then ReDim it.
       '
       ReDim baTemp          (500)
       ReDim abAPIVer        (100)
       ReDim abDLLVer        (100)
       ReDim abFWVer         (100)
       ReDim NullByteArray   (100)
       ReDim ucTxRxMessage  (2000)

       '
       ' Clear the byte arrays being used.
       '
       ClearByteArray( baTemp        )
       ClearByteArray( abAPIVer      )
       ClearByteArray( abDLLVer      )
       ClearByteArray( abFWVer       )
       ClearByteArray( NullByteArray )
       ClearByteArray( ucTxRxMessage )

       Console.WriteLine(PROGRAM_ID)

       '
       ' Have the user select the adapter they want to use and set sbRP1210DeviceDLL.
       '
       do 
        
          Console.WriteLine( "                                                                       " )
          Console.WriteLine( "---------------------------------------------------------------------- " )
          Console.WriteLine( " Select Adapter To Use                                                 " )
          Console.WriteLine( "---------------------------------------------------------------------- " )
          Console.WriteLine( "                                                                       " )
          Console.WriteLine( " 1 = DPA 5      Multi-Application           ( DLL Name = DGDPA5MA.DLL )" )
          Console.WriteLine( " 2 = DPA 4 Plus Multi-Application           ( DLL Name =  DPA4PMA.DLL )" )
          Console.WriteLine( " 3 = DPA 4 Plus And Prior DPAs              ( DLL Name = DG121032.DLL )" )
          Console.WriteLine( " 4 = Allison DR Drivers (DPA 4 Plus/DPA 5 ) ( DLL Name = DR121032.DLL )" )
          Console.WriteLine( " 5 = d-briDGe   Multi-Application           ( DLL Name = DBRIDGEM.DLL )" )
          Console.WriteLine( " 6 = Netbridge  Multi-Application           ( DLL Name = NBRIDGEM.DLL )" )
          Console.WriteLine( "                                                                       " )
          Console.Write    ( "->  " )
          
          sUserInput = Console.ReadLine()

          If Len( sUserInput ) > 0
            
              iUserChosenAPI = Convert.ToInt32( sUserInput )
              
              Select Case ( iUserChosenAPI )
                
                case 1 
                   sbRP1210DeviceDLL = "DGDPA5MA.DLL"
                   Exit Do
                case 2 
                   sbRP1210DeviceDLL = "DPA4PMA.DLL"  
                   Exit Do
                case 3 
                   sbRP1210DeviceDLL = "DG121032.DLL"
                   Exit Do
                case 4 
                   sbRP1210DeviceDLL = "DR121032.DLL"
                   Exit Do
                case 5 
                   sbRP1210DeviceDLL = "DBRIDGEM.DLL"
                   Exit Do
                case 6 
                   sbRP1210DeviceDLL = "NBRIDGEM.DLL"
                   Exit Do
                
              End Select

          End If
          
       Loop 'Do

       '
       ' Attempt loading the DLL and setting all of the function pointers.
       '
       If( False = LoadDLLAndFunctions( sbRP1210DeviceDLL ) ) Then
        
          Console.WriteLine( "FAILURE loading DLL [{0}].", sbRP1210DeviceDLL )

          End

       End If

       '
       ' Have the user select the device number that they want to connect to.
       '
       do
        
          Console.WriteLine( "                                                                      " )
          Console.WriteLine( "--------------------------------------------------------------------- " )
          Console.WriteLine( " Select Device To Use                                                 " )
          Console.WriteLine( "--------------------------------------------------------------------- " )
          Console.WriteLine( "                                                                      " )
          
          If( ( iUserChosenAPI = 1 ) ) Then
             
              Console.WriteLine( " Common DPA 5 Multi-Application Devices                           " )
              Console.WriteLine( "       1 =  DPA 5 - USB                                           " )
            
          ElseIf(      ( iUserChosenAPI = 2 ) ) Then
             
              Console.WriteLine( " Common DPA 4 Plus Multi-Application Devices                      " )
              Console.WriteLine( "     1   =  DPA 4 Plus - USB                                      " )
            
          ElseIf( ( iUserChosenAPI = 3) ) Then
             
              Console.WriteLine( " Common DG121032.ini Devices                                      " )
              Console.WriteLine( "     150 =  DPA 4/4 Plus USB                                      " )
              Console.WriteLine( "     101 =  DPA II/II+/III+ Serial Using COM1                     " )
              Console.WriteLine( "     102 =  DPA II/II+/III+ Serial Using COM2                     " )
            
          ElseIf( ( iUserChosenAPI = 4 ) ) Then
             
              Console.WriteLine( " Common DR121032.ini Devices                                      " )
              Console.WriteLine( "     150 =  DPA 4 USB                                             " )
              Console.WriteLine( "     151 =  DPA 4 Plus USB and DPA 5 USB                          " )
            
          ElseIf( ( iUserChosenAPI = 5 ) ) Then
             
              Console.WriteLine( " Common DBRIDGEM.ini Devices                                      " )
              Console.WriteLine( "       3 = d-briDGe                                               " )
            
          ElseIf( ( iUserChosenAPI = 6 ) ) Then
             
              Console.WriteLine( " Common NBRIDGEM.ini Devices                                      " )
              Console.WriteLine( "       2 = Netbridge                                              " )
          End If
          
          Console.WriteLine( "                                                                      " )
          Console.WriteLine( " These are the most common DG devices based on the DLL selected.      " )
          Console.WriteLine( " Other device numbers may exist in that INI file such as Bluetooth    " )
          Console.WriteLine( " entries for the DPA 5 ( beginning at 160 ).                          " )
          Console.WriteLine( "                                                                      " )
          Console.WriteLine( " Please enter the device number you would like to use.                " )
          Console.WriteLine( "                                                                      " )
          Console.Write    ( "->  " )
          
          sUserInput = Console.ReadLine()
          
          If ( Len( sUserInput ) > 0  ) Then
            
              nDeviceID = Convert.ToInt16( sUserInput )
              
              If( nDeviceID > 0 ) Then
                Exit Do
              End If

          End If

       Loop 'Do

       '
       ' Attempt connect to J1939 protocol and then claiming J1939 address if successful.
       '
       nClientIDJ1939 = pRP1210_ClientConnect( 0, nDeviceID, StringToByteArray("J1939",baTemp), 512*1024, 512*1024, 0)

       If( ( nClientIDJ1939 >= 0 ) And ( nClientIDJ1939 <= 127 ) ) Then
        
          Console.WriteLine( "SUCCESS - RP1210_ClientConnect( J1939 ) to DeviceID [{0}]", nDeviceID.ToString() )

          If( False = ClaimJ1939Address( nClientIDJ1939, ucJ1939Address) ) Then
          
             Console.WriteLine( "WARNING - Cannot claim J1939 address [{0}].", ucJ1939Address.ToString() )
          
          End If
        
       Else
        
          Console.WriteLine( "FAILURE - RP1210_ClientConnect( J1939 ) to DeviceID [{0}]", nDeviceID.ToString() )

          pRP1210_ClientDisconnect(nClientIDJ1939)
          
          FreeLibraryAndFunctions()

          End
          
       End If

       '
       ' Attempt to connect to J1708 protocol.  
       '
       nClientIDJ1708 = pRP1210_ClientConnect(IntPtr.Zero, nDeviceID, StringToByteArray("J1708", baTemp), 512*1024, 512*1024, 0)

       If ( ( nClientIDJ1708 >= 0 ) And ( nClientIDJ1708 <= 127 ) ) Then
        
          Console.WriteLine( "SUCCESS - RP1210_ClientConnect( J1708 ) to DeviceID [{0}]", nDeviceID.ToString() )
        
       Else
        
          Console.WriteLine( "FAILURE - RP1210_ClientConnect( J1708 ) to DeviceID [{0}]", nDeviceID.ToString() )

          pRP1210_ClientDisconnect(nClientIDJ1708)
          
          FreeLibraryAndFunctions()

          End
          
       End If  
      
       '
       ' Read the detailed version information about the DLL and adapter and write it to the screen.
       '
       nRetVal = pRP1210_ReadDetailedVersion( nClientIDJ1939, abAPIVer, abDLLVer, abFWVer )
       
       If( nRetVal <> 0 ) Then
         
           Console.WriteLine( "FAILURE - RP1210_ReadDetailedVersion() returned ({0}).", nRetVal.ToString() )
         
       else
         
           szAPIVer =  ByteArrayToString( abAPIVer, szAPIVer  )
           szDLLVer =  ByteArrayToString( abDLLVer, szDLLVer  )
           szFWVer  =  ByteArrayToString( abFWVer , szFWVer   )

           Console.WriteLine("SUCCESS - RP1210_ReadDetailedVersion:  API({0}) DLL({1}) FW({2})", szAPIVer, szDLLVer, szFWVer)
 
       End If
       
       '
       ' Set all filter states to pass on J1939 so we can read messages.
       '
       nRetVal = pRP1210_SendCommand(RP1210_Set_All_Filters_States_to_Pass, nClientIDJ1939, NullByteArray, 0)
 
       If( nRetVal <> 0 ) Then
         
           Console.WriteLine( "FAILURE - RP1210_Set_All_Filters_States_to_Pass( J1939 )")
         
       else
         
           Console.WriteLine( "SUCCESS - RP1210_Set_All_Filters_States_to_Pass( J1939 )")
 
       End If
 
       '
       ' Set all filter states to pass on J1708 so we can read messages.
       '
       nRetVal = pRP1210_SendCommand(RP1210_Set_All_Filters_States_to_Pass, nClientIDJ1708, NullByteArray, 0)
 
       If( nRetVal <> 0 ) Then
         
           Console.WriteLine( "FAILURE - RP1210_Set_All_Filters_States_to_Pass( J1708 )")
         
       Else
         
           Console.WriteLine( "SUCCESS - RP1210_Set_All_Filters_States_to_Pass( J1708 )")
       End If
       
       '
       ' Let the user know how to exit the program.
       '
       Console.WriteLine( "---------------------------------------------------------------------" )
       Console.WriteLine( " Ready to begin.  Press ""Enter"" to start, any key exits program.   " )
       Console.WriteLine( "            Press ""Ctrl-S"" to freeze the screen.                   " )
       Console.WriteLine( "---------------------------------------------------------------------" )
       Console.Write    ( ">" )
       
       sUserInput = Console.ReadLine()
       
       '
       ' Get the time now.
       '
       dttLastTimeRequestsSent = DateTime.Now
 
       '
       ' Forever.  Read/process messages until a ERR_HARDWARE_NOT_RESPONDING or a keystroke.
       '
       do
           '
           ' Get the time now and see if it has been over 5 seconds.
           '
           tsDiffInSeconds = DateTime.Now - dttLastTimeRequestsSent
           
           if( tsDiffInSeconds.Seconds > 5 ) Then
               '
               ' Request the VIN from the J1939 (global address) and J1708/J1587 network.
               '
               SendJ1939RequestPGN( nClientIDJ1939, ucJ1939Address, 255, 65260 ) ' VIN request.
               SendJ1708RequestPID( nClientIDJ1708, ucJ1708Address,        237 ) ' VIN request.
 
               dttLastTimeRequestsSent = DateTime.Now
 
           End If

           ' 
           ' Clear out the buffer.
           ' 
           ClearByteArray( ucTxRxMessage )

           '
           ' Read a J1939 message and print it to the screen if a message is available.
           '
           nRetVal = pRP1210_ReadMessage( nClientIDJ1939, ucTxRxMessage, 2000, 0)
 
           If( nRetVal = -(ERR_HARDWARE_NOT_RESPONDING) ) Then 
 
             Exit Do
 
           End If
           
           If( nRetVal > 0 ) Then
             
               sJ1939Msg = DecodeRxJ1939Message( ucTxRxMessage, nRetVal, nClientIDJ1939 )
 
               PrintJ1939RxMessage  ( sJ1939Msg )
 
               ProcessJ1939RxMessage( sJ1939Msg )
 
           End If
 
           ' 
           ' Clear out the buffer.
           ' 
           ClearByteArray( ucTxRxMessage )

           '
           ' Read a J1708 message and print it to the screen if a message is available.
           '
           nRetVal = pRP1210_ReadMessage(nClientIDJ1708, ucTxRxMessage, 2000, 0)
 
           if( nRetVal = -(ERR_HARDWARE_NOT_RESPONDING) )
 
             Exit Do
 
           End If
 
           If( nRetVal > 0 ) Then
             
               sJ1708Msg = DecodeRxJ1708Message( ucTxRxMessage, nRetVal, nClientIDJ1708 )
               
               PrintJ1708RxMessage  ( sJ1708Msg )
 
               ProcessJ1708RxMessage( sJ1708Msg )
 
           End If
 
           '
           ' If a key is pressed, exit cleanly.
           '
           If( _kbhit() <> 0 ) Then
 
             Exit Do
 
           End If
           
       Loop 'Do 
       
       '
       ' Disconnect and free the DLL.
       '
       pRP1210_ClientDisconnect(nClientIDJ1939)
       pRP1210_ClientDisconnect(nClientIDJ1708)
       FreeLibraryAndFunctions()

       '
       ' Return to the operating system.
       '
       End

    End Sub 'main()

End Module 'VBRP1210SampleSource
