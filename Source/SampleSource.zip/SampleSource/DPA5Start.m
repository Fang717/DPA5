% Example Matlab script program for DPA5 J2534 interface.
% The function DPA5Start loads the DPA5 Windows library that implements the SAE J2534
% API interface. The calls here open the connection to the DPA5 device, start the CAN
% protocol interface, and setup an "all pass" filter to read all CAN messages.
% 
% When using USB, the following registry entry
% HKEY_LOCAL_MACHINE\SOFTWARE\PassThruSupport 04.04\DPA5\DeviceId
% must be set to 1. When using Bluetooth, the registery entry must be sent to the
% bluetooth device id, for example "160". This "manual" setting of this registery
% entry will be automated in the full release of the DPA5 software.
% DPA 5 software needs to be installed, and DPA5 need to be plugged into USB and
% showing up in the Device Manager list, or bluetooth interface uses the COM port.
% ***************************************************************************************
% Version 1.2 of 2013-05-01 markc added comments
% Version 1.1 of 2011-01-24 markc added checks for errors
% Version 1.0 of 2011-01-21 markc initial open-connect-filter-read working
% ***************************************************************************************
% Copyright (C) 2011 DG Technologies, Inc. All Rights Reserved.
% The copyright notice here does not evidence any actual or intended publication.
% This code is provided "as-is".
% No claims are made concerning suitability for any given purpose.
% ***************************************************************************************

if not(libisloaded('DGDPA532'))
  hfile = ['C:\Dearborn Group Products\DPA 5 J2534\j2534.h']
  loadlibrary('DGDPA532', hfile);
end

libfunctionsview('DGDPA532')

error = 'J2534_STATUS_NOERROR'
ulDeviceID = 0
dummy = 0
[error,dummy, ulDeviceID] = calllib('DGDPA532', 'PassThruOpen', 0, ulDeviceID)
if not(strcmp(error,'J2534_STATUS_NOERROR'))
	return
end

hw_string = ''
fw_string = ''
sw_string = ''
[error, hw_string, fw_string, sw_string] = calllib('DGDPA532', 'PassThruReadVersion', ulDeviceID, hw_string, fw_string, sw_string)
if not(strcmp(error,'J2534_STATUS_NOERROR'))
	return
end

nProtocol = 5
flags = 0
baud = 500000
ulChannelID = 0
[error, ulChannelID] = calllib('DGDPA532', 'PassThruConnect', ulDeviceID, nProtocol, flags, baud, ulChannelID)
if not(strcmp(error,'J2534_STATUS_NOERROR'))
	return
end

% pass filter
ulFilterID = 0
filter = 1

% In order to read a message, you first must create a message filter
% because the default is to block all messages.
% The following filter passes all messages.
%
% setup a pattern of 00 00 00 00, this will pass everything
%
% 		PATTERN 	MASK		RESULT
% Pass Filter	00 00 07 e0	00 00 00 00	pass all
% Pass Filter	00 00 07 e0	ff ff ff ff	pass only 07e0
% Block Filter	00 00 07 e0	ff ff ff ff	block only 07e0
% Block Filter	00 00 07 e0	00 00 00 00	block everything
%
Pattern= libstruct('PASSTHRU_MSG');
Pattern.ucData(4128) = 0
Pattern.ulDataSize = 4
Pattern.ulProtocolID = nProtocol

Mask = libstruct('PASSTHRU_MSG');
Mask.ucData(4128) = 0
Mask.ulDataSize = 4
Mask.ulProtocolID = nProtocol

% NULL pointer
FC = libstruct('PASSTHRU_MSG');

%[error, Pattern, Mask, FC, ulFilterID] = calllib('DGDPA532', 'PassThruStartMsgFilter', ulChannelID, filter, Pattern, Mask, 0, ulFilterID)
[error, Pattern, Mask, FC, ulFilterID] = calllib('DGDPA532', 'PassThruStartMsgFilter', ulChannelID, filter, Pattern, Mask, FC, ulFilterID)
if not(strcmp(error,'J2534_STATUS_NOERROR'))
	return
end


Msg(1) = libstruct('PASSTHRU_MSG');
Msg(1).ucData(12) = 0
Msg(1).ulProtocolID = nProtocol


% set the number of message to read
ulNum = 1
% set 500ms timeout
ulTimeout = 500 
[error, Msg(1), ulNum] = calllib('DGDPA532', 'PassThruReadMsgs', ulChannelID, Msg(1), ulNum, ulTimeout)
if not(strcmp(error,'J2534_STATUS_NOERROR'))
	if (strcmp(error,'J2534_ERR_BUFFER_OVERFLOW'))
		format hex
		Msg(1).ucData
	else
		return
	end
else
	format hex
	Msg(1).ucData
end
