% Example Matlab script program for DPA5 J2534 interface.
% The function DPA5_PassThruReadMsgs reads a message from CAN.
% You must run script DPA5Start before running this script.
% 
% ***************************************************************************************
% Version 1.2 of 2013-05-01 markc added comments
% Version 1.1 of 2011-01-28 markc renamed script
% Version 1.0 of 2011-01-24 markc initial
% ***************************************************************************************
% Copyright (C) 2011 DG Technologies, Inc. All Rights Reserved.
% The copyright notice here does not evidence any actual or intended publication.
% This code is provided "as-is".
% No claims are made concerning suitability for any given purpose.
% ***************************************************************************************

if not(libisloaded('DGDPA532'))
	return
end

% Note: to read more than 1 message at a time,
% we need to change this to pass in an array of structs
Msg(1) = libstruct('PASSTHRU_MSG');
Msg(1).ucData(12) = 0
Msg(1).ulProtocolID = nProtocol


% set the number of message to read
ulNum = 1
% set 500ms timeout
ulTimeout = 500 
[error, Msg(1), ulNum] = calllib('DGDPA532', 'PassThruReadMsgs', ulChannelID, Msg(1), ulNum, ulTimeout)
if not(strcmp(error,'J2534_STATUS_NOERROR'))
	if (strcmp(error,'J2534_ERR_BUFFER_OVERFLOW'))
		format hex
		Msg(1).ucData
	else
		return
	end
else
	format hex
	Msg(1).ucData
end
