﻿// ----------------------------------------------------------------------------------------------------
//  DG Technologies - RP1210 Sample Source Code C# - Copyright (c) 2014 - Dearborn Group, Inc.
// ----------------------------------------------------------------------------------------------------
// 
//  Name:           RP1210SampleCodeCSharp.cs  Version 1.00
// 
//  Date:           February 15, 2014
// 
//  Written By:     Kenneth L. DeGrant II
//                  Field Applications Engineering Manager
//                  TMC RP1210 Task Force Chairman
//                  DG Technologies
//                  33604 West 8 Mile Road
//                  Farmington Hills, MI  48335
//                  kdegrant@dgtech.com
// 
//  Description:    This code is provided by Dearborn Group, Inc (herein referred to as 
//                  "DG Technologies" or "DG") to assist application developers in developing 
//                  RP1210 applications DG family of RP1210 products.  It shows how to connect
//                  to DG RP1210 devices and the J1708/J1587, and J1939 protocols.  This code 
//                  demonstrates all computer science fundamentals (open, read, write, close) 
//                  necessary to communicate with vehicle components on these networks.  It 
//                  also shows how to decode numeric data sent by these protocols in Little Endian
//                  or Least Significant Byte first (LSB) form and then translate that data into
//                  actual engineering values.  
//
//  Special Thanks: Special thanks goes out to Bryan Hunt of Zonar Systems, Ted Musto from 
//                  C. E. Niehoff, and Leo Kominek of Eaton Corporation.  This code began as 
//                  Bryan's C# wrapper for RP1210.  Ted and Leo were very helpful in getting 
//                  the initial version of this code to work.  Thanks guys!
//
//  Advanced:       The program decodes several parameters from the J1939 message EEC1 (PGN 61444)
//                  including engine speed, and prints the engineering value to the screen.  The program
//                  also decodes J1708/J1587 PID 190 Engine Speed and prints that engineerig value to the
//                  screen as well.
//
// Code Notes:      All necessary code for this project is in this file.  Because this program
//                  runs on a DOS command prompt, it can be readily adapted to do any basic 
//                  functionality that a developer unfamiliar with RP1210 might want to do, and without
//                  having to look at complex MFC, Visual Basic, C#, or other "GUI" code.  
//
//  Requirements:   This program requires that you have downloaded and installed the latest RP1210 
//                  drivers for one of the following products:
//
//                     * DPA 4 Plus Multi-Application           ( DLL Name =  DPA4PMA.DLL )
//                     * DPA 5      Multi-Application           ( DLL Name = DGDPA5MA.DLL )
//                     * DPA 4 Plus And Prior DPAs              ( DLL Name = DG121032.DLL )
//                     * Allison DR Drivers (DPA 4 Plus/DPA 5 ) ( DLL Name = DR121032.DLL )
//                     * D-briDGe   Multi-Application           ( DLL Name = DBRIDGEM.DLL )
//                     * Netbridge  Multi-Application           ( DLL Name = NBRIDGEM.DLL )
//
//                  Drivers are available from the DG Technologies website as follows:
//
//                               http://www.dgtech.com/download.php
//
//  No Liability:   This code is example code and is NOT warranted to be fit for any particular use 
//                  or purpose.  DG Technologies will not be held liable for any use or 
//                  misuse of this code "under any circumstances whatsoever".  
// 
//  Notes:          Be sure to have your DOS command prompt set to a width of at least 150, as the 
//                  program displays about 140 contiguous characters from a J1939 message.
// 
//                  It is possible to develop a completely RP1210 A/B/C/D compliant application that
//                  will not connect, send or read messages to or from a particular databus.  
//                  To ensure success, please read the documentation for the protocol you want to use 
//                  thoroughly along with reading the "complete" RP1210 document before trying to 
//                  adapt this code to a particular purpose.
//
//  Copyright:      This code is copyrighted by Dearborn Group, Inc., and is intended
//                  solely for the use of our DPA customers or potential DPA customers.  No portion,
//                  including "snippets" of this code are to be used, investigated, or copied in any 
//                  shape, form, or fashion, by anyone who is, or may in the future be, in competition 
//                  with DG Technologies in any way.  The code shall also not be modified in
//                  a way that it is capable of being used with any Vehicle Diagnostic Adapter (VDA)
//                  outside of one from Dearborn Group, Inc.
//
// ----------------------------------------------------------------------------------------------------
//  Revision  Date       Notes
//     1.0    02-15-14   Original Version.
// ----------------------------------------------------------------------------------------------------
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Globalization;

namespace CSharpTest
{
  public class RP1210_Class
  {
    //-----------------------------------------------------------------------------------------------------
    // RP1210   RP1210_SendCommand() definitions.
    //-----------------------------------------------------------------------------------------------------
    
    public short RP1210_Reset_Device                              =          0; //
    public short RP1210_Set_All_Filters_States_to_Pass            =          3; //
    public short RP1210_Set_Message_Filtering_For_J1939           =          4; //
    public short RP1210_Set_Message_Filtering_For_CAN             =          5; //
    public short RP1210_Set_Message_Filtering_For_J1708           =          7; //
    public short RP1210_Set_Message_Filtering_For_J1850           =          8; //
    public short RP1210_Set_Message_Filtering_For_ISO15765        =          9; //
    public short RP1210_Generic_Driver_Command                    =         14; //
    public short RP1210_Set_J1708_Mode                            =         15; //
    public short RP1210_Echo_Transmitted_Messages                 =         16; //
    public short RP1210_Set_All_Filters_States_to_Discard         =         17; //
    public short RP1210_Set_Message_Receive                       =         18; //
    public short RP1210_Protect_J1939_Address                     =         19; //
    public short RP1210_Set_Broadcast_For_J1708                   =         20; //
    public short RP1210_Set_Broadcast_For_CAN                     =         21; //
    public short RP1210_Set_Broadcast_For_J1939                   =         22; //
    public short RP1210_Set_Broadcast_For_J1850                   =         23; //
    public short RP1210_Set_J1708_Filter_Type                     =         24; //
    public short RP1210_Set_J1939_Filter_Type                     =         25; //
    public short RP1210_Set_CAN_Filter_Type                       =         26; //
    public short RP1210_Set_J1939_Interpacket_Time                =         27; //
    public short RP1210_SetMaxErrorMsgSize                        =         28; //
    public short RP1210_Disallow_Further_Connections              =         29; //
    public short RP1210_Set_J1850_Filter_Type                     =         30; //
    public short RP1210_Release_J1939_Address                     =         31; //
    public short RP1210_Set_ISO15765_Filter_Type                  =         32; //
    public short RP1210_Set_Broadcast_For_ISO15765                =         33; //
    public short RP1210_Set_ISO15765_Flow_Control                 =         34; //
    public short RP1210_Clear_ISO15765_Flow_Control               =         35; //
    public short RP1210_Set_ISO15765_Link_Type                    =         36; //
    public short RP1210_Set_J1939_Baud                            =         37; //
    public short RP1210_Set_ISO15765_Baud                         =         38; //
    public short RP1210_Set_BlockTimeout                          =        215; //
    public short RP1210_Set_J1708_Baud                            =        305; //
    
    //-----------------------------------------------------------------------------------------------------
    // RP1210 Constants - Check RP1210 document for any updates.
    //-----------------------------------------------------------------------------------------------------
    
    public byte  BIT0                                             =          1; // Bit 0 - Used for masking bits
    public byte  BIT1                                             =          2; // Bit 1 - Used for masking bits
    public byte  BIT2                                             =          4; // Bit 2 - Used for masking bits
    public byte  BIT3                                             =          8; // Bit 3 - Used for masking bits
    public byte  BIT4                                             =         16; // Bit 4 - Used for masking bits
    public byte  BIT5                                             =         32; // Bit 5 - Used for masking bits
    public byte  BIT6                                             =         64; // Bit 6 - Used for masking bits
    public byte  BIT7                                             =        128; // Bit 7 - Used for masking bits
    //
    public int   CONNECTED                                        =          1; // Connection state = Connected 
    public int   NOT_CONNECTED                                    =         -1; // Connection state = Disconnected
    //
    public byte  FILTER_PASS_NONE                                 =          0; // Filter state = DISCARD ALL MESSAGES
    public byte  FILTER_PASS_SOME                                 =          1; // Filter state = PASS SOME
    public byte  FILTER_PASS_ALL                                  =          2; // Filter state = PASS ALL
    //
    public byte  NULL_WINDOW                                      =          0; // Windows 3.1 is no longer supported.
    //
    public byte  BLOCKING_IO                                      =          1; // For Blocking calls to send/read.
    public byte  NON_BLOCKING_IO                                  =          0; // For Non-Blocking calls to send/read.
    public byte  BLOCK_INFINITE                                   =          0; // For Blocking calls to send/read.
    //
    public byte  BLOCK_UNTIL_DONE                                 =          0; // J1939 Address claim, wait until done
    public byte  RETURN_BEFORE_COMPLETION                         =          2; // J1939 Address claim, don't wait
    public byte  SILENT_J1939_CLAIM                               =       0x00; // Claim J1939 Address
    public byte  PASS_J1939_CLAIM_MESSAGES                        =       0x01; // Claim J1939 Address
    //
    public byte  CONVERTED_MODE                                   =          1; // J1708 RP1210Mode="Converted"
    public byte  RAW_MODE                                         =          0; // J1708 RP1210Mode="Raw"
    //
    public int   MAX_J1708_MESSAGE_LENGTH                         =        508; // Maximum size of J1708 message (+1)
    public int   MAX_J1939_MESSAGE_LENGTH                         =       1796; // Maximum size of J1939 message (+1)
    public int   MAX_ISO15765_MESSAGE_LENGTH                      =       4108; // Maximum size of ISO15765 message (+1)
    //
    public byte  ECHO_OFF                                         =       0x00; // EchoMode
    public byte  ECHO_ON                                          =       0x01; // EchoMode
    //
    public byte  RECEIVE_ON                                       =       0x01; // Set Message Receive
    public byte  RECEIVE_OFF                                      =       0x00; // Set Message Receive
    //
    public byte  ADD_LIST                                         =       0x01; // Add a message to the list.
    public byte  VIEW_B_LIST                                      =       0x02; // View an entry in the list.
    public byte  DESTROY_LIST                                     =       0x03; // Remove all entries in the list.
    public byte  REMOVE_ENTRY                                     =       0x04; // Remove a specific entry from the list.
    public byte  LIST_LENGTH                                      =       0x05; // Returns number of items in list.
    //
    public int   FILTER_PGN                                       = 0x00000001; // Setting of J1939 filters
    public int   FILTER_PRIORITY                                  = 0x00000002; // Setting of J1939 filters
    public int   FILTER_SOURCE                                    = 0x00000004; // Setting of J1939 filters
    public int   FILTER_DESTINATION                               = 0x00000008; // Setting of J1939 filters
    public byte  FILTER_INCLUSIVE                                 =       0x00; // FilterMode
    public byte  FILTER_EXCLUSIVE                                 =       0x01; // FilterMode
    //
    public byte  CHANGE_BAUD_NOW                                  =       0x00; // Change Baud
    public byte  MSG_FIRST_CHANGE_BAUD                            =       0x01; // Change Baud
    public byte  RP1210_BAUD_9600                                 =       0x00; // Change Baud
    public byte  RP1210_BAUD_19200                                =       0x01; // Change Baud
    public byte  RP1210_BAUD_38400                                =       0x02; // Change Baud
    public byte  RP1210_BAUD_57600                                =       0x03; // Change Baud
    public byte  RP1210_BAUD_125k                                 =       0x04; // Change Baud
    public byte  RP1210_BAUD_250k                                 =       0x05; // Change Baud
    public byte  RP1210_BAUD_500k                                 =       0x06; // Change Baud
    public byte  RP1210_BAUD_1000k                                =       0x07; // Change Baud
    //
    public byte  STANDARD_CAN                                     =       0x00; // Filters
    public byte  EXTENDED_CAN                                     =       0x01; // Filters
    //
    public byte  STANDARD_CAN_ISO15765_EXTENDED                   =       0x02; // 11-bit with ISO15765 extended address
    public byte  EXTENDED_CAN_ISO15765_EXTENDED                   =       0x03; // 29-bit with ISO15765 extended address
    public byte  STANDARD_MIXED_CAN_ISO15765                      =       0x04; // 11-bit identifier with mixed addressing
    public byte  ISO15765_ACTUAL_MESSAGE                          =       0x00; // ISO15765 ReadMessage - type of data
    public byte  ISO15765_CONFIRM                                 =       0x01; // ISO15765 ReadMessage - type of data
    public byte  ISO15765_FF_INDICATION                           =       0x02; // ISO15765 ReadMessage - type of data
    public byte  LINKTYPE_GENERIC_CAN                             =       0x00; // Set_ISO15765_Link_Type argument
    public byte  LINKTYPE_J1939_ISO15765_2_ANNEX_A                =       0x01; // Set_ISO15765_Link_Type argument
    public byte  LINKTYPE_J1939_ISO15765_3                        =       0x02; // Set_ISO15765_Link_Type argument
    //      
    public byte  J1939_GLOBAL_ADDRESS                             =        255; // Global address for destination specific messages.
    public byte  J1939_OFFBOARD_DIAGNOSTICS_TOOL_1                =        249; // Offboard PC#1 address in J1939.
    public byte  J1708_OFFBOARD_DIAGNOSTICS_TOOL_1                =        172; // Offboard PC#1 address in J1708/J1587.

    //-----------------------------------------------------------------------------------------------------
    // RP1210 Return Definitions
    //-----------------------------------------------------------------------------------------------------
    
    public int   NO_ERRORS                                        =          0; //
    public int   ERR_DLL_NOT_INITIALIZED                          =        128; //
    public int   ERR_INVALID_CLIENT_ID                            =        129; //
    public int   ERR_CLIENT_ALREADY_CONNECTED                     =        130; //
    public int   ERR_CLIENT_AREA_FULL                             =        131; //
    public int   ERR_FREE_MEMORY                                  =        132; //
    public int   ERR_NOT_ENOUGH_MEMORY                            =        133; //
    public int   ERR_INVALID_DEVICE                               =        134; //
    public int   ERR_DEVICE_IN_USE                                =        135; //
    public int   ERR_INVALID_PROTOCOL                             =        136; //
    public int   ERR_TX_QUEUE_FULL                                =        137; //
    public int   ERR_TX_QUEUE_CORRUPT                             =        138; //
    public int   ERR_RX_QUEUE_FULL                                =        139; //
    public int   ERR_RX_QUEUE_CORRUPT                             =        140; //
    public int   ERR_MESSAGE_TOO_LONG                             =        141; //
    public int   ERR_HARDWARE_NOT_RESPONDING                      =        142; //
    public int   ERR_COMMAND_NOT_SUPPORTED                        =        143; //
    public int   ERR_INVALID_COMMAND                              =        144; //
    public int   ERR_TXMESSAGE_STATUS                             =        145; //
    public int   ERR_ADDRESS_CLAIM_FAILED                         =        146; //
    public int   ERR_CANNOT_SET_PRIORITY                          =        147; //
    public int   ERR_CLIENT_DISCONNECTED                          =        148; //
    public int   ERR_CONNECT_NOT_ALLOWED                          =        149; //
    public int   ERR_CHANGE_MODE_FAILED                           =        150; //
    public int   ERR_BUS_OFF                                      =        151; //
    public int   ERR_COULD_NOT_TX_ADDRESS_CLAIMED                 =        152; //
    public int   ERR_ADDRESS_LOST                                 =        153; //
    public int   ERR_CODE_NOT_FOUND                               =        154; //
    public int   ERR_BLOCK_NOT_ALLOWED                            =        155; //
    public int   ERR_MULTIPLE_CLIENTS_CONNECTED                   =        156; //
    public int   ERR_ADDRESS_NEVER_CLAIMED                        =        157; //
    public int   ERR_WINDOW_HANDLE_REQUIRED                       =        158; //
    public int   ERR_MESSAGE_NOT_SENT                             =        159; //
    public int   ERR_MAX_NOTIFY_EXCEEDED                          =        160; //
    public int   ERR_MAX_FILTERS_EXCEEDED                         =        161; //
    public int   ERR_HARDWARE_STATUS_CHANGE                       =        162; //
    public int   ERR_INI_FILE_NOT_IN_WIN_DIR                      =        202; //
    public int   ERR_INI_SECTION_NOT_FOUND                        =        204; //
    public int   ERR_INI_KEY_NOT_FOUND                            =        205; //
    public int   ERR_INVALID_KEY_STRING                           =        206; //
    public int   ERR_DEVICE_NOT_SUPPORTED                         =        207; //
    public int   ERR_INVALID_PORT_PARAM                           =        208; //
    public int   ERR_COMMAND_TIMED_OUT                            =        213; //
    public int   ERR_OS_NOT_SUPPORTED                             =        220; //
    public int   ERR_COMMAND_QUEUE_IS_FULL                        =        222; //
    public int   ERR_CANNOT_SET_CAN_BAUDRATE                      =        224; //
    public int   ERR_CANNOT_CLAIM_BROADCAST_ADDRESS               =        225; //
    public int   ERR_OUT_OF_ADDRESS_RESOURCES                     =        226; //
    public int   ERR_ADDRESS_RELEASE_FAILED                       =        227; //
    public int   ERR_COMM_DEVICE_IN_USE                           =        230; //
    public int   DG_DLL_NOT_FOUND                                 =        254; //
    public int   DG_BUSY_SENDING                                  =        255; //
    public int   ERR_DATA_LINK_CONFLICT                           =        441; //
    public int   ERR_ADAPTER_NOT_RESPONDING                       =        453; //
    public int   ERR_CAN_BAUD_SET_NONSTANDARD                     =        454; //
    public int   ERR_MULTIPLE_CONNECTIONS_NOT_ALLOWED_NOW         =        455; //
    public int   ERR_J1708_BAUD_SET_NONSTANDARD                   =        456; //
    public int   ERR_J1939_BAUD_SET_NONSTANDARD                   =        457; //
    public int   ERR_ISO15765_BAUD_SET_NONSTANDARD                =        458; //

    //------------------------------------------------------------------------------------------
    // Import the LoadLibrary(), GetProcAddress(), and FreeLibrary() calls from Kernel32.DLL.
    //------------------------------------------------------------------------------------------
    
    [DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern IntPtr LoadLibrary(string dllToLoad);
    
    [DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern IntPtr GetProcAddress(IntPtr hModule, string procName);
    
    [DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern bool FreeLibrary(IntPtr hModule);

    //--------------------------------------------------------------
    // RP1210 Function Prototypes
    //--------------------------------------------------------------
    
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate short RP1210ClientConnect(IntPtr hwndClient, short nDeviceId, StringBuilder fpchProtocol, int lSendBuffer, int lReceiveBuffer, short nIsAppPacketizingIncomingMsgs);
    
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate short RP1210ClientDisconnect(short nClientID);
    
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate short RP1210SendMessage(short nClientID, byte[] fpchClientMessage, short nMessageSize, short nNotifyStatusOnTx, short nBlockOnSend);
    
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate short RP1210ReadMessage(short nClientID, byte[] fpchAPIMessage, short nBufferSize, short nBlockOnSend);
    
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate short RP1210SendCommand(short nCommandNumber, short nClientID, StringBuilder fpchClientCommand, short nMessageSize);
    
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate void RP1210ReadVersion(StringBuilder fpchDLLMajorVersion, StringBuilder fpchDLLMinorVersion, StringBuilder fpchAPIMajorVersion, StringBuilder fpchAPIMinorVersion);
    
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate short RP1210ReadDetailedVersion(short nClientID, StringBuilder fpchAPIVersionInfo, StringBuilder fpchDLLVersionInfo, StringBuilder fpchFWVersionInfo);
    
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate short RP1210GetHardwareStatus(short nClientID, StringBuilder fpchClientInfo, short nInfoSize, short nBlockOnRequest);
    
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate short RP1210GetErrorMsg(short err_code, StringBuilder fpchMessage);
    
    //------------------------------------------------------------------
    // RP1210 Function Pointer Definitions and then Function Variables
    //------------------------------------------------------------------
    
    public IntPtr                     pDLL                             ;

    public IntPtr                     fpRP1210_ClientConnect           ;
    public IntPtr                     fpRP1210_ClientDisconnect        ;
    public IntPtr                     fpRP1210_SendMessage             ;
    public IntPtr                     fpRP1210_ReadMessage             ;
    public IntPtr                     fpRP1210_SendCommand             ;
    public IntPtr                     fpRP1210_ReadVersion             ;
    public IntPtr                     fpRP1210_ReadDetailedVersion     ;
    public IntPtr                     fpRP1210_GetHardwareStatus       ;
    public IntPtr                     fpRP1210_GetErrorMsg             ;
    
    public RP1210ClientConnect        pRP1210_ClientConnect            ;
    public RP1210ClientDisconnect     pRP1210_ClientDisconnect         ;
    public RP1210SendMessage          pRP1210_SendMessage              ;
    public RP1210ReadMessage          pRP1210_ReadMessage              ;
    public RP1210SendCommand          pRP1210_SendCommand              ;
    public RP1210ReadVersion          pRP1210_ReadVersion              ;
    public RP1210ReadDetailedVersion  pRP1210_ReadDetailedVersion      ;
    public RP1210GetHardwareStatus    pRP1210_GetHardwareStatus        ;
    public RP1210GetErrorMsg          pRP1210_GetErrorMsg              ;

    // ----------------------------------------------------------------------
    // Unpack a two-byte integer that has been sent LSB first.
    // ----------------------------------------------------------------------
    public short UnPackTwoByteIntegerLSB( byte[] ucIntString, short nStartIdx )
    {
      short nValue = 0;
      
      nValue = (short) (( ucIntString[1 + nStartIdx] << 8 ) | ( ucIntString[0 + nStartIdx] ));
      
      return nValue;

    }//UnPackTwoByteIntegerLSB
    
    // ----------------------------------------------------------------------
    // Unpack a three-byte integer that has been sent LSB first.
    // ----------------------------------------------------------------------
    public UInt32 UnPackThreeByteIntegerLSB( byte[] ucIntString, short nStartIdx  )
    {
      UInt32 iValue = 0;

      iValue = (UInt32)((ucIntString[2 + nStartIdx] << 16) | (ucIntString[1 + nStartIdx] << 8) | (ucIntString[0 + nStartIdx]));
      
      return iValue;

    }//UnPackThreeByteIntegerLSB
    
    // ----------------------------------------------------------------------
    // Unpack a four-byte integer that has been sent LSB first.
    // ----------------------------------------------------------------------
    public UInt32 UnPackFourByteIntegerLSB( byte[] ucIntString, short nStartIdx)
    {
      UInt32 iValue = 0;

      iValue = (UInt32)((ucIntString[3 + nStartIdx] << 24) | (ucIntString[2 + nStartIdx] << 16) | (ucIntString[1 + nStartIdx] << 8) | (ucIntString[0 + nStartIdx]));
      
      return iValue;

    }//UnPackFourByteIntegerLSB

    //    
    //****************************************************************************************************
    //****************************************************************************************************
    // J1939 Section
    //****************************************************************************************************
    //****************************************************************************************************
    //

    //
    // Structure that defines a J1939 Message.
    //
    public struct sJ1939Message
    {
      public short  nChannel              ;
      public UInt32 ulTimeStamp           ;
      public byte   ucSourceAddress       ;
      public byte   ucDestAddress         ;
      public byte   ucPriority            ;
      public string sHow                  ;
      public UInt32 ulPGN                 ;
      public UInt32 ulDataLength          ;
      public byte[] ucData                ;
    }

    //
    // Process a received and decoded J1939 message, looking for PGN 61444 EEC1.
    //
    public void ProcessJ1939RxMessage( sJ1939Message sJ1939Msg )
    {
      double fEngineSpeed               = 0.0;
      double fEngineDemandPercentTorque = 0.0;

      switch( sJ1939Msg.ulPGN )
        {
          //
          // EEC1 - Electronic Engine #1, 61444
          //
        case 61444:

          Console.WriteLine();

          // SPN 190
          
          fEngineSpeed =  ( float ) ( UnPackTwoByteIntegerLSB( sJ1939Msg.ucData, 3 ) * 0.125 ) + 0;
          
          if( ( fEngineSpeed < 0 ) || ( fEngineSpeed > 8031.875 ) )
            Console.WriteLine("( PGN 61444/SPN 190  ) EngineSpeed                              = N/A"              );
          else
            Console.WriteLine("( PGN 61444/SPN 190  ) EngineSpeed                              = {0}", fEngineSpeed);

          // SPN 2432

          fEngineDemandPercentTorque = (float)(sJ1939Msg.ucData[7] * 1) + (-125);

          if( (fEngineDemandPercentTorque < -125) || (fEngineDemandPercentTorque > 125) )
            Console.WriteLine("( PGN 61444/SPN 2432 ) EngineDemandPercentTorque                = N/A"                            );
          else
            Console.WriteLine("( PGN 61444/SPN 2432 ) EngineDemandPercentTorque                = {0}", fEngineDemandPercentTorque);

          Console.WriteLine(  );
          
          break;
          
        default:
          break;
          
        }//switch

    }//ProcessJ1939RxMessage

    //
    // Prints a received and decoded J1939 message.
    //
    public void PrintJ1939RxMessage( sJ1939Message sJ1939Msg )
    {
      Console.Write("Rx J1939 TS=[{0}] ", sJ1939Msg.ulTimeStamp.ToString    ("D10") );
      Console.Write("Chan=[{0}] "       , sJ1939Msg.nChannel.ToString       ("D2" ) );
      Console.Write("PGN=[{0}] "        , sJ1939Msg.ulPGN.ToString          ("D5" ) );
      Console.Write("HOW=[{0}] "        , sJ1939Msg.sHow.ToString           (     ) );
      Console.Write("PRI=[{0}] "        , sJ1939Msg.ucPriority.ToString     ("D1" ) );
      Console.Write("SRC=[{0}] "        , sJ1939Msg.ucSourceAddress.ToString("D3" ) );
      Console.Write("DST=[{0}] "        , sJ1939Msg.ucDestAddress.ToString  ("D3" ) );
      Console.Write("DL=[{0}] "         , sJ1939Msg.ulDataLength.ToString   ("D4" ) );
      Console.WriteLine();
      Console.Write("\tDATA-HEX");
      
      for( int i = 0; i < sJ1939Msg.ulDataLength; i++ )
        Console.Write("[{0}]", sJ1939Msg.ucData[i].ToString("X2") );
      
      Console.WriteLine("");

    }//PrintJ1939RxMessage

    //
    // Prints a transmitted and decoded J1939 message.
    //
    public void PrintJ1939TxMessage( sJ1939Message sJ1939Msg )
    {
      Console.Write("Tx J1939 Chan=[{0}] "       , sJ1939Msg.nChannel.ToString       ("D2") );
      Console.Write("PGN=[{0}] "                 , sJ1939Msg.ulPGN.ToString          ("D5") );
      Console.Write("HOW=[{0}] "                 , sJ1939Msg.sHow.ToString           (    ) );
      Console.Write("PRI=[{0}] "                 , sJ1939Msg.ucPriority.ToString     ("D1") );
      Console.Write("SRC=[{0}] "                 , sJ1939Msg.ucSourceAddress.ToString("D3") );
      Console.Write("DST=[{0}] "                 , sJ1939Msg.ucDestAddress.ToString  ("D3") );
      Console.Write("DL=[{0}] "                  , sJ1939Msg.ulDataLength.ToString   ("D4") );
      Console.WriteLine();
      Console.Write("\tDATA-HEX");
      
      for( int i = 0; i < sJ1939Msg.ulDataLength; i++ )
        Console.Write("[{0}]", sJ1939Msg.ucData[i].ToString("X2") );
      
      Console.WriteLine("");

    }//PrintJ1939TxMessage
    
    //
    // Decodes a received J1939 message and puts it in a structure.
    //
    public sJ1939Message DecodeRxJ1939Message(byte[] ucMessage, short nMsgLen, short nChannel)
    {
      sJ1939Message sDecodedMsg              = new sJ1939Message();

      sDecodedMsg.nChannel                   = nChannel;
      sDecodedMsg.ulTimeStamp                = (UInt32)((ucMessage[0] << 24) + (ucMessage[1] << 16) + (ucMessage[2] << 8) + ucMessage[3]); //TS is Big Endian.
      sDecodedMsg.ulPGN                      = (UInt16)((ucMessage[6] << 16) + (ucMessage[5] << 8) + ucMessage[4]); // PGN

      if( ( ucMessage[7] & 0x80) == 0x80 )
        {
          sDecodedMsg.sHow                   = "BAM";
          ucMessage[9]                       = 0xFF;
        }
      else
        {
          sDecodedMsg.sHow                   = "RTS";
        }

      sDecodedMsg.ucPriority                 = (byte) (ucMessage[7] & 0x07);
      sDecodedMsg.ucSourceAddress            = ucMessage[8];
      sDecodedMsg.ucDestAddress              = ucMessage[9];
      sDecodedMsg.ulDataLength               = (UInt16)(nMsgLen - 10);
      sDecodedMsg.ucData                     = new byte[sDecodedMsg.ulDataLength];
      
      Array.Copy(ucMessage, 10, sDecodedMsg.ucData, 0, sDecodedMsg.ulDataLength);
      
      return sDecodedMsg;

    }//DecodeRxJ1939Message

    //
    // Decodes a transmitted J1939 message and puts it in a structure.
    //
    public sJ1939Message DecodeTxJ1939Message( byte[] ucMessage, short nMsgLen, short nChannel )
    {
      sJ1939Message sDecodedMsg              = new sJ1939Message();

      sDecodedMsg.nChannel                   = nChannel;
      sDecodedMsg.ulTimeStamp                = 0;
      sDecodedMsg.ulPGN                      = (UInt16)((ucMessage[2] << 16) + (ucMessage[1] << 8) + ucMessage[0]); // PGN

      if( ( ucMessage[3] & 0x80) == 0x80 )
        {
          sDecodedMsg.sHow                   = "BAM";
        }
      else
        {
          sDecodedMsg.sHow                   = "RTS";
        }

      sDecodedMsg.ucPriority                 = (byte) (ucMessage[3] & 0x07);

      sDecodedMsg.ucSourceAddress            = ucMessage[4];
      sDecodedMsg.ucDestAddress              = ucMessage[5];
      sDecodedMsg.ulDataLength               = (UInt16)(nMsgLen - 6);

      sDecodedMsg.ucData                     = new byte[sDecodedMsg.ulDataLength];
      
      Array.Copy(ucMessage, 6, sDecodedMsg.ucData, 0, sDecodedMsg.ulDataLength);
      
      return sDecodedMsg;

    }//DecodeTxJ1939Message

    //
    // This shows how to claim a J1939 address.
    //
    public bool ClaimJ1939Address(short nClientID, byte ucJ1939Address)
    {
      short  nRetVal              = 0;
      byte[] ucTxRxBuffer         = new byte[10];

      // J1939 "NAME" for this sample source code application ( see J1939/81 )
      //    Self Configurable       =   0 = NO
      //    Industry Group          =   0 = GLOBAL
      //    Vehicle System          =   0 = Non-Specific
      //    Vehicle System Instance =   0 = First Diagnostic PC
      //    Reserved                =   0 = Must be zero
      //    Function                = 129 = Offboard Service Tool
      //    Function Instance       =   0 = First Offboard Service Tool
      //    Manufacturer Code       =  11 = Dearborn Group, Inc. 
      //    Manufacturer Identity   =   0 = Dearborn Group, Inc. Sample Source Code
      
      byte[] ucJ1939Name = { 0x00, 0x00, 0x60, 0x01, 0x00, 0x81, 0x00, 0x00 };
    
      ucTxRxBuffer[0] = ucJ1939Address;
      ucTxRxBuffer[1] = ucJ1939Name[0];
      ucTxRxBuffer[2] = ucJ1939Name[1];
      ucTxRxBuffer[3] = ucJ1939Name[2];
      ucTxRxBuffer[4] = ucJ1939Name[3];
      ucTxRxBuffer[5] = ucJ1939Name[4];
      ucTxRxBuffer[6] = ucJ1939Name[5];
      ucTxRxBuffer[7] = ucJ1939Name[6];
      ucTxRxBuffer[8] = ucJ1939Name[7];
      ucTxRxBuffer[9] = BLOCK_UNTIL_DONE;

      StringBuilder Command = new StringBuilder(100);

      Command.Append( System.Text.Encoding.ASCII.GetString(ucTxRxBuffer) );

      nRetVal = pRP1210_SendCommand( RP1210_Protect_J1939_Address, nClientID, Command, 10 );
      
      if( nRetVal == 0 )
        {
          return true;
        }
      else
        {
          return false;
        }

    }//ClaimJ1939Address

    //
    // This shows how to send a J1939 message.  It sends the request PGN 59904 asking for iRequestedPGN.
    //
    public bool SendJ1939RequestPGN( short nClientID, byte ucSourceAddress, byte ucAddressRequestedFrom, int iRequestedPGN )
    {
      int             iPGN                = 59904;
      short           nRetVal             = -1;
      short           nDataBytes          = -1;
      byte[]          ucTxRxBuffer        = new byte[10];
      sJ1939Message   sJ1939Msg           ;

      iPGN            = 59904;                                          // Request PGN
      ucTxRxBuffer[0] = (byte) ( (iPGN & 0x000000FF) >> 0   );          // Byte 0 - LSB, Lo byte of PGN
      ucTxRxBuffer[1] = (byte) ( (iPGN & 0x0000FF00) >> 8   );          // Byte 1 - LSB, Mid byte of PGN
      ucTxRxBuffer[2] = (byte) ( (iPGN & 0x00FF0000) >> 16  );          // Byte 2 - LSB, Hi byte of PGN
      ucTxRxBuffer[3] = 0;                                              // 0 = RTS/CTS, 1 = BAM
      ucTxRxBuffer[3] <<= 7;                                            // Shift RTS/CTS/BAM to highest bit
      ucTxRxBuffer[3] |= 6;                                             // OR in the priority
      ucTxRxBuffer[4] = ucSourceAddress;                                // Source Address
      ucTxRxBuffer[5] = ucAddressRequestedFrom;                         // Who we want to respond
      ucTxRxBuffer[6] = (byte) ( (iRequestedPGN & 0x000000FF) >> 0   ); // Byte 0 - LSB, Lo byte of requested PGN
      ucTxRxBuffer[7] = (byte) ( (iRequestedPGN & 0x0000FF00) >> 8   ); // Byte 1 - LSB, Mid byte of requested PGN
      ucTxRxBuffer[8] = (byte) ( (iRequestedPGN & 0x00FF0000) >> 16  ); // Byte 2 - LSB, Hi byte of requested PGN
  
      nDataBytes = 9;
      
      nRetVal = pRP1210_SendMessage( nClientID, ucTxRxBuffer, nDataBytes, 0, NON_BLOCKING_IO );
      
      if( nRetVal != 0 )
        {
          return false;
        }
      else
        {
          sJ1939Msg = DecodeTxJ1939Message( ucTxRxBuffer, nDataBytes, nClientID );

          PrintJ1939TxMessage( sJ1939Msg );

          return true;
        }

    }//SendJ1939RequestPGN

    //
    //****************************************************************************************************
    //****************************************************************************************************
    // J1708 Section
    //****************************************************************************************************
    //****************************************************************************************************
    //

    //
    // Defines a J1708 Message
    //
    public struct sJ1708Message
    {
      public short  nChannel              ;
      public UInt32 ulTimeStamp           ;
      public byte   ucMID                 ;
      public UInt32 ulDataLength          ;
      public byte[] ucData                ;
      public byte   ucPriority            ; // Only on Tx messages.
    }

    //
    // Process a received and decoded J1708 message, looking for PID 190 (Engine Speed).
    //
    public void ProcessJ1708RxMessage( sJ1708Message sJ1708Msg )
    {
      double fEngineSpeed               = 0.0;
      byte   ucPID                      = 0;

      ucPID = sJ1708Msg.ucData[0];
     
      switch( ucPID )
        {
          //
          // 190 - Engine Speed
          //
        case 190:

          Console.WriteLine();

          fEngineSpeed =  ( float ) ( UnPackTwoByteIntegerLSB( sJ1708Msg.ucData, 1 ) * 0.25 ) + 0;
          
          Console.WriteLine("( SPN 190  ) EngineSpeed                              = {0}", fEngineSpeed);

          Console.WriteLine(  );
          
          break;
          
        default:
          break;
          
        }//switch

    }//ProcessJ1708RxMessage

    //
    // Prints a received and decoded J1708 message.
    //
    public void PrintJ1708RxMessage( sJ1708Message sJ1708Msg )
    {
      Console.Write("Rx J1708 TS=[{0}] ", sJ1708Msg.ulTimeStamp.ToString ("D10") );
      Console.Write("Chan=[{0}] "       , sJ1708Msg.nChannel.ToString    ("D2" ) );
      Console.Write("MID=[{0}] "        , sJ1708Msg.ucMID.ToString       ("D3" ) );
      Console.Write("DL=[{0}] "         , sJ1708Msg.ulDataLength.ToString("D4" ) );
      Console.WriteLine();
      Console.Write("\tDATA-HEX");
      
      for( int i = 0; i < sJ1708Msg.ulDataLength; i++ )
        Console.Write("[{0}]", sJ1708Msg.ucData[i].ToString("X2") );
      
      Console.WriteLine("");

    }//PrintJ1708RxMessage

    //
    // Prints a transmitted and decoded J1708 message.
    //
    public void PrintJ1708TxMessage( sJ1708Message sJ1708Msg )
    {
      Console.Write("Tx J1708 Chan=[{0}] ", sJ1708Msg.nChannel.ToString    ("D2" ) );
      Console.Write("PRI=[{0}] "          , sJ1708Msg.ucPriority.ToString  ("D3" ) );
      Console.Write("MID=[{0}] "          , sJ1708Msg.ucMID.ToString       ("D3" ) );
      Console.Write("DL=[{0}] "           , sJ1708Msg.ulDataLength.ToString("D4" ) );
      Console.WriteLine();
      Console.Write("\tDATA-HEX");
      
      for( int i = 0; i < sJ1708Msg.ulDataLength; i++ )
        Console.Write("[{0}]", sJ1708Msg.ucData[i].ToString("X2") );
      
      Console.WriteLine("");

    }//PrintJ1708TxMessage

    //
    // Decodes a received J1708 message and puts it in a structure.
    //
    public sJ1708Message DecodeRxJ1708Message(byte[] ucMessage, short nMsgLen, short nChannel)
    {
      sJ1708Message sDecodedMsg              = new sJ1708Message();

      sDecodedMsg.ucPriority                 = 0;
      sDecodedMsg.nChannel                   = nChannel;
      sDecodedMsg.ulTimeStamp                = (UInt32)((ucMessage[0] << 24) + (ucMessage[1] << 16) + (ucMessage[2] << 8) + ucMessage[3]); //TS is Big Endian.
      sDecodedMsg.ucMID                      = ucMessage[4];
      sDecodedMsg.ulDataLength               = (UInt16)(nMsgLen - 5);
      sDecodedMsg.ucData                     = new byte[sDecodedMsg.ulDataLength];
      
      Array.Copy(ucMessage, 5, sDecodedMsg.ucData, 0, sDecodedMsg.ulDataLength);
      
      return sDecodedMsg;

    }//DecodeRxJ1708Message

    //
    // Decodes a transmitted J1708 message and puts it in a structure.
    //
    public sJ1708Message DecodeTxJ1708Message( byte[] ucMessage, short nMsgLen, short nChannel )
    {
      sJ1708Message sDecodedMsg              = new sJ1708Message();

      sDecodedMsg.nChannel                   = nChannel;
      sDecodedMsg.ulTimeStamp                = 0;
      sDecodedMsg.ucPriority                 = ucMessage[0];
      sDecodedMsg.ucMID                      = ucMessage[1];
      sDecodedMsg.ulDataLength               = (UInt16)(nMsgLen - 2);
      sDecodedMsg.ucData                     = new byte[sDecodedMsg.ulDataLength];
      
      Array.Copy(ucMessage, 2, sDecodedMsg.ucData, 0, sDecodedMsg.ulDataLength);
      
      return sDecodedMsg;

    }//DecodeTxJ1708Message

    //
    // This shows how to send a J1708 message.  It sends the request PID (0) asking for ucRequestedPID.
    //
    public bool SendJ1708RequestPID( short nClientID, byte ucSourceAddress, byte ucRequestedPID )
    {
      short           nRetVal             = -1;
      short           nDataBytes          = -1;
      byte[]          ucTxRxBuffer        = new byte[10];
      sJ1708Message   sJ1708Msg           ;

      ucTxRxBuffer[0] = 8;                // Lowest Priority
      ucTxRxBuffer[1] = ucSourceAddress;  // Source Address
      ucTxRxBuffer[2] = 0x00;             // Request PID
      ucTxRxBuffer[3] = ucRequestedPID;   // Requested PID
      nDataBytes      = 4;

      nRetVal = pRP1210_SendMessage( nClientID, ucTxRxBuffer, nDataBytes, 0, NON_BLOCKING_IO);
      
      if( nRetVal != 0 )
        {
          return false;
        }
      else
        {
          sJ1708Msg = DecodeTxJ1708Message( ucTxRxBuffer, nDataBytes, nClientID );

          PrintJ1708TxMessage( sJ1708Msg );

          return true;
       }

    }//SendJ1708RequestPID

    //    
    //****************************************************************************************************
    //****************************************************************************************************
    // RP1210 Section
    //****************************************************************************************************
    //****************************************************************************************************
    //

    //
    // Load an RP1210 DLL and set up all of the function pointers.
    //
    public bool LoadDLLAndFunctions(string szDLLToLoad)
    {
      bool bError = false;
      
      pDLL = LoadLibrary(szDLLToLoad);
      
      if (pDLL == IntPtr.Zero)
        {
          return false;
        }
      else
        {
          fpRP1210_ClientConnect        = IntPtr.Zero;
          fpRP1210_ClientDisconnect     = IntPtr.Zero;
          fpRP1210_SendMessage          = IntPtr.Zero;
          fpRP1210_ReadMessage          = IntPtr.Zero;
          fpRP1210_SendCommand          = IntPtr.Zero;
          fpRP1210_ReadVersion          = IntPtr.Zero;
          fpRP1210_ReadDetailedVersion  = IntPtr.Zero;
          fpRP1210_GetHardwareStatus    = IntPtr.Zero;
          fpRP1210_GetErrorMsg          = IntPtr.Zero;
          
          fpRP1210_ClientConnect        = GetProcAddress(pDLL, "RP1210_ClientConnect"      );      
          fpRP1210_ClientDisconnect     = GetProcAddress(pDLL, "RP1210_ClientDisconnect"   );   
          fpRP1210_SendMessage          = GetProcAddress(pDLL, "RP1210_SendMessage"        );        
          fpRP1210_ReadMessage          = GetProcAddress(pDLL, "RP1210_ReadMessage"        );        
          fpRP1210_SendCommand          = GetProcAddress(pDLL, "RP1210_SendCommand"        );        
          fpRP1210_ReadVersion          = GetProcAddress(pDLL, "RP1210_ReadVersion"        );        
          fpRP1210_ReadDetailedVersion  = GetProcAddress(pDLL, "RP1210_ReadDetailedVersion");
          fpRP1210_GetHardwareStatus    = GetProcAddress(pDLL, "RP1210_GetHardwareStatus"  );  
          fpRP1210_GetErrorMsg          = GetProcAddress(pDLL, "RP1210_GetErrorMsg"        );        
          
          if (IntPtr.Zero == fpRP1210_ClientConnect)       bError = true;
          if (IntPtr.Zero == fpRP1210_ClientDisconnect)    bError = true;
          if (IntPtr.Zero == fpRP1210_SendMessage)         bError = true;
          if (IntPtr.Zero == fpRP1210_ReadMessage)         bError = true;
          if (IntPtr.Zero == fpRP1210_SendCommand)         bError = true;
          if (IntPtr.Zero == fpRP1210_ReadVersion)         bError = true;
          if (IntPtr.Zero == fpRP1210_ReadDetailedVersion) bError = true;
          if (IntPtr.Zero == fpRP1210_GetHardwareStatus)   bError = true;
          if (IntPtr.Zero == fpRP1210_GetErrorMsg)         bError = true;
          
          if( true == bError )
            {
              return false;
            }
          
          pRP1210_ClientConnect       = (RP1210ClientConnect)       Marshal.GetDelegateForFunctionPointer( fpRP1210_ClientConnect       , typeof( RP1210ClientConnect       ));
          pRP1210_ClientDisconnect    = (RP1210ClientDisconnect)    Marshal.GetDelegateForFunctionPointer( fpRP1210_ClientDisconnect    , typeof( RP1210ClientDisconnect    ));
          pRP1210_SendMessage         = (RP1210SendMessage)         Marshal.GetDelegateForFunctionPointer( fpRP1210_SendMessage         , typeof( RP1210SendMessage         ));
          pRP1210_ReadMessage         = (RP1210ReadMessage)         Marshal.GetDelegateForFunctionPointer( fpRP1210_ReadMessage         , typeof( RP1210ReadMessage         ));
          pRP1210_SendCommand         = (RP1210SendCommand)         Marshal.GetDelegateForFunctionPointer( fpRP1210_SendCommand         , typeof( RP1210SendCommand         ));
          pRP1210_ReadVersion         = (RP1210ReadVersion)         Marshal.GetDelegateForFunctionPointer( fpRP1210_ReadVersion         , typeof( RP1210ReadVersion         ));
          pRP1210_ReadDetailedVersion = (RP1210ReadDetailedVersion) Marshal.GetDelegateForFunctionPointer( fpRP1210_ReadDetailedVersion , typeof( RP1210ReadDetailedVersion ));
          pRP1210_GetHardwareStatus   = (RP1210GetHardwareStatus)   Marshal.GetDelegateForFunctionPointer( fpRP1210_GetHardwareStatus   , typeof( RP1210GetHardwareStatus   ));
          pRP1210_GetErrorMsg         = (RP1210GetErrorMsg)         Marshal.GetDelegateForFunctionPointer( fpRP1210_GetErrorMsg         , typeof( RP1210GetErrorMsg         ));
          
          return true;
        }
      
    }//LoadDLLAndFunctions()
    
    //
    // Free an RP1210 DLL.
    //
    public bool FreeLibraryAndFunctions()
    {
      FreeLibrary(pDLL);
      return true;

    }//FreeLibraryAndFunctions
    
  }//RP1210_Class

  //
  //****************************************************************************************************
  //****************************************************************************************************
  // Program Class
  //****************************************************************************************************
  //****************************************************************************************************
  //

  class Program
  {
    //
    // Import the kbhit function from the C runtime library.
    //
    [DllImport("crtdll.dll")]   
    public static extern int _kbhit();

    //
    // Global Program class variables.
    //
    const String PROGRAM_ID = "DG Technologies - RP1210 Sample Source Code C# - Version 1.00";

    //
    //****************************************************************************************************
    //****************************************************************************************************
    // main() - Program Entry Point
    //****************************************************************************************************
    //****************************************************************************************************
    static int Main(string[] args)
    {
      //
      // Declare the RP1210_Class wrapper.
      //
      RP1210_Class               RP1210            = new RP1210_Class();

      //
      // Device DLL name, DeviceID and nClientID variables.
      //
      StringBuilder              sbRP1210DeviceDLL = new StringBuilder(100);
      short                      nDeviceID         = 0;
      short                      nClientIDJ1939    = 0;
      short                      nClientIDJ1708    = 0;
      //
      // J1708/J1587 and J1939 addresses.
      //
      byte                       ucJ1939Address    = RP1210.J1939_OFFBOARD_DIAGNOSTICS_TOOL_1;
      byte                       ucJ1708Address    = RP1210.J1708_OFFBOARD_DIAGNOSTICS_TOOL_1;
      //
      // Return value for RP1210 functions, and declare a send/read message buffer.
      //
      short                      nRetVal           = 0;
      byte[]                     ucTxRxMessage     = new byte[2000];
      //
      // Values for RP1210_ReadDetailedVersion().
      //
      StringBuilder              sbAPIVer          = new StringBuilder(100);
      StringBuilder              sbDLLVer          = new StringBuilder(100);
      StringBuilder              sbFWVer           = new StringBuilder(100);
      //
      // Define a message structure to hold the decoded fields of a message.
      //
      RP1210_Class.sJ1939Message sJ1939Msg ;
      RP1210_Class.sJ1708Message sJ1708Msg ;
      //
      // Generic variables.
      //
      String                     sUserInput        = "";
      int                        iUserChosenAPI    = 0;
      StringBuilder              NullString        = new StringBuilder(100);
      //
      // Variables for sending request messages every 5 seconds.
      //
      DateTime                   dttLastTimeRequestsSent ;
      TimeSpan                   tsDiffInSeconds         ;

      //
      // Write the program identification to the screen.
      //
      Console.WriteLine( PROGRAM_ID );

      //
      // Have the user select the adapter they want to use and set sbRP1210DeviceDLL.
      //
      do 
        {
          Console.WriteLine( "                                                                       " );
          Console.WriteLine( "---------------------------------------------------------------------- " );
          Console.WriteLine( " Select Adapter To Use                                                 " );
          Console.WriteLine( "---------------------------------------------------------------------- " );
          Console.WriteLine( "                                                                       " );
          Console.WriteLine( " 1 = DPA 4 Plus Multi-Application           ( DLL Name =  DPA4PMA.DLL )" );
          Console.WriteLine( " 2 = DPA 5      Multi-Application           ( DLL Name = DGDPA5MA.DLL )" );
          Console.WriteLine( " 3 = DPA 4 Plus And Prior DPAs              ( DLL Name = DG121032.DLL )" );
          Console.WriteLine( " 4 = Allison DR Drivers (DPA 4 Plus/DPA 5 ) ( DLL Name = DR121032.DLL )" );
          Console.WriteLine( " 5 = d-briDGe   Multi-Application           ( DLL Name = DBRIDGEM.DLL )" );
          Console.WriteLine( " 6 = Netbridge  Multi-Application           ( DLL Name = NBRIDGEM.DLL )" );
          Console.WriteLine( "                                                                       " );
          Console.Write    ( "->  " );
          
          sUserInput = Console.ReadLine();

          if( sUserInput != null ) 
            {
              iUserChosenAPI = Convert.ToInt32( sUserInput );
              
              switch( iUserChosenAPI )
                {
                case 1: sbRP1210DeviceDLL.Append("DPA4PMA.DLL"  ); break;
                case 2: sbRP1210DeviceDLL.Append("DGDPA5MA.DLL" ); break;
                case 3: sbRP1210DeviceDLL.Append("DG121032.DLL" ); break;
                case 4: sbRP1210DeviceDLL.Append("DR121032.DLL" ); break;
                case 5: sbRP1210DeviceDLL.Append("DBRIDGEM.DLL" ); break;
                case 6: sbRP1210DeviceDLL.Append("NBRIDGEM.DLL" ); break;
                }
            }
          
        } while( iUserChosenAPI < 1 || iUserChosenAPI > 6 );

      //
      // Attempt loading the DLL and setting all of the function pointers.
      //
      if( false == RP1210.LoadDLLAndFunctions( sbRP1210DeviceDLL.ToString() ) )
        {
          Console.WriteLine( "FAILURE loading DLL {0}.", sbRP1210DeviceDLL );
          return 1;
        }

      //
      // Have the user select the device number that they want to connect to.
      //
      do
        {
          Console.WriteLine( "                                                                      " );
          Console.WriteLine( "--------------------------------------------------------------------- " );
          Console.WriteLine( " Select Device To Use                                                 " );
          Console.WriteLine( "--------------------------------------------------------------------- " );
          Console.WriteLine( "                                                                      " );
          
          if(      ( iUserChosenAPI == 1 ) ) 
            { 
              Console.WriteLine( " Common DPA 4 Plus Multi-Application Devices                      " );
              Console.WriteLine( "     1   =  DPA 4 Plus - USB                                      " );
            }
          else if( ( iUserChosenAPI == 2 ) ) 
            { 
              Console.WriteLine( " Common DPA 5 Multi-Application Devices                           " );
              Console.WriteLine( "       1 =  DPA 5 - USB                                           " );
            }
          else if( ( iUserChosenAPI == 3) )
            { 
              Console.WriteLine( " Common DG121032.ini Devices                                      " );
              Console.WriteLine( "     150 =  DPA 4/4 Plus USB                                      " );
              Console.WriteLine( "     101 =  DPA II/II+/III+ Serial Using COM1                     " );
              Console.WriteLine( "     102 =  DPA II/II+/III+ Serial Using COM2                     " );
            }
          else if( ( iUserChosenAPI == 4 ) )
            { 
              Console.WriteLine( " Common DR121032.ini Devices                                      " );
              Console.WriteLine( "     150 =  DPA 4 USB                                             " );
              Console.WriteLine( "     151 =  DPA 4 Plus USB and DPA 5 USB                          " );
            }
          else if( ( iUserChosenAPI == 5 ) )
            { 
              Console.WriteLine( " Common DBRIDGEM.ini Devices                                      " );
              Console.WriteLine( "       3 = d-briDGe                                               " );
            }
          else if( ( iUserChosenAPI == 6 ) )
            { 
              Console.WriteLine( " Common NBRIDGEM.ini Devices                                      " );
              Console.WriteLine( "       2 = Netbridge                                              " );
            }
          
          Console.WriteLine( "                                                                      " );
          Console.WriteLine( " These are the most common DG devices based on the DLL selected.      " );
          Console.WriteLine( " Other device numbers may exist in that INI file such as Bluetooth    " );
          Console.WriteLine( " entries for the DPA 5 ( beginning at 160 ).                          " );
          Console.WriteLine( "                                                                      " );
          Console.WriteLine( " Please enter the device number you would like to use.                " );
          Console.WriteLine( "                                                                      " );
          Console.Write    ( "->  " );
          
          sUserInput = Console.ReadLine();
          
          if ( sUserInput != null ) 
            {
              nDeviceID = Convert.ToInt16( sUserInput );
              
              if( nDeviceID > 0 )
                break;
            }

        } while( true );

      //
      // Attempt connect to J1939 protocol and then claiming J1939 address if successful.
      //
      nClientIDJ1939 = RP1210.pRP1210_ClientConnect(IntPtr.Zero, nDeviceID, new StringBuilder("J1939"), 0, 0, 0);

      if( ( nClientIDJ1939 >= 0 ) && ( nClientIDJ1939 <= 127 ) )
        {
          Console.WriteLine( "SUCCESS - RP1210_ClientConnect( J1939 ) to DeviceID {0}", nDeviceID.ToString() );

          if( false == RP1210.ClaimJ1939Address( nClientIDJ1939, ucJ1939Address) )
          {
            Console.WriteLine( "WARNING - Cannot claim J1939 address {0}.", ucJ1939Address.ToString() );
          }
        }
      else
        {
          Console.WriteLine( "FAILURE - RP1210_ClientConnect( J1939 ) to DeviceID {0}", nDeviceID.ToString() );

          RP1210.pRP1210_ClientDisconnect(nClientIDJ1939);
          
          RP1210.FreeLibraryAndFunctions();

          return 1;
        }

      //
      // Attempt to connect to J1708 protocol.  
      //
      nClientIDJ1708 = RP1210.pRP1210_ClientConnect(IntPtr.Zero, nDeviceID, new StringBuilder("J1708"), 0, 0, 0);

      if ( ( nClientIDJ1708 >= 0 ) && ( nClientIDJ1708 <= 127 ) )
        {
          Console.WriteLine( "SUCCESS - RP1210_ClientConnect( J1708 ) to DeviceID {0}", nDeviceID.ToString() );
        }
      else
        {
          Console.WriteLine( "FAILURE - RP1210_ClientConnect( J1708 ) to DeviceID {0}", nDeviceID.ToString() );

          RP1210.pRP1210_ClientDisconnect(nClientIDJ1708);
          
          RP1210.FreeLibraryAndFunctions();

          return 1;
        }
      
      //
      // Read the detailed version information about the DLL and adapter and write it to the scren.
      //
      RP1210.pRP1210_ReadDetailedVersion( nClientIDJ1939, sbAPIVer, sbDLLVer, sbFWVer );

      Console.WriteLine("RP1210_ReadDetailedVersion:  API({0}) DLL({1}) FW({2})", sbAPIVer.ToString(), sbDLLVer.ToString(), sbFWVer.ToString());
      
      //
      // Set all filter states to pass on J1939 so we can read messages.
      //
      nRetVal = RP1210.pRP1210_SendCommand(RP1210.RP1210_Set_All_Filters_States_to_Pass, nClientIDJ1939, NullString, 0);

      if( nRetVal != 0 )
        {
          Console.WriteLine( "FAILURE - RP1210_Set_All_Filters_States_to_Pass( J1939 )");
        }
      else
        {
          Console.WriteLine( "SUCCESS - RP1210_Set_All_Filters_States_to_Pass( J1939 )");
        }

      //
      // Set all filter states to pass on J1708 so we can read messages.
      //
      nRetVal = RP1210.pRP1210_SendCommand(RP1210.RP1210_Set_All_Filters_States_to_Pass, nClientIDJ1708, NullString, 0);

      if( nRetVal != 0 )
        {
          Console.WriteLine( "FAILURE - RP1210_Set_All_Filters_States_to_Pass( J1708 )");
        }
      else
        {
          Console.WriteLine( "SUCCESS - RP1210_Set_All_Filters_States_to_Pass( J1708 )");
        }
      
      //
      // Let the user know how to exit the program.
      //
      Console.WriteLine( "---------------------------------------------------------------------" );
      Console.WriteLine( " Ready to begin.  Press \"Enter\" to start, any key exits program.   " );
      Console.WriteLine( "            Press \"Ctrl-S\" to freeze the screen.                   " );
      Console.WriteLine( "---------------------------------------------------------------------" );
      Console.Write    ( ">" );
      
      sUserInput = Console.ReadLine();
      
      //
      // Get the time now.
      //
      dttLastTimeRequestsSent = DateTime.Now;

      //
      // Forever.  Read/process messages until a ERR_HARDWARE_NOT_RESPONDING or a keystroke.
      //
      do
        {

          //
          // Get the time now and see if it has been over 5 seconds.
          //
          tsDiffInSeconds = DateTime.Now - dttLastTimeRequestsSent;
          
          if( tsDiffInSeconds.Seconds > 5 )
            {
              //
              // Request the VIN from the J1939 (global address) and J1708/J1587 network.
              //
              RP1210.SendJ1939RequestPGN( nClientIDJ1939, ucJ1939Address, 255, 65260 ); // VIN request.
              RP1210.SendJ1708RequestPID( nClientIDJ1708, ucJ1708Address,        237 ); // VIN request.

              dttLastTimeRequestsSent = DateTime.Now;
            }

          //
          // Read a J1939 message and print it to the screen if a message is available.
          //
          nRetVal = RP1210.pRP1210_ReadMessage( nClientIDJ1939, ucTxRxMessage, 2000, 0);

          if( nRetVal == -(RP1210.ERR_HARDWARE_NOT_RESPONDING) )
            break;
          
          if( nRetVal > 0 )
            {
              sJ1939Msg = RP1210.DecodeRxJ1939Message( ucTxRxMessage, nRetVal, nClientIDJ1939 );

              RP1210.PrintJ1939RxMessage  ( sJ1939Msg );

              RP1210.ProcessJ1939RxMessage( sJ1939Msg );
            }

          //
          // Read a J1708 message and print it to the screen if a message is available.
          //
          nRetVal = RP1210.pRP1210_ReadMessage(nClientIDJ1708, ucTxRxMessage, 2000, 0);

          if( nRetVal == -(RP1210.ERR_HARDWARE_NOT_RESPONDING) )
            break;
          
          if( nRetVal > 0 )
            {
              sJ1708Msg = RP1210.DecodeRxJ1708Message( ucTxRxMessage, nRetVal, nClientIDJ1708 );
              
              RP1210.PrintJ1708RxMessage  ( sJ1708Msg );

              RP1210.ProcessJ1708RxMessage( sJ1708Msg );
            }

          //
          // If a key is pressed, exit cleanly.
          //
          if( _kbhit() != 0 )
            break;
          
        } while ( true );
      
      //
      // Disconnect and free the DLL.
      //
      RP1210.pRP1210_ClientDisconnect(nClientIDJ1939);
      RP1210.pRP1210_ClientDisconnect(nClientIDJ1708);
      RP1210.FreeLibraryAndFunctions();

      //
      // Return success to the operating system.
      //
      return 0;
    }
  }
}
