% Example Matlab script program for DPA5 J2534 interface.
% The function DPA5_PassThruWriteMsgs writes a message on CAN.
% You must run script DPA5Start before running this script.
% 
% ***************************************************************************************
% Version 1.1 of 2013-05-01 markc added comments
% Version 1.0 of 2011-01-28 markc initial open-connect-filter-read working
% ***************************************************************************************
% Copyright (C) 2011 DG Technologies, Inc. All Rights Reserved.
% The copyright notice here does not evidence any actual or intended publication.
% This code is provided "as-is".
% No claims are made concerning suitability for any given purpose.
% ***************************************************************************************

if not(libisloaded('DGDPA532'))
	return;
end


WMsg(1) = libstruct('PASSTHRU_MSG');
WMsg(1).ucData(12) = 0
WMsg(1).ulProtocolID = nProtocol
WMsg(1).ucData(1) = 0
WMsg(1).ucData(2) = 0
WMsg(1).ucData(3) = 7
WMsg(1).ucData(4) = 224
WMsg(1).ucData(5) = 16
WMsg(1).ucData(6) = 2
WMsg(1).ucData(7) = 17
WMsg(1).ucData(8) = 18
WMsg(1).ulDataSize = 8


% set the number of message to read
ulNum = 1
% set 500ms timeout
ulTimeout = 500 
[error, WMsg(1), ulNum] = calllib('DGDPA532', 'PassThruWriteMsgs', ulChannelID, WMsg(1), ulNum, ulTimeout)
if (strcmp(error,'J2534_STATUS_NOERROR'))
	format hex
	WMsg(1).ucData
end
