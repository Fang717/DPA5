﻿// ----------------------------------------------------------------------------------------------------
//  DG Technologies - J2534 Sample Source Code C# - Copyright (c) 2014 - Dearborn Group, Inc.
// ----------------------------------------------------------------------------------------------------
// 
//  Name:           J2534SampleCodeCSharp.cs  Version 1.00
// 
//  Date:           February 15, 2014
// 
//  Written By:     Kenneth L. DeGrant II
//                  Field Applications Engineering Manager
//                  DG Technologies
//                  33604 West 8 Mile Road
//                  Farmington Hills, MI  48335
//                  kdegrant@dgtech.com
// 
//  Description:    This code is provided by Dearborn Group, Inc. to assist application developers in 
//                  developing J2534 applications for Dearborn Group J2534 devices.  It allows 
//                  connecting to the ISO15765 protocol at 500k with Standard (11-bit) CAN 
//                  identifiers.  It shows how to set flow control filters for all ISO15765-4
//                  test equipment addresses to the address from the physical ECUs.
//
//                        External Test Equipment      Physical Response CANID
//                        -----------------------      -----------------------
//                               0x7E0                         0x7E8
//                               0x7E1                         0x7E9
//                               0x7E2                         0x7EA
//                               0x7E3                         0x7EB
//                               0x7E4                         0x7EC
//                               0x7E5                         0x7ED
//                               0x7E6                         0x7EE
//                               0x7E7                         0x7EF
//
//                  After the flow control filters are set up, the program will send out the 
//                  J1979 request for supported PID values in Mode 1 (Mode 1, PID 0) every
//                  several seconds and process the responses.  This is sometimes called the tester
//                  present message.  
//
// Code Notes:      All necessary code for this project is in this file.  Because this program
//                  runs on a DOS command prompt, it can be readily adapted to do any basic 
//                  functionality that a developer unfamiliar with J2534 might want to do, and without
//                  having to look at complex MFC, Visual Basic, C#, or other "GUI" code.  
//
//                  You may have to set your target EXE type to x86 to get the code to run properly.
//                  If LoadLibrary() fails, this is your indication.
//
//  Requirements:   This program requires that you have downloaded and installed the latest J2534 
//                  drivers for one of the following products:
//
//                     * DG DPA 5                ( DLL Name = DGDPA532.DLL   )
//                     * VSI-2534                ( DLL Name = DGVSI32.DLL    )
//                     * d-briDGe                ( DLL Name = DBRIDGE.DLL    )
//                     * Netbridge               ( DLL Name = NBRIDGE.DLL    )
//                     * Softbridge              ( DLL Name = SOFTBRIDGE.DLL )
//                     * Gryphon, G2, S3, S4     ( DLL Name = J2534G32.DLL   )
//
//                  Drivers are available from the DG Technologies website as follows:
//                               http://www.dgtech.com/download.php
//
//  No Liability:   This code is example code and is NOT warranted to be fit for any particular use 
//                  or purpose.  DG Technologies will not be held liable for any use or 
//                  misuse of this code "under any circumstances whatsoever".  
// 
//  Notes:          Be sure to have your DOS command prompt set to a width of at least 150, as the 
//                  program displays about 140 contiguous characters from a J1939 message.
// 
//                  It is possible to develop a completely J2534 compliant application that
//                  will not connect, send or read messages to or from a particular databus.  
//                  To ensure success, please read the documentation for the protocol you want to use 
//                  thoroughly along with reading the "complete" J2534 document before trying to 
//                  adapt this code to a particular purpose.
//
//  Copyright:      This code is copyrighted by Dearborn Group, Inc., and is intended
//                  solely for the use of our DPA customers or potential DPA customers.  No portion,
//                  including "snippets" of this code are to be used, investigated, or copied in any 
//                  shape, form, or fashion, by anyone who is, or may in the future be, in competition 
//                  with DG Technologies in any way.  The code shall also not be modified in
//                  a way that it is capable of being used with any Vehicle Diagnostic Adapter (VDA)
//                  outside of one from Dearborn Group, Inc.
//
// ----------------------------------------------------------------------------------------------------
//  Revision  Date       Notes
//     1.0    02-17-14   Original Version.
// ----------------------------------------------------------------------------------------------------
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Globalization;

namespace CSharpTest
{
  public class J2534_Class
  {
    //-----------------------------------------------------------------------------------------------------
    // J2534   J2534 definitions.
    //-----------------------------------------------------------------------------------------------------

    //
    // Protocol definitions 
    //
    public UInt32 J1850VPW                               =  1;
    public UInt32 J1850PWM                               =  2;
    public UInt32 ISO9141                                =  3;
    public UInt32 ISO14230                               =  4;
    public UInt32 CAN                                    =  5;
    public UInt32 ISO15765                               =  6;
    public UInt32 SCI_A_ENGINE                           =  7;
    public UInt32 SCI_A_TRANS                            =  8;
    public UInt32 SCI_B_ENGINE                           =  9;
    public UInt32 SCI_B_TRANS                            = 10;
    //
    // IOCTL IDs
    //
    public UInt32 GET_CONFIG                             =  1;
    public UInt32 SET_CONFIG                             =  2;
    public UInt32 READ_VBATT                             =  3;
    public UInt32 FIVE_BAUD_INIT                         =  4;
    public UInt32 FAST_INIT                              =  5;
    public UInt32 SET_PIN_USE                            =  6;
    public UInt32 CLEAR_TX_BUFFER                        =  7;
    public UInt32 CLEAR_RX_BUFFER                        =  8;
    public UInt32 CLEAR_PERIODIC_MSGS                    =  9;
    public UInt32 CLEAR_MSG_FILTERS                      = 10;
    public UInt32 CLEAR_FUNCT_MSG_LOOKUP_TABLE           = 11;
    public UInt32 ADD_TO_FUNCT_MSG_LOOKUP_TABLE          = 12;
    public UInt32 DELETE_FROM_FUNCT_MSG_LOOKUP_TABLE     = 13;
    public UInt32 READ_PROG_VOLTAGE                      = 14;
    //
    // Configuration Parameter IDs
    //
    public UInt32 CAN_ID_BOTH                            = 0x0400;
    public UInt32 DATA_RATE                              = 1;
    public UInt32 LOOPBACK                               = 3;
    public UInt32 NODE_ADDRESS                           = 4;
    public UInt32 NETWORK_LINE                           = 5;
    public UInt32 P1_MIN                                 = 6;
    public UInt32 P1_MAX                                 = 7;
    public UInt32 P2_MIN                                 = 8;
    public UInt32 P2_MAX                                 = 9;
    public UInt32 P3_MIN                                 = 10;
    public UInt32 P3_MAX                                 = 11;
    public UInt32 P4_MIN                                 = 12;
    public UInt32 P4_MAX                                 = 13;
    public UInt32 W1                                     = 14;
    public UInt32 W2                                     = 15;
    public UInt32 W3                                     = 16;
    public UInt32 W4                                     = 17;
    public UInt32 W5                                     = 18;
    public UInt32 TIDLE                                  = 19;
    public UInt32 TINIL                                  = 20;
    public UInt32 TWUP                                   = 21;
    public UInt32 PARITY                                 = 22;
    public UInt32 BIT_SAMPLE_POINT                       = 23;
    public UInt32 SYNC_JUMP_WIDTH                        = 24;
    public UInt32 T1_MAX                                 = 26;
    public UInt32 T2_MAX                                 = 27;
    public UInt32 T4_MAX                                 = 28;
    public UInt32 T5_MAX                                 = 29;
    public UInt32 ISO15765_BS                            = 30;
    public UInt32 ISO15765_STMIN                         = 31;
    public UInt32 DATA_BITS                              = 32;
    public UInt32 FIVE_BAUD_MOD                          = 33;
    public UInt32 BS_TX                                  = 34;
    public UInt32 STMIN_TX                               = 35;
    public UInt32 T3_MAX                                 = 36;
    public UInt32 ISO15765_WFT_MAX                       = 37;
    //
    // Error IDs
    //
    public UInt32 STATUS_NOERROR                         = 0;
    public UInt32 ERR_NOT_SUPPORTED                      = 1;
    public UInt32 ERR_INVALID_CHANNEL_ID                 = 2;
    public UInt32 ERR_INVALID_PROTOCOL_ID                = 3;
    public UInt32 ERR_NULL_PARAMETER                     = 4;
    public UInt32 ERR_INVALID_IOCTL                      = 5;
    public UInt32 ERR_INVALID_FLAGS                      = 6;
    public UInt32 ERR_FAILED                             = 7;
    public UInt32 ERR_DEVICE_NOT_CONNECTED               = 8;
    public UInt32 ERR_TIMEOUT                            = 9;
    public UInt32 ERR_INVALID_MSG                        = 10;
    public UInt32 ERR_INVALID_TIME_INTERVAL              = 11;
    public UInt32 ERR_EXCEEDED_LIMIT                     = 12;
    public UInt32 ERR_INVALID_MSG_ID                     = 13;
    public UInt32 ERR_INVALID_ERROR_ID                   = 14;
    public UInt32 ERR_INVALID_IOCTL_ID                   = 15;
    public UInt32 ERR_BUFFER_EMPTY                       = 16;
    public UInt32 ERR_BUFFER_FULL                        = 17;
    public UInt32 ERR_BUFFER_OVERFLOW                    = 18;
    public UInt32 ERR_PIN_INVALID                        = 19;
    public UInt32 ERR_CHANNEL_IN_USE                     = 20;
    public UInt32 ERR_MSG_PROTOCOL_ID                    = 21;
    //
    //  Miscellaneous definitions 
    //
    public UInt32 SHORT_TO_GROUND                        = 0xFFFFFFFE;
    public UInt32 VOLTAGE_OFF                            = 0xFFFFFFFF;
    //
    // RxStatus definitions 
    //
    public UInt32 TX_MSG_TYPE                            = 0x00000001;
    public UInt32 ISO15765_FIRST_FRAME                   = 0x00000002;
    public UInt32 RX_BREAK                               = 0x00000004;
    public UInt32 ISO15765_TX_DONE                       = 0x00000008;
    //
    // TxFlags definitions
    //
    public UInt32 TX_NORMAL_TRANSMIT                     = 0x00000000;
    public UInt32 ISO15765_FRAME_PAD                     = 0x00000040;
    public UInt32 ISO15765_EXT_ADDR                      = 0x00000080;
    //
    public UInt32 TX_STANDARD_CAN                        = 0x00;
    public UInt32 TX_EXTENDED_CAN                        = 0x80;
    //
    public UInt32 CAN_29BIT_ID                           = 0x80;
    public UInt32 CAN_11BIT_ID                           = 0x00;
    //
    public UInt32 TX_BLOCKING                            = 0x00010000;
    public UInt32 SCI_TX_VOLTAGE                         = 0x00800000;
    //
    // Filter definitions 
    //
    public UInt32 PASS_FILTER                            = 0x00000001;
    public UInt32 BLOCK_FILTER                           = 0x00000002;
    public UInt32 FLOW_CONTROL_FILTER                    = 0x00000003;

    //
    // PASSTHRU_MSG - Declared as a "class".  The constructor allocates memory for the Data array.
    //
    //   Note that this is how you declare a structure to be on a 1-byte boundary.
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct PASSTHRU_MSG
    {
      public UInt32      ProtocolID       ;
      public UInt32      RxStatus         ;
      public UInt32      TxFlags          ;
      public UInt32      Timestamp        ;
      public UInt32      DataSize         ;
      public UInt32      ExtraDataIndex   ;
      //
      // This Marshal statement tells the compiler that the array will be 4128 bytes
      //   so that when this is converted to an unmanaged structure, a size will 
      //   be known.  Note how variables of this type are declared below.
      //
      [MarshalAs(UnmanagedType.ByValArray, SizeConst=4128)]
      public byte[]      Data;
    }
    /*
    //
    // SCONFIG IOCTL Structures
    //
    struct SCONFIG
    {
      UInt32   Parameter        ;
      UInt32   Value            ;
    }
    //
    // SCONFIG_LIST
    //
    struct SCONFIG_LIST
    {
      UInt32   NumOfParams;
      IntPtr   ConfigPtr  ;// SCONFIG *
    } 
    //
    // SBYTE_ARRAY
    //
    struct SBYTE_ARRAY
    {
      UInt32  NumOfBytes      ;
      byte[]  BytePtr         ;
    }
    //
    // SPIN_CONTROL
    //
    struct SPIN_CONTROL
    {
      UInt32  NumOfPins       ;
      byte[]  PinUsePtr       ;
    }
    //
    // SPIN_USE
    //
    struct SPIN_USE
    {
      UInt32 PinNumber        ;
      UInt32 PinUse           ;
      UInt32 Parameter        ;
    }
    */
 
    //------------------------------------------------------------------------------------------
    // Import the LoadLibrary(), GetProcAddress(), and FreeLibrary() calls from Kernel32.DLL.
    //------------------------------------------------------------------------------------------
    
    [DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern IntPtr LoadLibrary(string dllToLoad);
    
    [DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern IntPtr GetProcAddress(IntPtr hModule, string procName);
    
    [DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern bool FreeLibrary(IntPtr hModule);

    //--------------------------------------------------------------
    // J2534 Function Prototypes.  IntPtr for all PASSTHRU_MSG *,
    //   and ref for all unsigned long * variables.
    //--------------------------------------------------------------
    
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruOpen(IntPtr pName, ref UInt32 pDeviceID);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruClose(UInt32 DeviceID);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruConnect(UInt32 DeviceID, UInt32 ProtoID, UInt32 Flags,UInt32 BaudRate,ref UInt32 pChanID);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruDisconnect(UInt32 ChannelID);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruReadMsgs(UInt32 ChannelID, IntPtr pMsg,ref UInt32 pNumMsgs,UInt32 Timeout);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruWriteMsgs(UInt32 ChannelID, IntPtr pMsg, ref UInt32 pNumMsgs, UInt32 Timeout);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruStartPeriodicMsg(UInt32 ChannelID,IntPtr pMsg,ref UInt32 pMsgID, UInt32 TimeIntvl);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruStopPeriodicMsg(UInt32 ChannelID, UInt32 MsgID);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruStartMsgFilter(UInt32 ChannelID, UInt32 FiltType,IntPtr pMask,IntPtr pPatt,IntPtr pFlowCon,ref UInt32 pFilterID);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruStopMsgFilter(UInt32 ChannelID, UInt32 FilterID);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruSetProgrammingVoltage(UInt32 DeviceID, UInt32 PinNumber, UInt32 Voltage);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruReadVersion(UInt32 DeviceID, StringBuilder pFWVer,StringBuilder pDLLVer,StringBuilder pAPIVer);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruGetLastError(StringBuilder pErrDesc);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate UInt32 PassThruIoctl(UInt32 ChannelID,UInt32 IOCTLID,byte[] pInput,byte[] pOutput);
    
    //------------------------------------------------------------------
    // J2534 Function Pointer Definitions and then Function Variables
    //------------------------------------------------------------------
    
    public IntPtr                        pDLL                            ;

    public IntPtr                        fpPassThruOpen                  ;
    public IntPtr                        fpPassThruClose                 ;
    public IntPtr                        fpPassThruConnect               ;
    public IntPtr                        fpPassThruDisconnect            ;
    public IntPtr                        fpPassThruReadMsgs              ;
    public IntPtr                        fpPassThruWriteMsgs             ;
    public IntPtr                        fpPassThruStartPeriodicMsg      ;
    public IntPtr                        fpPassThruStopPeriodicMsg       ;
    public IntPtr                        fpPassThruStartMsgFilter        ;
    public IntPtr                        fpPassThruStopMsgFilter         ;
    public IntPtr                        fpPassThruSetProgrammingVoltage ;
    public IntPtr                        fpPassThruReadVersion           ;
    public IntPtr                        fpPassThruGetLastError          ;
    public IntPtr                        fpPassThruIoctl                 ;

    public PassThruOpen                  pPassThruOpen                   ;
    public PassThruClose                 pPassThruClose                  ;
    public PassThruConnect               pPassThruConnect                ;
    public PassThruDisconnect            pPassThruDisconnect             ;
    public PassThruReadMsgs              pPassThruReadMsgs               ;
    public PassThruWriteMsgs             pPassThruWriteMsgs              ;
    public PassThruStartPeriodicMsg      pPassThruStartPeriodicMsg       ;
    public PassThruStopPeriodicMsg       pPassThruStopPeriodicMsg        ;
    public PassThruStartMsgFilter        pPassThruStartMsgFilter         ;
    public PassThruStopMsgFilter         pPassThruStopMsgFilter          ;
    public PassThruSetProgrammingVoltage pPassThruSetProgrammingVoltage  ;
    public PassThruReadVersion           pPassThruReadVersion            ;
    public PassThruGetLastError          pPassThruGetLastError           ;
    public PassThruIoctl                 pPassThruIoctl                  ;

    // ----------------------------------------------------------------------
    // Unpack a four-byte integer that has been sent MSB first.
    // ----------------------------------------------------------------------
    public UInt32 UnPackFourByteIntegerMSB( byte[] ucIntString, short nStartIdx)
    {
      UInt32 iValue = 0;
      
      iValue = (UInt32)((ucIntString[0] << 24 )|(ucIntString[1] << 16 )|(ucIntString[2] << 8  )|(ucIntString[3] ));
      
      return iValue;
    }

    //    
    //****************************************************************************************************
    //****************************************************************************************************
    // ISO15765 11-bit Section
    //****************************************************************************************************
    //****************************************************************************************************
    //

    //================================================================================
    // Request Mode Supported PIDS
    //================================================================================

    public bool RequestModeSupportedPIDS( UInt32 ulProtocolID, UInt32 ulChannelID, UInt32 ulTesterCANID, byte ucMode)
    {
      UInt32            ulNumMessages    = 1;
      UInt32            ulRetVal         = 0;
      PASSTHRU_MSG      sSendMessage     = new PASSTHRU_MSG{ Data = new byte[4128]};
      StringBuilder     szErrMsg         = new StringBuilder(256);
      int               iSizeOfPTM       = 0; 
      IntPtr            pMsg             = IntPtr.Zero;
      
      // 
      // Set up the message header to send.
      //
      sSendMessage.ProtocolID         = ISO15765            ;
      sSendMessage.RxStatus           = 0x00000000          ;
      sSendMessage.ExtraDataIndex     = 0x00000000          ;
      sSendMessage.Timestamp          = 0x00000000          ;
      sSendMessage.TxFlags            = ISO15765_FRAME_PAD  ;
      
      //
      // CANID is always 4 bytes even though we are using 11-bit.
      //
      sSendMessage.Data[0]            = (byte) (( ulTesterCANID & 0xFF000000 ) >> 24);
      sSendMessage.Data[1]            = (byte) (( ulTesterCANID & 0x00FF0000 ) >> 16);
      sSendMessage.Data[2]            = (byte) (( ulTesterCANID & 0x0000FF00 ) >>  8);
      sSendMessage.Data[3]            = (byte) (( ulTesterCANID & 0x000000FF ) >>  0);
      
      //
      // Requests for all PIDS take two messages:
      //     Msg1=(0x00, 0x20, 0x40, 0x60, 0x80, 0xA0)
      //     Msg2=(0xC0, 0xE0)
      //   This app only sends the first message.
      //
      sSendMessage.Data[4]   = ucMode; // DB1
      sSendMessage.Data[5]   = 0x00;   // DB2
      sSendMessage.Data[6]   = 0x20;   // DB3
      sSendMessage.Data[7]   = 0x40;   // DB4
      sSendMessage.Data[8]   = 0x60;   // DB5
      sSendMessage.Data[9]   = 0x80;   // DB6
      sSendMessage.Data[10]  = 0xA0;   // DB7
      sSendMessage.DataSize  = 11;

      //
      // To pass the address of a structure in C# to a C++ DLL, this is required.
      //      
      iSizeOfPTM              = Marshal.SizeOf( typeof(PASSTHRU_MSG) ); 
      pMsg                    = Marshal.AllocHGlobal( iSizeOfPTM     );
      Marshal.StructureToPtr( sSendMessage, pMsg, false);

      //
      // Write the message.
      //
      ulRetVal = pPassThruWriteMsgs( ulChannelID, pMsg, ref ulNumMessages, 1000 );

      //
      // Put message from pMsg into the sSendMessage structure.
      //
      sSendMessage = (PASSTHRU_MSG) Marshal.PtrToStructure(pMsg, typeof(PASSTHRU_MSG));
      
      if( STATUS_NOERROR != ulRetVal )
        {
          pPassThruGetLastError( szErrMsg );
          
          Console.WriteLine( "RequestModeSupportedPIDS(Mode={0} PassThruWriteMsgs() Returned Failure of {1}.  Msg={2}", ucMode, ulRetVal, szErrMsg  );
          
          Marshal.FreeHGlobal( pMsg );

          return false;
        }
      else
        {
          //
          // Write the message to the screen.
          //
          PrintTxISO15765Message( sSendMessage );
        }
      
      //
      // Read and process ISO15765 messages until the buffer is empty.
      //
      ReadAndProcessISO15765Messages( ulProtocolID, ulChannelID );

      //
      // Release the memory.
      //      
      Marshal.FreeHGlobal( pMsg );

      return true;

    }//RequestModeSupportedPIDS
    
    //------------------------------------------------------------------------------------------------------------------
    // PrintTxISO15765Message - Print a message that was sent on the ISO15765 bus.
    //------------------------------------------------------------------------------------------------------------------
    
    public bool PrintTxISO15765Message( PASSTHRU_MSG sSentMsg )
    {
      int       i                      = 0;
      int       j                      = 0;
      UInt32    nDataBytesIndex        = 0;
      UInt32    nNumDataBytes          = 0;
      UInt32    iCANID                 = 0;
      
      //
      // Unpack the CANID.  It is always 4 bytes even when using 11-bit.
      //
      iCANID          = UnPackFourByteIntegerMSB( sSentMsg.Data, 0 );
      
      //
      // Data bytes will start appearing at index 4.
      //
      nDataBytesIndex = 4;
      
      //
      // Calculate the number of data bytes in the message.
      //
      nNumDataBytes   = sSentMsg.DataSize - nDataBytesIndex;
      
      //
      // Print the string to the FILE pointers and to the variable szMsgString.
      //
      Console.WriteLine( "Tx ISO15765 CANID=[{0}] TxFlags=[{1}] DataLen=[{2}]", iCANID.ToString("X8"), sSentMsg.TxFlags.ToString("X8"), nNumDataBytes.ToString("D4") );
      
      //
      // If data bytes exist (some messages are just indications), print the data bytes as well.
      //  
      if( nNumDataBytes > 0 )
        {
          Console.Write("    DATA");
          
          for( j = 0, i = (int) nDataBytesIndex; j < (int) nNumDataBytes; j++, i++)
            {
              Console.Write("[{0}]", sSentMsg.Data[i].ToString("X2") );
            }
        }
      
      //
      // Terminate the line with a newline.  
      //
      Console.WriteLine();
      Console.WriteLine();
      
      return true;

    }//PrintTxISO15765Message
    
    //------------------------------------------------------------------------------------------------------------------
    // ReadAndProcessISO15765Messages - Since the PassThruReadMsgs may return status indicators and some requests
    //                                  may return more than one message, this function reads messages until the 
    //                                  buffer is empty.  On each message, it is handled to a "Process" routine
    //                                  that looks for specific PID responses (i.e. 0x41).
    //------------------------------------------------------------------------------------------------------------------
    
    public bool ReadAndProcessISO15765Messages( UInt32 ulProtocolID, UInt32 ulChannelID )
    {
      PASSTHRU_MSG     sReadMessage      = new PASSTHRU_MSG{ Data = new byte[4128]};
      UInt32           ulRetVal          = 0;
      UInt32           ulNumMessages     = 1;
      int              iSizeOfPTM        = 0; 
      IntPtr           pMsg              = IntPtr.Zero;

      //
      // Read messages until dry.
      //
      do
        {
          //
          // Setup to read 1 message with a 250ms timeout value.
          //
          ulNumMessages = 1;
          
          sReadMessage.ProtocolID = ulProtocolID;
          
          //
          // To pass the address of a structure in C# to a C++ DLL, this is required.
          //      
          iSizeOfPTM              = Marshal.SizeOf( typeof(PASSTHRU_MSG) ); 
          pMsg                    = Marshal.AllocHGlobal( iSizeOfPTM     );
          Marshal.StructureToPtr( sReadMessage, pMsg, false);

          //
          // Attempt to read a message.
          //
          ulRetVal = pPassThruReadMsgs( ulChannelID, pMsg, ref ulNumMessages, 250 );
          
          //
          // Put the message from pMsg back into the sReadMessage structure.
          //
          sReadMessage = (PASSTHRU_MSG) Marshal.PtrToStructure( pMsg, typeof(PASSTHRU_MSG) );

          if( ulRetVal == ERR_BUFFER_EMPTY )
            {
              Console.WriteLine("Rx TS=[{0}] ** Buffer Empty", sReadMessage.Timestamp.ToString("D10") );      
              Console.WriteLine();
              break;
            }

          int nDataBytesIndex = 4;
  
          int nNumDataBytes   = (int) ( sReadMessage.DataSize - nDataBytesIndex );

          if( ( sReadMessage.RxStatus == 0x09 ) && ( 0 == nNumDataBytes ) )
            {
              Console.WriteLine(  "Rx TS=[{0}] ** Tx Done Indication", sReadMessage.Timestamp.ToString("D10") ); 
              Console.WriteLine();
              continue;
            }

          if( ( sReadMessage.RxStatus & 0x02 ) == 0x02 )
            {
              Console.WriteLine(  "Rx TS=[{0}] ** Rx Start Indication", sReadMessage.Timestamp.ToString("D10") ); 
              Console.WriteLine();
              continue;
            }

          if( STATUS_NOERROR == ulRetVal )
            {
              ProcessRxISO15765Message( sReadMessage );
            }
          
        } while( ulRetVal != ERR_BUFFER_EMPTY );
      
      //
      // Free the memory.
      //
      Marshal.FreeHGlobal( pMsg );

      return true;

    }//ReadAndProcessISO15765Messages
    
    //------------------------------------------------------------------------------------------------------------------
    // ProcessRxISO15765Message - Process a received ISO15765 message.  Look for PID 0x41 which will arrive in 
    //                            response to our sending of PID 1 (Supported PIDS).
    //------------------------------------------------------------------------------------------------------------------
    public bool ProcessRxISO15765Message( PASSTHRU_MSG sReadMessage )
    {
      UInt32       nNumDataBytes          = 0;
      UInt32       iCANID                 = 0;
      int          i                      = 0;
      
      //
      // Print the raw message to the file pointers fp1, fp2.
      //
      PrintRxISO15765Message( sReadMessage );
      
      //
      // Unpack the CANID of the node.
      //
      iCANID    = UnPackFourByteIntegerMSB( sReadMessage.Data, 0 );
      
      //
      // The number of data bytes is the data size - 5 (4 bytes CANID + 1 byte for the PID ).
      //
      nNumDataBytes   = sReadMessage.DataSize - 5;
      
      switch( sReadMessage.Data[4] )
        {
          //
          // Supported PIDS Mode 1 Response
          //
        case 0x41:
          
          Console.Write("Received PID 0x41 - Response to PID=0x01, Mode Supported PIDs from CANID=[{0}].  DATA", iCANID.ToString("X8") );

          for( i = 0; i < (int) nNumDataBytes; i++ )
            {
              Console.Write( "[{0}]", sReadMessage.Data[i+5].ToString("X2") );
            }
          
          Console.WriteLine();
          Console.WriteLine();
          break;
          
        }//switch
      
      return true;
      
    }//ProcessRxISO15765Message
    
    //------------------------------------------------------------------------------------------------------------------
    // PrintRxISO15765Message - Print a received ISO15765 message.
    //------------------------------------------------------------------------------------------------------------------
    public bool PrintRxISO15765Message( PASSTHRU_MSG sReadMessage )
    {
      int           i                      = 0;
      int           j                      = 0;
      UInt32        nDataBytesIndex        = 0;
      UInt32        nNumDataBytes          = 0;
      UInt32        iCANID                 = 0;
      
      //
      // Unpack the CANID.  It is always 4 bytes even when using 11-bit.
      //
      iCANID          = UnPackFourByteIntegerMSB( sReadMessage.Data, 0 );
      
      //
      // Data bytes will start appearing at index 4.
      //
      nDataBytesIndex = 4;
      
      //
      // Calculate the number of data bytes in the message.
      //
      nNumDataBytes   = sReadMessage.DataSize - nDataBytesIndex;
      
      //
      // Print the string to the FILE pointers and to the variable szMsgString.
      //
      Console.WriteLine( "Rx TS=[{0}] ISO15765 CANID=[{1}] RxStatus=[{2}] DataLen=[{3}]", 
                         sReadMessage.Timestamp.ToString("D10"), iCANID.ToString("X8"), sReadMessage.RxStatus.ToString("X8"), nNumDataBytes.ToString("D4") );
      
      //
      // If data bytes exist (some messages are just indications), print the data bytes as well.
      //  
      if( nNumDataBytes > 0 )
        {
          Console.Write("    DATA");
          
          for( j = 0, i = (int) nDataBytesIndex; j < (int) nNumDataBytes; j++, i++ )
            {
              Console.Write( "[{0}]", sReadMessage.Data[i].ToString("X2"));
            }
        }
      
      Console.WriteLine();
      Console.WriteLine();
      
      return true;
      
    }//PrintRxISO15765Message
    
    //    
    //****************************************************************************************************
    //****************************************************************************************************
    // J2534 Section
    //****************************************************************************************************
    //****************************************************************************************************
    //
    
    //
    // Load an J2534 DLL and set up all of the function pointers.
    //
    public bool LoadDLLAndFunctions( string szDLLToLoad )
    {
      bool bError = false;
      
      pDLL = LoadLibrary( szDLLToLoad );
      
      if( pDLL == IntPtr.Zero )
        {
          return false;
        }
      else
        {
          fpPassThruOpen                  = IntPtr.Zero;
          fpPassThruClose                 = IntPtr.Zero;
          fpPassThruConnect               = IntPtr.Zero;
          fpPassThruDisconnect            = IntPtr.Zero;
          fpPassThruReadMsgs              = IntPtr.Zero;
          fpPassThruWriteMsgs             = IntPtr.Zero;
          fpPassThruStartPeriodicMsg      = IntPtr.Zero;
          fpPassThruStopPeriodicMsg       = IntPtr.Zero;
          fpPassThruStartMsgFilter        = IntPtr.Zero;
          fpPassThruStopMsgFilter         = IntPtr.Zero;
          fpPassThruSetProgrammingVoltage = IntPtr.Zero;
          fpPassThruReadVersion           = IntPtr.Zero;
          fpPassThruGetLastError          = IntPtr.Zero;
          fpPassThruIoctl                 = IntPtr.Zero;
          
          fpPassThruOpen                  = GetProcAddress(pDLL, "PassThruOpen"                  );
          fpPassThruClose                 = GetProcAddress(pDLL, "PassThruClose"                 );
          fpPassThruConnect               = GetProcAddress(pDLL, "PassThruConnect"               );
          fpPassThruDisconnect            = GetProcAddress(pDLL, "PassThruDisconnect"            );
          fpPassThruReadMsgs              = GetProcAddress(pDLL, "PassThruReadMsgs"              );
          fpPassThruWriteMsgs             = GetProcAddress(pDLL, "PassThruWriteMsgs"             );
          fpPassThruStartPeriodicMsg      = GetProcAddress(pDLL, "PassThruStartPeriodicMsg"      );
          fpPassThruStopPeriodicMsg       = GetProcAddress(pDLL, "PassThruStopPeriodicMsg"       );
          fpPassThruStartMsgFilter        = GetProcAddress(pDLL, "PassThruStartMsgFilter"        );
          fpPassThruStopMsgFilter         = GetProcAddress(pDLL, "PassThruStopMsgFilter"         );
          fpPassThruSetProgrammingVoltage = GetProcAddress(pDLL, "PassThruSetProgrammingVoltage" );
          fpPassThruReadVersion           = GetProcAddress(pDLL, "PassThruReadVersion"           );
          fpPassThruGetLastError          = GetProcAddress(pDLL, "PassThruGetLastError"          );
          fpPassThruIoctl                 = GetProcAddress(pDLL, "PassThruIoctl"                 );
          
          if (IntPtr.Zero ==  fpPassThruOpen                  )       bError = true;
          if (IntPtr.Zero ==  fpPassThruClose                 )       bError = true;
          if (IntPtr.Zero ==  fpPassThruConnect               )       bError = true;
          if (IntPtr.Zero ==  fpPassThruDisconnect            )       bError = true;
          if (IntPtr.Zero ==  fpPassThruReadMsgs              )       bError = true;
          if (IntPtr.Zero ==  fpPassThruWriteMsgs             )       bError = true;
          if (IntPtr.Zero ==  fpPassThruStartPeriodicMsg      )       bError = true;
          if (IntPtr.Zero ==  fpPassThruStopPeriodicMsg       )       bError = true;
          if (IntPtr.Zero ==  fpPassThruStartMsgFilter        )       bError = true;
          if (IntPtr.Zero ==  fpPassThruStopMsgFilter         )       bError = true;
          if (IntPtr.Zero ==  fpPassThruSetProgrammingVoltage )       bError = true;
          if (IntPtr.Zero ==  fpPassThruReadVersion           )       bError = true;
          if (IntPtr.Zero ==  fpPassThruGetLastError          )       bError = true;
          if (IntPtr.Zero ==  fpPassThruIoctl                 )       bError = true;
          
          if( true == bError )
            {
              return false;
            }
          
          pPassThruOpen                  = (PassThruOpen                 ) Marshal.GetDelegateForFunctionPointer( fpPassThruOpen                  , typeof( PassThruOpen                  ));
          pPassThruClose                 = (PassThruClose                ) Marshal.GetDelegateForFunctionPointer( fpPassThruClose                 , typeof( PassThruClose                 ));
          pPassThruConnect               = (PassThruConnect              ) Marshal.GetDelegateForFunctionPointer( fpPassThruConnect               , typeof( PassThruConnect               ));
          pPassThruDisconnect            = (PassThruDisconnect           ) Marshal.GetDelegateForFunctionPointer( fpPassThruDisconnect            , typeof( PassThruDisconnect            ));
          pPassThruReadMsgs              = (PassThruReadMsgs             ) Marshal.GetDelegateForFunctionPointer( fpPassThruReadMsgs              , typeof( PassThruReadMsgs              ));
          pPassThruWriteMsgs             = (PassThruWriteMsgs            ) Marshal.GetDelegateForFunctionPointer( fpPassThruWriteMsgs             , typeof( PassThruWriteMsgs             ));
          pPassThruStartPeriodicMsg      = (PassThruStartPeriodicMsg     ) Marshal.GetDelegateForFunctionPointer( fpPassThruStartPeriodicMsg      , typeof( PassThruStartPeriodicMsg      ));
          pPassThruStopPeriodicMsg       = (PassThruStopPeriodicMsg      ) Marshal.GetDelegateForFunctionPointer( fpPassThruStopPeriodicMsg       , typeof( PassThruStopPeriodicMsg       ));
          pPassThruStartMsgFilter        = (PassThruStartMsgFilter       ) Marshal.GetDelegateForFunctionPointer( fpPassThruStartMsgFilter        , typeof( PassThruStartMsgFilter        ));
          pPassThruStopMsgFilter         = (PassThruStopMsgFilter        ) Marshal.GetDelegateForFunctionPointer( fpPassThruStopMsgFilter         , typeof( PassThruStopMsgFilter         ));
          pPassThruSetProgrammingVoltage = (PassThruSetProgrammingVoltage) Marshal.GetDelegateForFunctionPointer( fpPassThruSetProgrammingVoltage , typeof( PassThruSetProgrammingVoltage ));
          pPassThruReadVersion           = (PassThruReadVersion          ) Marshal.GetDelegateForFunctionPointer( fpPassThruReadVersion           , typeof( PassThruReadVersion           ));
          pPassThruGetLastError          = (PassThruGetLastError         ) Marshal.GetDelegateForFunctionPointer( fpPassThruGetLastError          , typeof( PassThruGetLastError          ));
          pPassThruIoctl                 = (PassThruIoctl                ) Marshal.GetDelegateForFunctionPointer( fpPassThruIoctl                 , typeof( PassThruIoctl                 ));

          return true;
        }
      
    }//LoadDLLAndFunctions()
    
    //
    // Free an J2534 DLL.
    //
    public bool FreeLibraryAndFunctions()
    {
      FreeLibrary(pDLL);
      return true;

    }//FreeLibraryAndFunctions
    
  }//J2534_Class

  //
  //****************************************************************************************************
  //****************************************************************************************************
  // Program Class
  //****************************************************************************************************
  //****************************************************************************************************
  //

  class Program
  {
    //
    // Import the kbhit function from the C runtime library.
    //
    [DllImport("crtdll.dll")]   
    public static extern int _kbhit();

    //
    // Global Program class variables.
    //
    const String PROGRAM_ID = "DG Technologies - J2534 Example Souce Code C# - Version 1.00";

    //
    //****************************************************************************************************
    //****************************************************************************************************
    // main() - Program Entry Point
    //****************************************************************************************************
    //****************************************************************************************************
    static int Main(string[] args)
    {
      //
      // Declare the J2534_Class wrapper.
      //
      J2534_Class               J2534              = new J2534_Class();

      //================================================================================
      // Declare Global J2534 Variables That Are Used Throughout
      //================================================================================
      
      UInt32            ulProtocolID               = J2534.ISO15765;
      UInt32            ulProtocolBaud             = 500000;
      UInt32            ulProtocolFlagsISO15765    = 0;
      UInt32            ulTesterCANID              = 0x000007DF;
      UInt32            ulChannelID                = 0x00;
      UInt32            ulDeviceID                 = 0x00;
      
      J2534_Class.PASSTHRU_MSG sMaskMsg            = new J2534_Class.PASSTHRU_MSG{ Data = new byte[4128]};
      J2534_Class.PASSTHRU_MSG sPatternMsg         = new J2534_Class.PASSTHRU_MSG{ Data = new byte[4128]};
      J2534_Class.PASSTHRU_MSG sFlowControlMsg     = new J2534_Class.PASSTHRU_MSG{ Data = new byte[4128]};

      //
      // To pass the address of a structure in C# to a C++ DLL, this is required.
      //      
      int               iSizeOfPTM                 = 0; 
      IntPtr            pMsg                       = IntPtr.Zero;
      IntPtr            pMaskMsg                   = IntPtr.Zero;
      IntPtr            pPatternMsg                = IntPtr.Zero;
      IntPtr            pFlowControlMsg            = IntPtr.Zero;
      //
      //
      //
      UInt32                   ulFlowFilter        = 0;
      //
      // Device DLL name, DeviceID and nClientID variables.
      //
      StringBuilder              sbJ2534DeviceDLL  = new StringBuilder(100);
      //
      // Return value for J2534 functions, and declare a send/read message buffer.
      //
      UInt32                     ulRetVal          = 0;
      StringBuilder              szErrMsg          = new StringBuilder(256);
      //
      // Values for J2534_ReadDetailedVersion().
      //
      StringBuilder              szFirmwareVersion = new StringBuilder(100);
      StringBuilder              szDLLVersion      = new StringBuilder(100);
      StringBuilder              szAPIVersion      = new StringBuilder(100);
      //
      // Generic variables.
      //
      String                     sUserInput        = "";
      int                        iUserChosenAPI    = 0;
      //
      // Variables for sending request messages every 5 seconds.
      //
      DateTime                   dttLastTimeRequestsSent ;
      TimeSpan                   tsDiffInSeconds         ;
      bool                       bFirst                  = true;
      //
      // Write the program identification to the screen.
      //
      Console.WriteLine( PROGRAM_ID );
      
      //
      // Have the user select the adapter they want to use and set sbJ2534DeviceDLL.
      //
      do 
        {
          Console.WriteLine( "                                                                       " );
          Console.WriteLine( "---------------------------------------------------------------------- " );
          Console.WriteLine( " Select Adapter To Use                                                 " );
          Console.WriteLine( "---------------------------------------------------------------------- " );
          Console.WriteLine( "                                                                       " );
          Console.WriteLine( " 1 = DG DPA 5                ( DLL Name = DGDPA532.DLL   )             " );
          Console.WriteLine( " 2 = VSI-2534                ( DLL Name = DGVSI32.DLL    )             " );
          Console.WriteLine( " 3 = d-briDGe                ( DLL Name = DBRIDGE.DLL    )             " );
          Console.WriteLine( " 4 = Netbridge               ( DLL Name = NBRIDGE.DLL    )             " );
          Console.WriteLine( " 5 = Softbridge              ( DLL Name = SOFTBRIDGE.DLL )             " );
          Console.WriteLine( " 6 = Gryphon, G2, S3, S4     ( DLL Name = J2534G32.DLL   )             " );
          Console.WriteLine( "                                                                       " );
          Console.Write    ( "->  " );
          
          sUserInput = Console.ReadLine();
          
          if( sUserInput != null ) 
            {
              iUserChosenAPI = Convert.ToInt32( sUserInput );
              
              switch( iUserChosenAPI )
                {
                case 1: sbJ2534DeviceDLL.Append("dgDPA532.DLL"   ); break;
                case 2: sbJ2534DeviceDLL.Append("DGVSI32.DLL"    ); break;
                case 3: sbJ2534DeviceDLL.Append("DBRIDGE.DLL"    ); break;
                case 4: sbJ2534DeviceDLL.Append("NBRIDGE.DLL"    ); break;
                case 5: sbJ2534DeviceDLL.Append("SOFTBRIDGE.DLL" ); break;
                case 6: sbJ2534DeviceDLL.Append("J2534G32.DLL"   ); break;
                }
            }
          
        } while( iUserChosenAPI < 1 || iUserChosenAPI > 6 );
      
      //
      // Attempt loading the DLL and setting all of the function pointers.
      //
      if( false == J2534.LoadDLLAndFunctions( sbJ2534DeviceDLL.ToString() ) )
        {
          Console.WriteLine( "FAILURE loading DLL {0}.", sbJ2534DeviceDLL );
          Console.WriteLine( " -> Try setting the project EXE type to x86.");
          return 1;
        }
      
      //
      // PassThruOpen() - Open a connection to the device.  Get the DeviceID back.
      //
      ulRetVal = J2534.pPassThruOpen( IntPtr.Zero, ref ulDeviceID );
      
      if( J2534.STATUS_NOERROR != ulRetVal )
        {
          Console.WriteLine( "FAILURE calling PassThruOpen on DLL {0}.", sbJ2534DeviceDLL );
          J2534.FreeLibraryAndFunctions();
          return 1;
        }
      
      //
      // PassThruReadVersion() - Get the API, DLL, and FW version information.
      //
      ulRetVal = J2534.pPassThruReadVersion(ulDeviceID, szFirmwareVersion, szDLLVersion, szAPIVersion);

      if( J2534.STATUS_NOERROR != ulRetVal)
        {
          Console.WriteLine("FAILURE calling PassThruReadVersion on DLL {0}.", sbJ2534DeviceDLL);
          J2534.FreeLibraryAndFunctions();
          return 1;
        }
      else
        {
          Console.WriteLine("Device Firmware Version = {0}, DLL Version = {1}, API Version = {2}", szFirmwareVersion, szDLLVersion, szAPIVersion );
        }
      
      //
      // PassThruconnect() - Connect to the ISO15765 data bus.
      //
      ulRetVal = J2534.pPassThruConnect(ulDeviceID, ulProtocolID, ulProtocolFlagsISO15765, ulProtocolBaud, ref ulChannelID);

      if( J2534.STATUS_NOERROR != ulRetVal)
        {
          J2534.pPassThruClose(ulDeviceID);
          J2534.FreeLibraryAndFunctions();
          return 1;
        }
      
      //
      // Setup ISO15765 flow control filters for all allowable 11-bit ISO15765-4 
      // external test equipment/ECM address combinations.
      //
      //     External Test Equipment      Physical Response CANID
      //     -----------------------      -----------------------
      //            0x7E0                         0x7E8
      //            0x7E1                         0x7E9
      //            0x7E2                         0x7EA
      //            0x7E3                         0x7EB
      //            0x7E4                         0x7EC
      //            0x7E5                         0x7ED
      //            0x7E6                         0x7EE
      //            0x7E7                         0x7EF
      
      sMaskMsg.ProtocolID            = ulProtocolID;
      sMaskMsg.RxStatus              = 0;
      sMaskMsg.TxFlags               = J2534.ISO15765_FRAME_PAD;
      sMaskMsg.Timestamp             = 0;
      sMaskMsg.DataSize              = 4;
      sMaskMsg.ExtraDataIndex        = 0;
      sMaskMsg.Data[0]               = 0xFF;
      sMaskMsg.Data[1]               = 0xFF;
      sMaskMsg.Data[2]               = 0xFF;
      sMaskMsg.Data[3]               = 0xFF;
      
      sPatternMsg.ProtocolID         = ulProtocolID;
      sPatternMsg.RxStatus           = 0;
      sPatternMsg.TxFlags            = J2534.ISO15765_FRAME_PAD;
      sPatternMsg.Timestamp          = 0;
      sPatternMsg.DataSize           = 4;
      sPatternMsg.ExtraDataIndex     = 0;
      sPatternMsg.Data[0]            = 0x00;
      sPatternMsg.Data[1]            = 0x00;
      sPatternMsg.Data[2]            = 0x07;
      sPatternMsg.Data[3]            = 0xE8;
      
      sFlowControlMsg.ProtocolID     = ulProtocolID;
      sFlowControlMsg.RxStatus       = 0;
      sFlowControlMsg.TxFlags        = J2534.ISO15765_FRAME_PAD;
      sFlowControlMsg.Timestamp      = 0;
      sFlowControlMsg.DataSize       = 4;
      sFlowControlMsg.ExtraDataIndex = 4;
      sFlowControlMsg.Data[0]        = 0x00;
      sFlowControlMsg.Data[1]        = 0x00;
      sFlowControlMsg.Data[2]        = 0x07;
      sFlowControlMsg.Data[3]        = 0xE0;
      
      //
      // Setup flow control filters for all pairs.
      //
      for( sFlowControlMsg.Data[3] = 0xE0; sFlowControlMsg.Data[3] < 0xE8; sFlowControlMsg.Data[3]++,  sPatternMsg.Data[3]++ )
        {
          //
          // This may be redundant, but I wanted to make sure that if the PassThruStartMsgFilter
          //   code modifies the structure in any way, I set it back to the correct state.
          //
          sMaskMsg.ProtocolID            = ulProtocolID;
          sMaskMsg.RxStatus              = 0;
          sMaskMsg.TxFlags               = J2534.ISO15765_FRAME_PAD;
          sMaskMsg.Timestamp             = 0;
          sMaskMsg.DataSize              = 4;
          sMaskMsg.ExtraDataIndex        = 0;
          sMaskMsg.Data[0]               = 0xFF;
          sMaskMsg.Data[1]               = 0xFF;
          sMaskMsg.Data[2]               = 0xFF;
          sMaskMsg.Data[3]               = 0xFF;
          
          sPatternMsg.ProtocolID         = ulProtocolID;
          sPatternMsg.RxStatus           = 0;
          sPatternMsg.TxFlags            = J2534.ISO15765_FRAME_PAD;
          sPatternMsg.Timestamp          = 0;
          sPatternMsg.DataSize           = 4;
          sPatternMsg.ExtraDataIndex     = 0;
          sPatternMsg.Data[0]            = 0x00;
          sPatternMsg.Data[1]            = 0x00;
          sPatternMsg.Data[2]            = 0x07;
          
          sFlowControlMsg.ProtocolID     = ulProtocolID;
          sFlowControlMsg.RxStatus       = 0;
          sFlowControlMsg.TxFlags        = J2534.ISO15765_FRAME_PAD;
          sFlowControlMsg.Timestamp      = 0;
          sFlowControlMsg.DataSize       = 4;
          sFlowControlMsg.ExtraDataIndex = 4;
          sFlowControlMsg.Data[0]        = 0x00;
          sFlowControlMsg.Data[1]        = 0x00;
          sFlowControlMsg.Data[2]        = 0x07;

          //
          // This code is required to Marshal managed structure (C#) into a 
          //   C++ DLL unmanaged structur pointer (PASSTHRU_MSG *pMsg).
          //
          iSizeOfPTM              = Marshal.SizeOf( typeof(J2534_Class.PASSTHRU_MSG) );

          pMaskMsg                = Marshal.AllocHGlobal( iSizeOfPTM     );
          pPatternMsg             = Marshal.AllocHGlobal( iSizeOfPTM     );
          pFlowControlMsg         = Marshal.AllocHGlobal( iSizeOfPTM     );

          Marshal.StructureToPtr( sMaskMsg, pMaskMsg, false);
          Marshal.StructureToPtr( sPatternMsg, pPatternMsg, false);
          Marshal.StructureToPtr( sFlowControlMsg, pFlowControlMsg, false);

          ulRetVal = J2534.pPassThruStartMsgFilter( ulChannelID, J2534.FLOW_CONTROL_FILTER, pMaskMsg, pPatternMsg, pFlowControlMsg, ref ulFlowFilter);
          
          if( J2534.STATUS_NOERROR != ulRetVal )
            {
              J2534.pPassThruGetLastError(szErrMsg);
              J2534.pPassThruDisconnect(ulChannelID);
              J2534.pPassThruClose(ulDeviceID);
              J2534.FreeLibraryAndFunctions();

              //
              // Free all the memory
              //
              Marshal.FreeHGlobal( pMaskMsg        );
              Marshal.FreeHGlobal( pPatternMsg     );
              Marshal.FreeHGlobal( pFlowControlMsg );


              return 1;
            }
          else
            {
              Console.WriteLine( "Setting flow/pattern filter Tester(0x{0}{1}{2}{3}) / ECM (0x{4}{5}{6}{7}) successful.",
                      sPatternMsg.Data[0].ToString("X2")        ,
                      sPatternMsg.Data[1].ToString("X2")        ,
                      sPatternMsg.Data[2].ToString("X2")        ,
                      sPatternMsg.Data[3].ToString("X2")        ,
                      sFlowControlMsg.Data[0].ToString("X2")    ,
                      sFlowControlMsg.Data[1].ToString("X2")    ,
                      sFlowControlMsg.Data[2].ToString("X2")    ,
                      sFlowControlMsg.Data[3].ToString("X2")    
                      );
            }
        }
      
      //
      // Free memory allocated with setting flow control filters.
      //
      Marshal.FreeHGlobal( pMaskMsg        );
      Marshal.FreeHGlobal( pPatternMsg     );
      Marshal.FreeHGlobal( pFlowControlMsg );

      //
      // Let the user know how to exit the program.
      //
      Console.WriteLine( "---------------------------------------------------------------------" );
      Console.WriteLine( " Ready to begin.  Press \"Enter\" to start, any key exits program.   " );
      Console.WriteLine( "            Press \"Ctrl-S\" to freeze the screen.                   " );
      Console.WriteLine( "---------------------------------------------------------------------" );
      Console.Write    ( ">" );
      
      sUserInput = Console.ReadLine();
      
      //
      // Get the time now.
      //
      dttLastTimeRequestsSent = DateTime.Now;
      
      //
      // Forever.  Read/process messages until a ERR_HARDWARE_NOT_RESPONDING or a keystroke.
      //
      do
        {
          
          //
          // Get the time now and see if it has been over 2 seconds.
          //
          tsDiffInSeconds = DateTime.Now - dttLastTimeRequestsSent;
          
          if( ( tsDiffInSeconds.Seconds > 2 ) || ( bFirst == true ) )
            {
              J2534.RequestModeSupportedPIDS( ulProtocolID, ulChannelID, ulTesterCANID, 1 );
              
              dttLastTimeRequestsSent = DateTime.Now;

              bFirst = false;
            }
          
          //
          // If a key is pressed, exit cleanly.
          //
          if( _kbhit() != 0 )
            break;
          
        } while ( true );
      
      //
      // PassThruDisconnect() - Disconnect from the protocol data bus.
      //
      J2534.pPassThruDisconnect( ulChannelID );
      J2534.pPassThruClose( ulDeviceID );
      J2534.FreeLibraryAndFunctions();
      
      //
      // Return success to the operating system.
      //
      return 0;
    }
  }
}
