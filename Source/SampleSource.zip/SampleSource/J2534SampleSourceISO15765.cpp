// ----------------------------------------------------------------------------------------------------
//  DG Technologies - SAE J2534 Example Source Code for ISO15765 (11-bit CANIDs)
//  Copyright (c) 2012-2014 - Dearborn Group, Inc.
// ----------------------------------------------------------------------------------------------------
// 
//  Name:           J2534SampleSourceISO15765.cpp 
//
//  Version:        1.25
// 
//  Date:           09-26-14
// 
//  Written By:     Kenneth L. DeGrant II
//                  Field Applications Engineering Manager
//                  DPA Product Manager
//                  Dearborn Group, Inc.
//                  kdegrant@dgtech.com
//                  859-624-8488 (office)
//                  859-358-1485 (cell)
// 
//  Description:    This code is provided by Dearborn Group, Inc. to assist application developers in 
//                  developing J2534 applications for the Dearborn Group J2534 devices.  It allows 
//                  connecting to the ISO15765 protocol at 500k with Standard CAN (11-bit) CAN 
//                  identifiers.  It shows how to set flow control filters for all ISO15765-4
//                  test equipment addresses to the address from the physical ECUs.
//
//                        External Test Equipment      Physical Response CANID
//                        -----------------------      -----------------------
//                               0x7E0                         0x7E8
//                               0x7E1                         0x7E9
//                               0x7E2                         0x7EA
//                               0x7E3                         0x7EB
//                               0x7E4                         0x7EC
//                               0x7E5                         0x7ED
//                               0x7E6                         0x7EE
//                               0x7E7                         0x7EF
//
//                  After the flow control filters are set up, the program can either:
//
//                  1.  Send out the J1979 request for supported PID values in Mode 1.
//
//                  2.  Send request for Engine RPM (Mode 1, PID 0x0C) and decode the value.
//
//                  During this process, the program will read and process the response
//                  messages back from each controller (CANID).
//
//  Requirements:   This program requires that you have downloaded and installed the latest J2534 
//                  drivers for your DG product.  They can be found here:
//
//                               http://www.dgtech.com/download.php
//
//  No Liability:   This code is example code and is NOT warranted to be fit for any particular use 
//                  or purpose.  Dearborn Group, Inc. will not be held liable for any use or 
//                  misuse of this code "under any circumstances whatsoever".  
// 
//  Notes:          It is possible to develop a completely J2534 application that will not connect, 
//                  send or read messages to or from a particular databus.  To ensure success, 
//                  please read the documentation for the protocol you want to use thoroughly along 
//                  with reading the "complete" J2534 document before trying to adapt this code to 
//                  a particular purpose.  Other pertinent documents are J1979 and ISO15765-4.
//
//  Copyright:      This code is copyrighted by Dearborn Group, Inc., and is intended
//                  solely for the use of our customers or potential customers.  No portion,
//                  including "snippets" of this code are to be used, investigated, or copied in any 
//                  shape, form, or fashion, by anyone who is, or may in the future be, in competition 
//                  with Dearborn Group, Inc. in any way.  
//
//  Developer
//  Notes:          The application was originally written using Microsoft Visual Studio 2008.
//                  This code was not written for UNICODE or Multi-Byte strings so options have to be
//                  set in the Project Properties.  The following are the settings that were changed
//                  from default values:
//                  
//                  [Configuration Properties][General]
//                    Use Of MFC               "Use MFC in a Static Library"
//                    Use of ATL               "Not Set"
//                    Character Set            "Not Set"
//                  
//                  [Configuration Properties][C/C++][Preprocessor]
//                    Preprocessor Definitions "WIN32;_DEBUG;_CONSOLE;_CRT_SECURE_NO_WARNINGS"
//                      NOTE:  _CRT_SECURE_NO_WARNINGS removes the warnings about not using
//                             the newer "safe" string functions like sprintf_s.
//
//                  The project was compiled with Warning Level set to 4 (all warnings).
//
// ----------------------------------------------------------------------------------------------------
//  Revision  Date       Notes
//     1.0    02-07-12   Original Version for DPA 5.
//     1.1    04-25-12   Added support for VSI-2534 and documented code and compiler options that
//                       are necessary for compiling under Microsoft Visual Studio.
//     1.2    05-10-12   Added read until buffer empty after each send of a message.
//     1.21   12-04-12   Changed copyright date.
//     1.22   04-05-13   Added d-briDGe and Netbridge
//     1.23   06-25-13   Changed formal name of Netbridge product.
//     1.24   02-05-14   Added Softbridge, Gryphon products and changed copyright date.
//     1.25   09-26-14   Added ability to decode J1979 parameter 0x0C (Engine RPM).
// ----------------------------------------------------------------------------------------------------

const char *PROGRAMID = "DG Technologies - J2534 Example Souce Code for 11-bit ISO15765 - Version 1.25";

//======================================================================
// Necessary include files.
//======================================================================

#include<stdio.h>
#include<windows.h>
#include<conio.h>
#include<time.h>

#ifndef TRUE
#define TRUE  1
#define FALSE 0
#endif

//======================================================================
// J2534 Definitions
//======================================================================

typedef unsigned long UL;
typedef unsigned char U8;

//
// Protocol definitions 
//
#define J1850VPW                                                         1
#define J1850PWM                                                         2  
#define ISO9141                                                          3
#define ISO14230                                                         4
#define CAN                                                              5
#define ISO15765                                                         6
#define SCI_A_ENGINE                                                     7
#define SCI_A_TRANS                                                      8
#define SCI_B_ENGINE                                                     9
#define SCI_B_TRANS                                                     10

//
// IOCTL IDs
//
#define GET_CONFIG                                                       1
#define SET_CONFIG                                                       2
#define READ_VBATT                                                       3
#define FIVE_BAUD_INIT                                                   4
#define FAST_INIT                                                        5
#define SET_PIN_USE                                                      6
#define CLEAR_TX_BUFFER                                                  7
#define CLEAR_RX_BUFFER                                                  8
#define CLEAR_PERIODIC_MSGS                                              9
#define CLEAR_MSG_FILTERS                                               10
#define CLEAR_FUNCT_MSG_LOOKUP_TABLE                                    11
#define ADD_TO_FUNCT_MSG_LOOKUP_TABLE                                   12
#define DELETE_FROM_FUNCT_MSG_LOOKUP_TABLE                              13
#define READ_PROG_VOLTAGE                                               14

//
// Configuration Parameter IDs
//

#define CAN_ID_BOTH                                                 0x0400

#define DATA_RATE                                                        1
#define LOOPBACK                                                         3
#define NODE_ADDRESS                                                     4
#define NETWORK_LINE                                                     5
#define P1_MIN                                                           6
#define P1_MAX                                                           7
#define P2_MIN                                                           8
#define P2_MAX                                                           9
#define P3_MIN                                                          10
#define P3_MAX                                                          11
#define P4_MIN                                                          12
#define P4_MAX                                                          13
#define W1                                                              14
#define W2                                                              15
#define W3                                                              16
#define W4                                                              17
#define W5                                                              18
#define TIDLE                                                           19
#define TINIL                                                           20
#define TWUP                                                            21
#define PARITY                                                          22
#define BIT_SAMPLE_POINT                                                23
#define SYNC_JUMP_WIDTH                                                 24
#define T1_MAX                                                          26
#define T2_MAX                                                          27
#define T4_MAX                                                          28
#define T5_MAX                                                          29
#define ISO15765_BS                                                     30
#define ISO15765_STMIN                                                  31
#define DATA_BITS                                                       32
#define FIVE_BAUD_MOD                                                   33
#define BS_TX                                                           34
#define STMIN_TX                                                        35
#define T3_MAX                                                          36
#define ISO15765_WFT_MAX                                                37

//
// Error IDs
//
#define STATUS_NOERROR                                                   0
#define ERR_NOT_SUPPORTED                                                1
#define ERR_INVALID_CHANNEL_ID                                           2
#define ERR_INVALID_PROTOCOL_ID                                          3 
#define ERR_NULL_PARAMETER                                               4
#define ERR_INVALID_IOCTL                                                5
#define ERR_INVALID_FLAGS                                                6
#define ERR_FAILED                                                       7
#define ERR_DEVICE_NOT_CONNECTED                                         8
#define ERR_TIMEOUT                                                      9
#define ERR_INVALID_MSG                                                 10
#define ERR_INVALID_TIME_INTERVAL                                       11
#define ERR_EXCEEDED_LIMIT                                              12
#define ERR_INVALID_MSG_ID                                              13
#define ERR_INVALID_ERROR_ID                                            14
#define ERR_INVALID_IOCTL_ID                                            15
#define ERR_BUFFER_EMPTY                                                16
#define ERR_BUFFER_FULL                                                 17
#define ERR_BUFFER_OVERFLOW                                             18
#define ERR_PIN_INVALID                                                 19
#define ERR_CHANNEL_IN_USE                                              20
#define ERR_MSG_PROTOCOL_ID                                             21

//
//  Miscellaneous definitions 
//
#define SHORT_TO_GROUND                                         0xFFFFFFFE
#define VOLTAGE_OFF                                             0xFFFFFFFF

//
// RxStatus definitions 
//
#define TX_MSG_TYPE                                             0x00000001
#define ISO15765_FIRST_FRAME                                    0x00000002
#ifndef RX_BREAK
#define RX_BREAK                                                0x00000004
#endif
#define ISO15765_TX_DONE                                        0x00000008

//
// TxFlags definitions
//
#define TX_NORMAL_TRANSMIT                                      0x00000000
#define ISO15765_FRAME_PAD                                      0x00000040
#define ISO15765_EXT_ADDR                                       0x00000080

#define TX_STANDARD_CAN                                               0x00
#define TX_EXTENDED_CAN                                               0x80

#define CAN_29BIT_ID                                                  0x80
#define CAN_11BIT_ID                                                  0x00

#define TX_BLOCKING                                             0x00010000
#define SCI_TX_VOLTAGE                                          0x00800000

//
// Filter definitions 
//
#define PASS_FILTER                                             0x00000001
#define BLOCK_FILTER                                            0x00000002
#define FLOW_CONTROL_FILTER                                     0x00000003

//
// PASSTHRU_MSG Structure
//
typedef struct
{
  UL ProtocolID       ;
  UL RxStatus         ;
  UL TxFlags          ;
  UL Timestamp        ;
  UL DataSize         ;
  UL ExtraDataIndex   ;
  U8 Data[4128]       ;
  
} PASSTHRU_MSG;

//
// SCONFIG IOCTL Structures
//
typedef struct
{
  UL Parameter        ;
  UL Value            ;
  
} SCONFIG;

typedef struct
{
  UL       NumOfParams;
  SCONFIG *ConfigPtr  ;
  
} SCONFIG_LIST;

typedef struct
{
  UL  NumOfBytes      ;
  U8 *BytePtr         ;
  
} SBYTE_ARRAY;

typedef struct
{
  UL  NumOfPins       ;
  U8 *PinUsePtr       ;
} SPIN_CONTROL;

typedef struct
{
  UL PinNumber        ;
  UL PinUse           ;
  UL Parameter        ;
  
} SPIN_USE;

//======================================================================
// Definitions for unpacking bytes from integer data types.
//======================================================================

#define HIWORD_OF_INT4( x )   ( ( x >> 16 ) & 0xFFFF )
#define LOWORD_OF_INT4( x )   ( x & 0x0000FFFF )
#define HIBYTE_OF_WORD( x )   ( ( x >> 8 ) & 0xFF ) 
#define LOBYTE_OF_WORD( x )   ( x & 0x00FF ) 
#define HINIBBLE_OF_CHAR( x ) ( ( x & 0xF0 ) >> 4 )
#define LONIBBLE_OF_CHAR( x ) (   x & 0x0F ) 
#define BYTE0_OF_INT4( x )    (U8) (LOBYTE_OF_WORD( LOWORD_OF_INT4( x ) ))
#define BYTE1_OF_INT4( x )    (U8) (HIBYTE_OF_WORD( LOWORD_OF_INT4( x ) ))
#define BYTE2_OF_INT4( x )    (U8) (LOBYTE_OF_WORD( HIWORD_OF_INT4( x ) ))
#define BYTE3_OF_INT4( x )    (U8) (HIBYTE_OF_WORD( HIWORD_OF_INT4( x ) ))

//======================================================================
// Definitions for masking bits from integers.
//======================================================================

#define BIT0                 0x01  
#define BIT1                 0x02  
#define BIT2                 0x04  
#define BIT3                 0x08  
#define BIT4                 0x10  
#define BIT5                 0x20  
#define BIT6                 0x40  
#define BIT7                 0x80  
#define BIT8                0x100  
#define BIT9                0x200  
#define BIT10               0x400  
#define BIT11               0x800  
#define BIT12              0x1000  
#define BIT13              0x2000
#define BIT14              0x4000
#define BIT15              0x8000
#define BIT16             0x10000
#define BIT17             0x20000
#define BIT18             0x40000
#define BIT19             0x80000
#define BIT20            0x100000
#define BIT21            0x200000
#define BIT22            0x400000
#define BIT23            0x800000
#define BIT24           0x1000000
#define BIT25           0x2000000
#define BIT26           0x4000000
#define BIT27           0x8000000
#define BIT28          0x10000000
#define BIT29          0x20000000
#define BIT30          0x40000000
#define BIT31          0x80000000

//================================================================================
// Defined J2534 Function Types
//================================================================================

typedef long (CALLBACK* fxPassThruOpen                  )( void *pName, UL *pDeviceID );
typedef long (CALLBACK* fxPassThruClose                 )( UL DeviceID );
typedef long (CALLBACK* fxPassThruConnect               )( UL DeviceID, UL ProtocolID, UL Flags, UL BaudRate, UL *pChannelID );
typedef long (CALLBACK* fxPassThruDisconnect            )( UL ChannelID );
typedef long (CALLBACK* fxPassThruReadMsgs              )( UL ChannelID, PASSTHRU_MSG *pMsg, UL *pNumMsgs, UL Timeout );
typedef long (CALLBACK* fxPassThruWriteMsgs             )( UL ChannelID, PASSTHRU_MSG *pMsg, UL *pNumMsgs, UL Timeout );
typedef long (CALLBACK* fxPassThruStartPeriodicMsg      )( UL ChannelID, PASSTHRU_MSG *pMsg, UL *pMsgID,   UL TimeInterval );
typedef long (CALLBACK* fxPassThruStopPeriodicMsg       )( UL ChannelID, UL MsgID );
typedef long (CALLBACK* fxPassThruStartMsgFilter        )( UL ChannelID, UL FilterType, PASSTHRU_MSG *pMaskMsg, PASSTHRU_MSG *pPatternMsg, PASSTHRU_MSG *pFlowControlMsg,UL *pFilterID );
typedef long (CALLBACK* fxPassThruStopMsgFilter         )( UL ChannelID, UL FilterID );
typedef long (CALLBACK* fxPassThruSetProgrammingVoltage )( UL DeviceID, UL PinNumber, UL Voltage );
typedef long (CALLBACK* fxPassThruReadVersion           )( UL DeviceID, char *pFirmwareVersion, char *pDLLVersion, char *pAPIVersion );
typedef long (CALLBACK* fxPassThruGetLastError          )( char *pErrorDescription );
typedef long (CALLBACK* fxPassThruIoctl                 )( UL ChannelID, UL IOCTLID, void *pInput, void *pOutput );

//================================================================================
// Declare J2534 Function Global Variables And Set To NULL
//================================================================================

fxPassThruOpen                       PassThruOpen                             = NULL;
fxPassThruClose                      PassThruClose                            = NULL;
fxPassThruConnect                    PassThruConnect                          = NULL;
fxPassThruDisconnect                 PassThruDisconnect                       = NULL;
fxPassThruReadMsgs                   PassThruReadMsgs                         = NULL;
fxPassThruWriteMsgs                  PassThruWriteMsgs                        = NULL;
fxPassThruStartPeriodicMsg           PassThruStartPeriodicMsg                 = NULL;
fxPassThruStopPeriodicMsg            PassThruStopPeriodicMsg                  = NULL;
fxPassThruStartMsgFilter             PassThruStartMsgFilter                   = NULL;
fxPassThruStopMsgFilter              PassThruStopMsgFilter                    = NULL;
fxPassThruSetProgrammingVoltage      PassThruSetProgrammingVoltage            = NULL;
fxPassThruReadVersion                PassThruReadVersion                      = NULL;
fxPassThruGetLastError               PassThruGetLastError                     = NULL;
fxPassThruIoctl                      PassThruIoctl                            = NULL;

//================================================================================
// Declare Global J2534 Variables That Are Used Throughout
//================================================================================

UL            ulProtocolID              = ISO15765;
UL            ulProtocolBaud            = 500000;
UL            ulProtocolFlagsISO15765   = 0;
UL            ulTesterCANID             = 0x000007DF;
UL            ulChannelID               = 0x00;
UL            ulDeviceID                = 0x00;

//================================================================================
// Program Function Prototypes
//================================================================================

UL        LoadDLLAndFunctions           ( char *szDLLName, HMODULE *hDLL );
UL        ReadAndProcessISO15765Messages( FILE *fp1, FILE *fp2                                                                   );
UL        ProcessRxISO15765Message      ( FILE *fp1, FILE *fp2, PASSTHRU_MSG sReadMessage, char *szMsgString, int iMsgStringSize );
UL        PrintRxISO15765Message        ( FILE *fp1, FILE *fp2, PASSTHRU_MSG sReadMessage, char *szMsgString, int iMsgStringSize );
UL        PrintTxISO15765Message        ( FILE *fp1, FILE *fp2, PASSTHRU_MSG sSentMessage, char *szMsgString, int iMsgStringSize );
int       RequestMode1SupportedPIDS     ( UL ulChannelID, UL ulTesterCANID, U8 ucMode, FILE *fp1, FILE *fp2 );
int       RequestEngineRPM              ( UL ulChannelID, UL ulTesterCANID, U8 ucMode, FILE *fp1, FILE *fp2 );

//-----------------------------------------------------------------------------------------------------
// Function Prototypes for Unpacking of U8 character strings representing numbers, and 
// also converting numbers into U8 character strings.
//-----------------------------------------------------------------------------------------------------

short     UnPackTwoByteIntegerLSB       ( U8 *ucIntString, int *iFFFlag );
int       UnPackThreeByteIntegerLSB     ( U8 *ucIntString, int *iFFFlag );
int       UnPackFourByteIntegerLSB      ( U8 *ucIntString, int *iFFFlag );

short     UnPackTwoByteIntegerMSB       ( U8 *ucIntString, int *iFFFlag );
int       UnPackThreeByteIntegerMSB     ( U8 *ucIntString, int *iFFFlag );
int       UnPackFourByteIntegerMSB      ( U8 *ucIntString, int *iFFFlag );

U8       *CreateTwoByteIntegerLSB       ( int   iVal, U8 *ucIntString );
U8       *CreateThreeByteIntegerLSB     ( int   iVal, U8 *ucIntString );
U8       *CreateFourByteIntegerLSB      ( int   iVal, U8 *ucIntString );

U8       *CreateTwoByteIntegerMSB       ( int   iVal, U8 *ucIntString );
U8       *CreateThreeByteIntegerMSB     ( int   iVal, U8 *ucIntString );
U8       *CreateFourByteIntegerMSB      ( int   iVal, U8 *ucIntString );

//================================================================================
// Begin main program
//================================================================================

int main( void )
{
  //
  // This is the handle to the DLL from LoadLibrary().
  //
  HMODULE       hDLL                      = NULL;
  
  //
  // This variable used to allow the user to select 
  // betwen the DPA 5 and the VSI-2534
  //
  int           iAPI                      = 0;

  //
  // What the user wants to do.  Menu selection variable.
  //
  int           iSelection                = 0;
  
  //
  // This variable is used only to remove the compiler warning
  // on the main program loop which used to be "while( TRUE )"
  //
  int           iAlwaysTRUE               = TRUE;
  
  //
  // Local variables needed for J2534 flow control setup.
  //
  UL            ulRetVal                  = 0x00;
  UL            ulFlowFilter              = 0;
  PASSTHRU_MSG  sMaskMsg                  = {0};
  PASSTHRU_MSG  sPatternMsg               = {0};
  PASSTHRU_MSG  sFlowControlMsg           = {0};
  
  //
  // Variables to show what FW, DLL, and API the device supports.
  //
  char          szFirmwareVersion   [100] = {0};
  char          szDLLVersion        [100] = {0};
  char          szAPIVersion        [100] = {0};
  
  //
  // Generic variables used for user input/output.
  //
  char          szUserBuffer        [100] = {0};
  char          szErrMsg           [1000] = {0};
  char          szMessage          [1000] = {0};
  
  //====================================================================================================
  // Main Program.
  //====================================================================================================
  
  //
  // Initialize complex variables (strings, structures, etc.)
  //
  memset( &sMaskMsg,            0x00, sizeof( sMaskMsg          ) );
  memset( &sPatternMsg,         0x00, sizeof( sPatternMsg       ) );
  memset( &sFlowControlMsg,     0x00, sizeof( sFlowControlMsg   ) );
  memset( szFirmwareVersion,    0x00, sizeof( szFirmwareVersion ) );
  memset( szDLLVersion,         0x00, sizeof( szDLLVersion      ) );
  memset( szAPIVersion,         0x00, sizeof( szAPIVersion      ) );
  memset( szUserBuffer,         0x00, sizeof( szUserBuffer      ) );
  memset( szErrMsg,             0x00, sizeof( szErrMsg          ) );
  memset( szMessage,            0x00, sizeof( szMessage         ) );
  
  //
  // Ask the user which device to use, the DPA 5 or the VSI-2534.
  //
  do
    {
      printf("-------------------------------------------------------------------------------------\n");
      printf("%s\n", PROGRAMID                                                                        );
      printf("-------------------------------------------------------------------------------------\n");
      printf("                                                                                     \n");
      printf("Please select the Dearborn Group product you are using:                              \n");
      printf("                                                                                     \n");
      printf("  1 = DG DPA 5                                                                       \n");
      printf("  2 = VSI-2534                                                                       \n");
      printf("  3 = d-briDGe                                                                       \n");
      printf("  4 = Netbridge                                                                      \n");
      printf("  5 = Softbridge                                                                     \n");
      printf("  6 = Gryphon, G2, S3, S4                                                            \n");
      printf("                                                                                     \n");
      printf("-------------------------------------------------------------------------------------\n");
      printf("> ");
      
      iAPI = atoi( gets( szUserBuffer ) );
      
    } while( ( iAPI > 6 ) || ( iAPI < 1 ) );
  
  if( iAPI == 1 )
    {
      //
      // Load DLL and set up function pointers for the DPA 5 J2534 DLL.
      //
      ulRetVal = LoadDLLAndFunctions( "DGDPA532.DLL", &hDLL );
      
      if( FALSE == ulRetVal )
        {
          fprintf(stderr,"LoadDLLAndFunctions(DPA 5) failed.  Exiting(...)\n");
          exit( ulRetVal );
        }
    }
  else if( iAPI == 2 )
    {
      //
      // Load DLL and set up function pointers for the VSI-2534 J2534 DLL.
      //
      ulRetVal = LoadDLLAndFunctions( "DGVSI32.DLL", &hDLL );
      
      if( FALSE == ulRetVal )
        {
          fprintf(stderr,"LoadDLLAndFunctions(VSI-2534) failed.  Exiting(...)\n");
          exit( ulRetVal );
        }
    }
  else if( iAPI == 3 )
    {
      //
      // Load DLL and set up function pointers for the d-briDGe.
      //
      ulRetVal = LoadDLLAndFunctions( "DBRIDGE.DLL", &hDLL );
      
      if( FALSE == ulRetVal )
        {
          fprintf(stderr,"LoadDLLAndFunctions(d-briDGe) failed.  Exiting(...)\n");
          exit( ulRetVal );
        }
    }
  else if( iAPI == 4 )
    {
      //
      // Load DLL and set up function pointers for the Netbridge.
      //
      ulRetVal = LoadDLLAndFunctions( "NBRIDGE.DLL", &hDLL );
      
      if( FALSE == ulRetVal )
        {
          fprintf(stderr,"LoadDLLAndFunctions(Netbridge) failed.  Exiting(...)\n");
          exit( ulRetVal );
        }
    }

  else if( iAPI == 5 )
    {
      //
      // Load DLL and set up function pointers for the Softbridge.
      //
      ulRetVal = LoadDLLAndFunctions( "SOFTBRIDGE.DLL", &hDLL );
      
      if( FALSE == ulRetVal )
        {
          fprintf(stderr,"LoadDLLAndFunctions(Softbridge) failed.  Exiting(...)\n");
          exit( ulRetVal );
        }
    }
  else if( iAPI == 6 )
    {
      //
      // Load DLL and set up function pointers for the Gryphon products.
      //
      ulRetVal = LoadDLLAndFunctions( "J2534G32.DLL", &hDLL );
          
      if( FALSE == ulRetVal )
        {
          fprintf(stderr,"LoadDLLAndFunctions(Gryphon, G2, S3, S4) failed.  Exiting(...)\n");
          exit( ulRetVal );
        }
    }

  //
  // PassThruOpen() - Open a connection to the device.  Get the DeviceID back.
  //
  ulRetVal = PassThruOpen( NULL, &ulDeviceID );
  
  if( STATUS_NOERROR != ulRetVal )
    {
      fprintf(stderr,"PassThruOpen() Returned Failure of %d\n", ulRetVal );
      FreeLibrary( hDLL );
      exit( ulRetVal );
    }
  
  //
  // PassThruReadVersion() - Get the API, DLL, and FW version information.
  //
  ulRetVal = PassThruReadVersion( ulDeviceID, szFirmwareVersion, szDLLVersion, szAPIVersion );
  
  if( STATUS_NOERROR != ulRetVal )
    {
      fprintf(stderr,"PassThruReadVersion() Returned Failure of %d\n", ulRetVal );
    }
  else
    {
      printf("\nDevice Firmware Version = [%s], DLL Version = [%s], API Version = [%s]\n\n", szFirmwareVersion, szDLLVersion, szAPIVersion );
    }
  
  //
  // PassThruconnect() - Connect to the ISO15765 data bus.
  //
  ulRetVal = PassThruConnect( ulDeviceID, ulProtocolID, ulProtocolFlagsISO15765, ulProtocolBaud, &ulChannelID );
  
  if( STATUS_NOERROR != ulRetVal )
    {
      fprintf(stderr,"PassThruConnect() Returned Failure of %d\n", ulRetVal );
      FreeLibrary( hDLL );
      exit( ulRetVal );
    }
  
  //
  // Setup ISO15765 flow control filters for all allowable 11-bit ISO15765-4 
  // external test equipment/ECM address combinations.
  //
  //     External Test Equipment      Physical Response CANID
  //     -----------------------      -----------------------
  //            0x7E0                         0x7E8
  //            0x7E1                         0x7E9
  //            0x7E2                         0x7EA
  //            0x7E3                         0x7EB
  //            0x7E4                         0x7EC
  //            0x7E5                         0x7ED
  //            0x7E6                         0x7EE
  //            0x7E7                         0x7EF
  
  sMaskMsg.ProtocolID        = ulProtocolID;
  sMaskMsg.TxFlags           = ISO15765_FRAME_PAD;
  sMaskMsg.DataSize          = 4;
  sMaskMsg.Data[0]           = 0xFF;
  sMaskMsg.Data[1]           = 0xFF;
  sMaskMsg.Data[2]           = 0xFF;
  sMaskMsg.Data[3]           = 0xFF;
  
  sPatternMsg.ProtocolID     = ulProtocolID;
  sPatternMsg.TxFlags        = ISO15765_FRAME_PAD;
  sPatternMsg.DataSize       = 4;
  sPatternMsg.Data[0]        = 0x00;
  sPatternMsg.Data[1]        = 0x00;
  sPatternMsg.Data[2]        = 0x07;
  sPatternMsg.Data[3]        = 0xE8;
  
  sFlowControlMsg.ProtocolID = ulProtocolID;
  sFlowControlMsg.TxFlags    = ISO15765_FRAME_PAD;
  sFlowControlMsg.DataSize   = 4;
  sFlowControlMsg.Data[0]    = 0x00;
  sFlowControlMsg.Data[1]    = 0x00;
  sFlowControlMsg.Data[2]    = 0x07;
  sFlowControlMsg.Data[3]    = 0xE0;
  
  //
  // Setup flow control filters for all pairs.
  //
  for( sFlowControlMsg.Data[3] = 0xE0; sFlowControlMsg.Data[3] < 0xE8; sFlowControlMsg.Data[3]++,  sPatternMsg.Data[3]++ )
    {
      ulRetVal = PassThruStartMsgFilter( ulChannelID, FLOW_CONTROL_FILTER, &sMaskMsg, &sPatternMsg, &sFlowControlMsg, &ulFlowFilter );
      
      if( STATUS_NOERROR != ulRetVal )
        {
          PassThruGetLastError( &szErrMsg[0] );
          
          printf( "PassThruStartMsgFilter(FLOW_CONTROL_FILTER) Returned Failure of %d.  Msg=[%s].  Exiting...\n", ulRetVal, szErrMsg );
          
          PassThruDisconnect( ulChannelID );
          
          FreeLibrary( hDLL );
          
          exit( ulRetVal );
        }
      else
        {
          printf( "Setting flow/pattern filter Tester(0x%0X%0X%0X%0X) / ECM (0x%0X%0X%0X%0X) successful.\n",
                  sPatternMsg.Data[0]        ,
                  sPatternMsg.Data[1]        ,
                  sPatternMsg.Data[2]        ,
                  sPatternMsg.Data[3]        ,
                  sFlowControlMsg.Data[0]    ,
                  sFlowControlMsg.Data[1]    ,
                  sFlowControlMsg.Data[2]    ,
                  sFlowControlMsg.Data[3]    
                  );
        }
    }
  
  while( iAlwaysTRUE )
    {
      printf("                                                                                                \n");
      printf("----------------------------------------------------------------------------------------------- \n");
      printf(" 1 - Request Mode 1 Supported PIDs (Mode 1, PID 0x00, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0, 0xE0) \n");
      printf(" 2 - Request Engine RPM            (Mode 1, PID 0x0C)                                           \n");
      printf(" 0 - Exit                                                                                       \n");
      printf("----------------------------------------------------------------------------------------------- \n");
      printf("                                                                                                \n");
      printf("-> " );

      iSelection = atoi( gets( szUserBuffer ) );

      switch( iSelection )
        {
        case     1: RequestMode1SupportedPIDS( ulChannelID, ulTesterCANID, 1, stdout, NULL ); break;
        case     2: RequestEngineRPM         ( ulChannelID, ulTesterCANID, 1, stdout, NULL ); break;
        default:                                                                              break;
        }

      if( iSelection == 0 )
        {
          break;
        }
    }
  
  //
  // PassThruDisconnect() - Disconnect from the protocol data bus.
  //
  PassThruDisconnect( ulChannelID );
  
  //
  // PassThruClose() - Close connection to the device.
  //
  PassThruClose( ulDeviceID );
  
  //
  // Free the DLL.
  //
  FreeLibrary( hDLL );
  
  return 0;
}

//================================================================================
// Request Mode Supported PIDS
//================================================================================

int RequestEngineRPM( UL ulChannelID, UL ulTesterCANID, U8 ucMode, FILE *fp1, FILE *fp2 )
{
  UL            ulNumMessages    = 1;
  UL            ulRetVal         = 0;
  PASSTHRU_MSG  sSendMessage     = {0};
  char          szErrMsg   [500] = {0};
  char          szMessage  [500] = {0};
  
  // 
  // Initialize complex variables.
  //
  memset( &sSendMessage          , 0x00, sizeof( sSendMessage ) );
  memset( szErrMsg               , 0x00, sizeof( szErrMsg     ) );
  memset( szMessage              , 0x00, sizeof( szMessage    ) );
  
  // 
  // Set up the message header to send.
  //
  sSendMessage.ProtocolID         = ISO15765            ;
  sSendMessage.RxStatus           = 0x00000000          ;
  sSendMessage.ExtraDataIndex     = 0x00000000          ;
  sSendMessage.Timestamp          = 0x00000000          ;
  sSendMessage.TxFlags            = ISO15765_FRAME_PAD  ;
  
  //
  // CANID is always 4 bytes even though we are using 11-bit.
  //
  sSendMessage.Data[0]            = BYTE3_OF_INT4( ulTesterCANID );
  sSendMessage.Data[1]            = BYTE2_OF_INT4( ulTesterCANID );
  sSendMessage.Data[2]            = BYTE1_OF_INT4( ulTesterCANID );
  sSendMessage.Data[3]            = BYTE0_OF_INT4( ulTesterCANID );
  
  //
  // Request for PID 0x0C (Engine RPM).
  //
  sSendMessage.Data[4]   = ucMode; // DB1
  sSendMessage.Data[5]   = 0x0C;   // DB2
  sSendMessage.DataSize  = 6;
  
  ulRetVal = PassThruWriteMsgs( ulChannelID, &sSendMessage, &ulNumMessages, 1000 );
  
  if( STATUS_NOERROR != ulRetVal )
    {
      PassThruGetLastError( &szErrMsg[0] );
      
      fprintf(stderr,"RequestEngineRPM(Mode=0x%0X) PassThruWriteMsgs() Returned Failure of %d.  Msg=[%s]\n", (int) ucMode, ulRetVal, szErrMsg  );
      
      return FALSE;
    }
  else
    {
      PrintTxISO15765Message( fp1, fp2, sSendMessage, szMessage, sizeof( szMessage ) );
    }
  
  //
  // Read and process ISO15765 messages until the buffer is empty.
  //
  ReadAndProcessISO15765Messages( fp1, fp2 );
  
  return TRUE;
}

//================================================================================
// Request Mode Supported PIDS
//================================================================================

int RequestMode1SupportedPIDS ( UL ulChannelID, UL ulTesterCANID, U8 ucMode, FILE *fp1, FILE *fp2 )
{
  UL            ulNumMessages    = 1;
  UL            ulRetVal         = 0;
  PASSTHRU_MSG  sSendMessage     = {0};
  char          szErrMsg   [500] = {0};
  char          szMessage  [500] = {0};
  
  // 
  // Initialize complex variables.
  //
  memset( &sSendMessage          , 0x00, sizeof( sSendMessage ) );
  memset( szErrMsg               , 0x00, sizeof( szErrMsg     ) );
  memset( szMessage              , 0x00, sizeof( szMessage    ) );
  
  // 
  // Set up the message header to send.
  //
  sSendMessage.ProtocolID         = ISO15765            ;
  sSendMessage.RxStatus           = 0x00000000          ;
  sSendMessage.ExtraDataIndex     = 0x00000000          ;
  sSendMessage.Timestamp          = 0x00000000          ;
  sSendMessage.TxFlags            = ISO15765_FRAME_PAD  ;
  
  //
  // CANID is always 4 bytes even though we are using 11-bit.
  //
  sSendMessage.Data[0]            = BYTE3_OF_INT4( ulTesterCANID );
  sSendMessage.Data[1]            = BYTE2_OF_INT4( ulTesterCANID );
  sSendMessage.Data[2]            = BYTE1_OF_INT4( ulTesterCANID );
  sSendMessage.Data[3]            = BYTE0_OF_INT4( ulTesterCANID );
  
  //
  // Requests for all PIDS take two messages:
  //     Msg1=(0x00, 0x20, 0x40, 0x60, 0x80, 0xA0)
  //     Msg2=(0xC0, 0xE0)
  //
  sSendMessage.Data[4]   = ucMode; // DB1
  sSendMessage.Data[5]   = 0x00;   // DB2
  sSendMessage.Data[6]   = 0x20;   // DB3
  sSendMessage.Data[7]   = 0x40;   // DB4
  sSendMessage.Data[8]   = 0x60;   // DB5
  sSendMessage.Data[9]   = 0x80;   // DB6
  sSendMessage.Data[10]  = 0xA0;   // DB7
  sSendMessage.DataSize  = 11;
  
  ulRetVal = PassThruWriteMsgs( ulChannelID, &sSendMessage, &ulNumMessages, 1000 );
  
  if( STATUS_NOERROR != ulRetVal )
    {
      PassThruGetLastError( &szErrMsg[0] );
      
      fprintf(stderr,"RequestModeSupportedPIDS(Mode=0x%0X) PassThruWriteMsgs() Returned Failure of %d.  Msg=[%s]\n", (int) ucMode, ulRetVal, szErrMsg  );
      
      return FALSE;
    }
  else
    {
      PrintTxISO15765Message( fp1, fp2, sSendMessage, szMessage, sizeof( szMessage ) );
    }
  
  //
  // Read and process ISO15765 messages until the buffer is empty.
  //
  ReadAndProcessISO15765Messages( fp1, fp2 );
  
  //
  // Requests for all PIDS take two messages:
  //     Msg1=(0x00, 0x20, 0x40, 0x60, 0x80, 0xA0)
  //     Msg2=(0xC0, 0xE0)
  //
  sSendMessage.Data[4]   = ucMode; // DB1
  sSendMessage.Data[5]   = 0xC0;   // DB2
  sSendMessage.Data[6]   = 0xE0;   // DB3
  sSendMessage.DataSize  = 7;
  
  ulRetVal = PassThruWriteMsgs( ulChannelID, &sSendMessage, &ulNumMessages, 1000 );
  
  if( STATUS_NOERROR != ulRetVal )
    {
      PassThruGetLastError( &szErrMsg[0] );
      
      fprintf(stderr,"RequestModeSupportedPIDS(Mode=0x%0X) PassThruWriteMsgs() Returned Failure of %d.  Msg=[%s]\n", (int) ucMode, ulRetVal, szErrMsg  );
      
      return FALSE;
    }
  else
    {
      PrintTxISO15765Message( fp1, fp2, sSendMessage, szMessage, sizeof( szMessage )  );
    }
  
  //
  // Read and process ISO15765 messages until the buffer is empty.
  //
  ReadAndProcessISO15765Messages( fp1, fp2 );
  
  return TRUE;
}

//------------------------------------------------------------------------------------------------------------------
// PrintTxISO15765Message - Print a message that was sent on the ISO15765 bus.
//------------------------------------------------------------------------------------------------------------------

UL PrintTxISO15765Message( FILE *fp1, FILE *fp2, PASSTHRU_MSG sSentMsg, char *szMsgString, int iMsgStringSize  )
{
  int       i                      = 0;
  int       j                      = 0;
  UL        nDataBytesIndex        = 0;
  UL        nNumDataBytes          = 0;
  int       iCANID                 = 0;
  
  // 
  // The function returns the string to print in szMsgString, so initialize it to all zeros.
  //
  if( szMsgString != NULL )
    {
      memset( szMsgString, 0x00, iMsgStringSize );
    }
  
  //
  // Have to print "somewhere", stdout is just as good of a place as any.
  //
  if( fp1 == NULL )
    {
      fp1 = stdout;
    }
  
  //
  // Unpack the CANID.  It is always 4 bytes even when using 11-bit.
  //
  iCANID          = UnPackFourByteIntegerMSB( &sSentMsg.Data[0], NULL );
  
  //
  // Data bytes will start appearing at index 4.
  //
  nDataBytesIndex = 4;
  
  //
  // Calculate the number of data bytes in the message.
  //
  nNumDataBytes   = sSentMsg.DataSize - nDataBytesIndex;
  
  //
  // Print the string to the FILE pointers and to the variable szMsgString.
  //
  fprintf(fp1,  "Tx ISO15765 CANID=[0x%08X]  TxFlags=[0x%08X] DataLen=[%2d]", iCANID, sSentMsg.TxFlags, nNumDataBytes );
  
  if( fp2 != NULL )
    {
      fprintf(fp2,"Tx ISO15765 CANID=[0x%08X]  TxFlags=[0x%08X] DataLen=[%2d]", iCANID, sSentMsg.TxFlags, nNumDataBytes );
    }
  
  if( szMsgString != NULL )
    {
      sprintf(szMsgString,"Tx ISO15765 CANID=[0x%08X]  TxFlags=[0x%08X] DataLen=[%2d]", iCANID, sSentMsg.TxFlags, nNumDataBytes );
    }
  
  //
  // If data bytes exist (some messages are just indications), print the data bytes as well.
  //  
  if( nNumDataBytes > 0 )
    {
      fprintf(fp1," DATA");
      
      if( fp2 != NULL )
        {
          fprintf(fp2," DATA");
        }
      
      if( szMsgString != NULL )
        {
          sprintf(szMsgString,"%s DATA", szMsgString);
        }
      
      for( j = 0, i = nDataBytesIndex; j < (int) nNumDataBytes; j++, i++)
        {
          fprintf(fp1,  "[%02X]", sSentMsg.Data[i] );
          
          if( fp2 != NULL )
            {
              fprintf(fp2,"[%02X]", sSentMsg.Data[i] );
            }
          
          if( szMsgString != NULL )
            {
              sprintf(szMsgString,"%s[%02X]", szMsgString, sSentMsg.Data[i]);
            }
        }
    }
  
  //
  // Terminate the line with a newline.  If putting text into a Windows edit box
  // you would need to change \n to \r\n.
  //
  fprintf(fp1,"\n");
  
  if( fp2 != NULL )
    {
      fprintf(fp2,"\n");
    }
  
  if( szMsgString != NULL )
    {
      sprintf(szMsgString,"%s\n", szMsgString);
    }
  
  return ERROR_SUCCESS;
}

//------------------------------------------------------------------------------------------------------------------
// ReadAndProcessISO15765Messages - Since the PassThruReadMsgs may return status indicators and some requests
//                                  may return more than one message, this function reads messages until the 
//                                  buffer is empty.  On each message, it is handled to a "Process" routine
//                                  that looks for specific PID responses (i.e. 0x41).
//------------------------------------------------------------------------------------------------------------------

UL ReadAndProcessISO15765Messages( FILE *fp1, FILE *fp2 )
{
  PASSTHRU_MSG sReadMessage;
  char         szMessage  [2000] = {0};
  UL           ulRetVal          = 0;
  UL           ulNumMessages     = 1;
  
  //
  // Have to print "somewhere", stdout is just as good of a place as any.
  //
  if( fp1 == NULL )
    {
      fp1 = stdout;
    }
  
  //
  // Read messages until dry.
  //
  do
    {
      //
      // Clear the structure for the call to reading messages.
      //
      memset( &sReadMessage, 0x00, sizeof( sReadMessage ) );
      
      //
      // Setup to read 1 message with a 250ms timeout value.
      //
      ulNumMessages = 1;
      
      sReadMessage.ProtocolID = ulProtocolID;
      
      //
      // Attempt to read a message.
      //
      ulRetVal = PassThruReadMsgs( ulChannelID, &sReadMessage, &ulNumMessages, 250 );
      
      if( STATUS_NOERROR == ulRetVal )
        {
          ProcessRxISO15765Message( fp1, fp2, sReadMessage, szMessage, sizeof( szMessage ) );
        }
      
    } while( ulRetVal != ERR_BUFFER_EMPTY );
  
  return ERROR_SUCCESS;
}

//------------------------------------------------------------------------------------------------------------------
// ProcessRxISO15765Message - Process a received ISO15765 message.  Look for PID 0x41 which will arrive in 
//                            response to our sending of PID 1 (Supported PIDS).
//------------------------------------------------------------------------------------------------------------------

UL ProcessRxISO15765Message( FILE *fp1, FILE *fp2, PASSTHRU_MSG sReadMessage, char *szMsgString, int iMsgStringSize )
{
  UL        nNumDataBytes          = 0;
  double    dValue                 = 0.0;
  int       iCANID                 = 0;
  int       i                      = 0;
  
  //
  // Print the raw message to the file pointers fp1, fp2.
  //
  PrintRxISO15765Message( fp1, fp2, sReadMessage, szMsgString, iMsgStringSize );
  
  //
  // Have to print "somewhere", stdout is just as good of a place as any.
  //
  if( fp1 == NULL )
    {
      fp1 = stdout;
    }
  
  // 
  // This function does not use szMsgString, but a customer implementation might, so it is still initialized.
  //
  if( szMsgString != NULL )
    {
      memset( szMsgString, 0x00, iMsgStringSize );
    }
  
  //
  // Unpack the CANID of the node.
  //
  iCANID    = UnPackFourByteIntegerMSB( &sReadMessage.Data[0], NULL );
  
  //
  // The number of data bytes is the data size - 5 (4 bytes CANID + 1 byte for the PID ).
  //
  nNumDataBytes   = sReadMessage.DataSize - 5;
  
  switch( sReadMessage.Data[4] )
    {
      //
      // Read Supported PID Mode 1 Response
      //
    case 0x41:
      
      //
      // Engine RPM
      //
      if( sReadMessage.Data[5] == 0x0C )
        {
          dValue = UnPackTwoByteIntegerMSB( &sReadMessage.Data[6], NULL );

          dValue = (double) dValue * 0.25;

          if( ( dValue < 0 ) || ( dValue > 16383.75 ) )
            {
              printf("Engine RPM value %13.4f out of range.\n", dValue );
            }
          else
            {
              printf("Engine RPM: %13.4f\n", dValue );
            }
        }
      else
        {
          //
          // MODE Supported PIDs (0x00, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0, 0xE0)
          //
          fprintf(fp1, "\nReceived PID 0x41 - Response to PID=0x01, Mode Supported PIDs from CANID=0x%04X.\n", iCANID );
          
          if( fp2 )
            {
              fprintf(fp2, "\nReceived PID 0x41 - Response to PID=0x01, Mode Supported PIDs from CANID=0x%04X.\n", iCANID );
            }
          
          fprintf( fp1, "\t" );
          
          if( fp2 )
            {
              fprintf( fp2, "\t" );
            }
          
          for( i = 0; i < (int) nNumDataBytes; i++ )
            {
              fprintf( fp1, "[%02X]", sReadMessage.Data[i+5] );
              
              if( fp2 )
                {
                  fprintf( fp2, "[%02X]", sReadMessage.Data[i+5] );
                }
            }
          
          fprintf( fp1, "\n\n" );
          
          if( fp2 )
            {
              fprintf( fp2, "\n\n" );
            }
        }

      break;
      
    }
  
  return ERROR_SUCCESS;
}

//------------------------------------------------------------------------------------------------------------------
// PrintRxISO15765Message - Print a received ISO15765 message.
//------------------------------------------------------------------------------------------------------------------

UL PrintRxISO15765Message( FILE *fp1, FILE *fp2, PASSTHRU_MSG sReadMessage, char *szMsgString, int iMsgStringSize )
{
  int       i                      = 0;
  int       j                      = 0;
  UL        nDataBytesIndex        = 0;
  UL        nNumDataBytes          = 0;
  int       iCANID                 = 0;
  
  // 
  // The function returns the string to print in szMsgString, so initialize it to all zeros.
  //
  if( szMsgString != NULL )
    {
      memset( szMsgString, 0x00, iMsgStringSize );
    }
  
  //
  // Have to print "somewhere", stdout is just as good of a place as any.
  //
  if( fp1 == NULL )
    {
      fp1 = stdout;
    }
  
  //
  // Unpack the CANID.  It is always 4 bytes even when using 11-bit.
  //
  iCANID          = UnPackFourByteIntegerMSB( &sReadMessage.Data[0], NULL );
  
  //
  // Data bytes will start appearing at index 4.
  //
  nDataBytesIndex = 4;
  
  //
  // Calculate the number of data bytes in the message.
  //
  nNumDataBytes   = sReadMessage.DataSize - nDataBytesIndex;
  
  //
  // Print the string to the FILE pointers and to the variable szMsgString.
  //
  fprintf( fp1, "Rx ISO15765 CANID=[0x%08X] RxStatus=[0x%08X] DataLen=[%2d]", iCANID, sReadMessage.RxStatus, nNumDataBytes );
  
  if( fp2 != NULL )
    {
      fprintf( fp2, "Rx ISO15765 CANID=[0x%08X] RxStatus=[0x%08X] DataLen=[%2d]", iCANID, sReadMessage.RxStatus, nNumDataBytes );
    }
  
  if( szMsgString != NULL )
    {
      sprintf( szMsgString, "Rx ISO15765 CANID=[0x%08X] RxStatus=[0x%08X] DataLen=[%2d]", iCANID, sReadMessage.RxStatus, nNumDataBytes );
    }
  
  //
  // If data bytes exist (some messages are just indications), print the data bytes as well.
  //  
  if( nNumDataBytes > 0 )
    {
      fprintf(fp1," DATA");
      
      if( fp2 != NULL )
        {
          fprintf(fp2," DATA");
        }
      
      if( szMsgString != NULL )
        {
          sprintf( szMsgString, "%s DATA", szMsgString );
        }
      
      for( j = 0, i = nDataBytesIndex; j < (int) nNumDataBytes; j++, i++ )
        {
          fprintf(fp1,  "[%02X]", sReadMessage.Data[i]);
          
          if( fp2 != NULL )
            {
              fprintf(fp2,"[%02X]", sReadMessage.Data[i]);
            }
          
          if( szMsgString != NULL )
            {
              sprintf( szMsgString, "%s[%02X]", szMsgString, sReadMessage.Data[i] );
            }
        }
    }
  
  //
  // Terminate the line with a newline.  If putting text into a Windows edit box
  // you would need to change \n to \r\n.
  //
  fprintf(fp1,"\n");
  
  if( fp2 != NULL )
    {
      fprintf(fp2,"\n");
    }
  
  if( szMsgString != NULL )
    {
      sprintf( szMsgString, "%s\n", szMsgString );
    }
  
  return ERROR_SUCCESS;
}

//------------------------------------------------------------------------------------------------------------------
// LoadDLLAndFunctions - Load the J2534 DLL pointed to by szDLLName, set global function variables.
//------------------------------------------------------------------------------------------------------------------

UL LoadDLLAndFunctions( char *szDLLName, HMODULE *hDLL )
{
  if ( ( *hDLL = LoadLibrary( szDLLName ) ) == NULL )
    {
      fprintf( stderr, "Failed to load library (%s)!\n", szDLLName );
      return( FALSE );
    }
  
  PassThruOpen                  = (fxPassThruOpen)                  GetProcAddress( *hDLL, "PassThruOpen"                  );
  PassThruClose                 = (fxPassThruClose)                 GetProcAddress( *hDLL, "PassThruClose"                 );
  PassThruConnect               = (fxPassThruConnect)               GetProcAddress( *hDLL, "PassThruConnect"               );
  PassThruDisconnect            = (fxPassThruDisconnect)            GetProcAddress( *hDLL, "PassThruDisconnect"            );
  PassThruReadMsgs              = (fxPassThruReadMsgs)              GetProcAddress( *hDLL, "PassThruReadMsgs"              );
  PassThruWriteMsgs             = (fxPassThruWriteMsgs)             GetProcAddress( *hDLL, "PassThruWriteMsgs"             );
  PassThruStartPeriodicMsg      = (fxPassThruStartPeriodicMsg)      GetProcAddress( *hDLL, "PassThruStartPeriodicMsg"      );
  PassThruStopPeriodicMsg       = (fxPassThruStopPeriodicMsg)       GetProcAddress( *hDLL, "PassThruStopPeriodicMsg"       );
  PassThruStartMsgFilter        = (fxPassThruStartMsgFilter)        GetProcAddress( *hDLL, "PassThruStartMsgFilter"        );
  PassThruStopMsgFilter         = (fxPassThruStopMsgFilter)         GetProcAddress( *hDLL, "PassThruStopMsgFilter"         );
  PassThruSetProgrammingVoltage = (fxPassThruSetProgrammingVoltage) GetProcAddress( *hDLL, "PassThruSetProgrammingVoltage" );
  PassThruReadVersion           = (fxPassThruReadVersion)           GetProcAddress( *hDLL, "PassThruReadVersion"           );
  PassThruGetLastError          = (fxPassThruGetLastError)          GetProcAddress( *hDLL, "PassThruGetLastError"          );
  PassThruIoctl                 = (fxPassThruIoctl)                 GetProcAddress( *hDLL, "PassThruIoctl"                 );
  
  if( NULL == PassThruOpen                    ) return FALSE;
  if( NULL == PassThruClose                   ) return FALSE;
  if( NULL == PassThruConnect                 ) return FALSE;
  if( NULL == PassThruDisconnect              ) return FALSE;
  if( NULL == PassThruReadMsgs                ) return FALSE;
  if( NULL == PassThruWriteMsgs               ) return FALSE;
  if( NULL == PassThruStartPeriodicMsg        ) return FALSE;
  if( NULL == PassThruStopPeriodicMsg         ) return FALSE;
  if( NULL == PassThruStartMsgFilter          ) return FALSE;
  if( NULL == PassThruStopMsgFilter           ) return FALSE;
  if( NULL == PassThruSetProgrammingVoltage   ) return FALSE;
  if( NULL == PassThruReadVersion             ) return FALSE;
  if( NULL == PassThruGetLastError            ) return FALSE;
  if( NULL == PassThruIoctl                   ) return FALSE;
  
  return TRUE;
}

// ----------------------------------------------------------------------
//  Function:  UnPackTwoByteIntegerLSB
// 
//  Purpose:   Unpack a two-byte integer that has been sent least 
//             significant byte first.  
// 
// ----------------------------------------------------------------------

short UnPackTwoByteIntegerLSB( U8 *ucIntString, int *iFFFlag )
{
  short iValue = 0;
  
  iValue = ( ucIntString[1] << 8 ) | ( ucIntString[0] );
  
  if( NULL != iFFFlag )
    {
      if( (ucIntString[0] == 0xFF) && (ucIntString[1] == 0xFF) )
        *iFFFlag = TRUE;
      else
        *iFFFlag = FALSE;
    }
  
  return iValue;
}

// ----------------------------------------------------------------------
//  Function:  UnPackThreeByteIntegerLSB
// 
//  Purpose:   Unpack a three-byte integer that has been sent least 
//             significant byte first.  
// 
// ----------------------------------------------------------------------

int UnPackThreeByteIntegerLSB( U8 *ucIntString, int *iFFFlag)
{
  int iValue = 0;
  
  iValue = (ucIntString[2] << 16) | ( ucIntString[1] << 8 ) | ( ucIntString[0] );
  
  if( NULL != iFFFlag )
    {
      if( (ucIntString[0] == 0xFF) && (ucIntString[1] == 0xFF) && (ucIntString[2] == 0xFF) )
        *iFFFlag = TRUE;
      else
        *iFFFlag = FALSE;
    }

  return iValue;
}

// ----------------------------------------------------------------------
//  Function:  UnPackFourByteIntegerLSB
// 
//  Purpose:   Unpack a four-byte integer that has been sent least 
//             significant byte first.  
// 
// ----------------------------------------------------------------------

int UnPackFourByteIntegerLSB( U8 *ucIntString, int *iFFFlag )
{
  int iValue = 0;
  
  iValue = (ucIntString[3] << 24) | (ucIntString[2] << 16) | ( ucIntString[1] << 8 ) | ( ucIntString[0] );
  
  if( NULL != iFFFlag )
    {
      if( (ucIntString[0] == 0xFF) && (ucIntString[1] == 0xFF) && (ucIntString[2] == 0xFF) && (ucIntString[3] == 0xFF) )
        *iFFFlag = TRUE;
      else
        *iFFFlag = FALSE;
    }

  return iValue;
}

// ----------------------------------------------------------------------
//  Function:  UnPackTwoByteIntegerMSB
// 
//  Purpose:   Unpack a two-byte integer that has been sent most
//             significant byte first.  
// 
// ----------------------------------------------------------------------

short UnPackTwoByteIntegerMSB( U8 *ucIntString, int *iFFFlag )
{
  short iValue = 0;
  
  iValue = ( ucIntString[0] << 8 ) | ( ucIntString[1] );
  
  if( NULL != iFFFlag )
    {
      if( (ucIntString[0] == 0xFF) && (ucIntString[1] == 0xFF) )
        *iFFFlag = TRUE;
      else
        *iFFFlag = FALSE;
    }
  
  return iValue;
}

// ----------------------------------------------------------------------
//  Function:  UnPackThreeByteIntegerMSB
// 
//  Purpose:   Unpack a three-byte integer that has been sent most
//             significant byte first.  
// 
// ----------------------------------------------------------------------

int UnPackThreeByteIntegerMSB( U8 *ucIntString, int *iFFFlag )
{
  int iValue = 0;
  
  iValue = (ucIntString[0] << 16) | ( ucIntString[1] << 8 ) | ( ucIntString[2] );
  
  if( NULL != iFFFlag )
    {
      if( (ucIntString[0] == 0xFF) && (ucIntString[1] == 0xFF) && (ucIntString[2] == 0xFF) )
        *iFFFlag = TRUE;
      else
        *iFFFlag = FALSE;
    }

  return iValue;
}

// ----------------------------------------------------------------------------------------------------
//  Function:  UnPackFourByteIntegerMSB
// 
//  Purpose:   Unpack a four-byte integer that has been sent most significant
//             byte first.  
// 
// ----------------------------------------------------------------------------------------------------

int UnPackFourByteIntegerMSB( U8 *ucIntString, int *iFFFlag )
{
  int iValue = 0;
  
  iValue = (ucIntString[0] << 24 )|(ucIntString[1] << 16 )|(ucIntString[2] << 8  )|(ucIntString[3] );
  
  if( NULL != iFFFlag )
    {
      if( (ucIntString[0] == 0xFF) && (ucIntString[1] == 0xFF) && (ucIntString[2] == 0xFF) && (ucIntString[3] == 0xFF) )
        *iFFFlag = TRUE;
      else
        *iFFFlag = FALSE;
    }

  return iValue;
}

// ----------------------------------------------------------------------------------------------------
//  Function:  CreateTwoByteIntegerLSB
// 
//  Purpose:   Given an integer, create a two byte U8 LSB representation.
// 
// ----------------------------------------------------------------------------------------------------

U8 *CreateTwoByteIntegerLSB( int iVal, U8 *szBuffer )
{
  szBuffer[0] = (U8) BYTE0_OF_INT4( iVal );
  szBuffer[1] = (U8) BYTE1_OF_INT4( iVal );

  return ( &szBuffer[0] );
}

// ----------------------------------------------------------------------------------------------------
//  Function:  CreateThreeByteIntegerLSB
// 
//  Purpose:   Given an integer, create a three byte U8 LSB representation.
// 
// ----------------------------------------------------------------------------------------------------

U8 *CreateThreeByteIntegerLSB( int iVal, U8 *szBuffer )
{
  szBuffer[0] = (U8) BYTE0_OF_INT4( iVal );
  szBuffer[1] = (U8) BYTE1_OF_INT4( iVal );
  szBuffer[2] = (U8) BYTE2_OF_INT4( iVal );
  
  return ( &szBuffer[0] );
}

// ----------------------------------------------------------------------------------------------------
//  Function:  CreateFourByteIntegerLSB
// 
//  Purpose:   Given an integer, create a four byte U8 LSB representation.
// 
// ----------------------------------------------------------------------------------------------------

U8 *CreateFourByteIntegerLSB( int iVal, U8 *szBuffer )
{
  szBuffer[0] = (U8) BYTE0_OF_INT4( iVal );
  szBuffer[1] = (U8) BYTE1_OF_INT4( iVal );
  szBuffer[2] = (U8) BYTE2_OF_INT4( iVal );
  szBuffer[3] = (U8) BYTE3_OF_INT4( iVal );
  
  return ( &szBuffer[0] );
}

// ----------------------------------------------------------------------------------------------------
//  Function:  CreateTwoByteIntegerMSB
// 
//  Purpose:   Given an integer, create a two byte U8 MSB representation.
// 
// ----------------------------------------------------------------------------------------------------

U8 *CreateTwoByteIntegerMSB( int iVal, U8 *szBuffer )
{
  szBuffer[0] = (U8) BYTE1_OF_INT4( iVal );
  szBuffer[1] = (U8) BYTE0_OF_INT4( iVal );
  
  return ( &szBuffer[0] );
}

// ----------------------------------------------------------------------------------------------------
//  Function:  CreateThreeByteIntegerMSB
// 
//  Purpose:   Given an integer, create a three byte U8 MSB representation.
// 
// ----------------------------------------------------------------------------------------------------

U8 *CreateThreeByteIntegerMSB( int iVal, U8 *szBuffer )
{
  szBuffer[0] = (U8) BYTE2_OF_INT4( iVal );
  szBuffer[1] = (U8) BYTE1_OF_INT4( iVal );
  szBuffer[2] = (U8) BYTE0_OF_INT4( iVal );
  
  return ( &szBuffer[0] );
}

// ----------------------------------------------------------------------------------------------------
//  Function:  CreateFourByteIntegerMSB
// 
//  Purpose:   Given an integer, create a four byte U8 MSB representation.
// 
// ----------------------------------------------------------------------------------------------------

U8 *CreateFourByteIntegerMSB( int iVal, U8 *szBuffer )
{
  szBuffer[0] = (U8) BYTE3_OF_INT4( iVal );
  szBuffer[1] = (U8) BYTE2_OF_INT4( iVal );
  szBuffer[2] = (U8) BYTE1_OF_INT4( iVal );
  szBuffer[3] = (U8) BYTE0_OF_INT4( iVal );
  
  return ( &szBuffer[0] );
}
